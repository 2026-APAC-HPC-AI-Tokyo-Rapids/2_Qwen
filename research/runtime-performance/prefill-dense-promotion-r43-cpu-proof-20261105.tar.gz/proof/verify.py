from pathlib import Path
import ast
import hashlib
import json
import re
import sys
import tarfile

root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text())
if len(sys.argv) > 1:
    with tarfile.open(sys.argv[1]) as archive:
        for path, sha in manifest.items():
            assert hashlib.sha256(archive.extractfile("proof/" + path).read()).hexdigest() == sha, path
else:
    for path, sha in manifest.items():
        assert hashlib.sha256((root / path).read_bytes()).hexdigest() == sha, path
compile_records = json.loads((root / "compile.json").read_text())
deps = json.loads((root / "dependency.json").read_text())
accounting = json.loads((root / "accounting.json").read_text())
for shape in ("qkv", "o"):
    record = compile_records[shape]
    sass = (root / f"{shape}.sass").read_text()
    words = re.findall(r"/\* 0x([0-9a-f]{16}) \*/", sass)
    encoding = b"".join(int(x, 16).to_bytes(8, "little") for x in words)
    assert len(encoding) == record["encoding_bytes"]
    assert hashlib.sha256(encoding).hexdigest() == record["encoding_sha256"]
    assert hashlib.sha256((root / f"{shape}.cubin").read_bytes()).hexdigest() == record["cubin_sha256"]
    assert "REG:168 STACK:0 SHARED:1024 LOCAL:0" in (root / f"{shape}.resources").read_text()
    assert "0 bytes stack frame, 0 bytes spill stores, 0 bytes spill loads" in (root / f"{shape}.compile.log").read_text()
    assert not re.search(r"C75\d\d|serialization", (root / f"{shape}.compile.log").read_text())
    assert not re.search(r"\b(?:LDL|STL)\b", sass)
    assert len(deps[shape]["halves"]) == 32
    assert all(x["ffma"] == 64 and x["all_promotion_before_reuse"] for x in deps[shape]["halves"])
    assert record["matches_r37_encoding"]
    assert accounting["shapes"][shape]["steady_chunk"]["slots"] == 1533
assert accounting["candidate_net_saving_us"] is None
assert not accounting["dense_cuda_13_0_cubin_found"]
for script in root.glob("*.py"):
    ast.parse(script.read_text())
print(json.dumps({"verified_member_hashes": len(manifest), "production_specializations": 2, "static_wave_dependencies": 64, "steady_chunks_verified": 2, "gpu_execution": False, "result": "PASS"}, indent=2))
