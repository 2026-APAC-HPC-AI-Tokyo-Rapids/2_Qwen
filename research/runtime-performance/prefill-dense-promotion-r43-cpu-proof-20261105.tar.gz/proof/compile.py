from pathlib import Path
import hashlib
import json
import re
import subprocess
import time

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent / "work"
INCLUDE = WORK / ".r40-proof/production/deep_gemm/include"
DEP = WORK / ".r40-proof/fixture/r32/dependencies"
EXPECTED = {"qkv": "9630609edf7b108d9ccdfd2fcaf5387a3a31f86ca79095394d043d1a2cdcfc35", "o": "11f685d47e665bb3c16cf1ebfa42cbd568e2fc963b5e10587c977ebe3f7a371b"}
records = {}
for shape in ("qkv", "o"):
    target = ROOT / f"{shape}.cu"
    cmd = ["/usr/local/cuda-13.4/bin/nvcc", "--cubin", "--std=c++20", "--expt-relaxed-constexpr", "--expt-extended-lambda", "-O3", "--diag-suppress=177", "--ptxas-options=-v,-warn-spills", "-gencode", "arch=compute_90a,code=sm_90a", "-I" + str(INCLUDE), "-I" + str(DEP), "-DDG_SM90_PREFILL_DENSE_FIRST_K=1", str(target), "-o", str(ROOT / f"{shape}.cubin")]
    start = time.monotonic()
    result = subprocess.run(cmd, capture_output=True, text=True)
    (ROOT / f"{shape}.compile.log").write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stderr
    sass = subprocess.check_output(["/usr/local/cuda-13.4/bin/nvdisasm", "-hex", str(ROOT / f"{shape}.cubin")], text=True)
    (ROOT / f"{shape}.sass").write_text(sass)
    words = re.findall(r"/\* 0x([0-9a-f]{16}) \*/", sass)
    encoding = b"".join(int(x, 16).to_bytes(8, "little") for x in words)
    record = {"command": cmd, "exit_code": result.returncode, "seconds": time.monotonic() - start, "encoding_bytes": len(encoding), "encoding_sha256": hashlib.sha256(encoding).hexdigest(), "cubin_sha256": hashlib.sha256((ROOT / f"{shape}.cubin").read_bytes()).hexdigest()}
    record["matches_r37_encoding"] = record["encoding_sha256"] == EXPECTED[shape]
    assert record["matches_r37_encoding"]
    records[shape] = record
    print(shape, json.dumps(record), flush=True)
(ROOT / "compile.json").write_text(json.dumps(records, indent=2) + "\n")
