from pathlib import Path
import hashlib
import json
import re
from collections import Counter

root = Path(__file__).resolve().parent
report = {}
for shape in ("qkv", "o"):
    text = (root / f"{shape}.sass").read_text()
    instructions = [(int(m[1], 16), m[2].strip()) for m in re.finditer(r"/\*([0-9a-f]+)\*/\s+(.+?);", text)]
    q = [i for i, (_, s) in enumerate(instructions) if "QGMMA." in s]
    assert len(q) == 128
    halves = []
    for j in range(32):
        indexes = q[j * 4 : j * 4 + 4]
        first, last = indexes[0], indexes[-1]
        next_first = q[j * 4 + 4] if j < 31 else next(i for i in range(last + 1, len(instructions)) if "STSM" in instructions[i][1])
        wait = next(i for i in range(last + 1, next_first) if "WARPGROUP.DEPBAR" in instructions[i][1])
        promotion = [i for i in range(wait + 1, next_first) if instructions[i][1].startswith("FFMA ")]
        assert len(promotion) == 64, (shape, j, len(promotion))
        assert "0x0" in instructions[wait][1]
        fence = max(i for i in range(first) if "WARPGROUP.ARRIVE" in instructions[i][1])
        scope_start = q[j * 4 - 1] + 1 if j else 0
        full = [(hex(pc), s) for pc, s in instructions[scope_start:first] if "SYNCS.PHASECHK" in s]
        loads = [(hex(pc), s) for pc, s in instructions[scope_start:first] if s.startswith(("LDS", "FMUL"))]
        releases = [(hex(pc), s) for pc, s in instructions[wait:next_first] if "SYNCS.ARRIVE" in s]
        dest = [int(re.search(r"FFMA R(\d+)", instructions[i][1])[1]) for i in promotion]
        temp = sorted(set(int(re.search(r"FFMA R\d+, R(\d+)", instructions[i][1])[1]) for i in promotion))
        assert len(temp) == 64
        halves.append({"section": "peeled" if j < 16 else "steady", "k_static": (j // 2) % 8, "m_wave": j % 2, "fence": hex(instructions[fence][0]), "qgmma": [hex(instructions[i][0]) for i in indexes], "wait": [hex(instructions[wait][0]), instructions[wait][1]], "promotion": [hex(instructions[promotion[0]][0]), hex(instructions[promotion[-1]][0])], "ffma": len(promotion), "temporary_registers": [temp[0], temp[-1]], "final_registers": dest, "prior_full_wait_checks": full, "prior_scale_loads_and_fmul": loads, "release": releases, "next_qgmma": hex(instructions[next_first][0]) if j < 31 else None, "all_promotion_before_reuse": promotion[-1] < next_first})
    steady_start = min(int(x["fence"], 16) for x in halves[16:])
    steady_end = int(halves[-1]["promotion"][-1], 16)
    active = [(pc, s) for pc, s in instructions if steady_start <= pc <= steady_end]
    reg = max(int(x) for x in re.findall(r"(?<![A-Z])R(\d+)", text))
    report[shape] = {"static_instruction_slots": len(instructions), "max_r_number": reg, "opcodes": dict(Counter(s.split()[0] for _, s in instructions)), "steady_issue_to_promotion_pc": [hex(steady_start), hex(steady_end)], "steady_partial_span_slots": len(active), "halves": halves}
    (root / f"{shape}-dependency.tsv").write_text("section\tk\tm_wave\tfence\tqgmma\twait0\tFFMA64\ttemporary\trelease\n" + "\n".join(f"{x['section']}\t{x['k_static']}\t{x['m_wave']}\t{x['fence']}\t{','.join(x['qgmma'])}\t{x['wait'][0]}\t{'..'.join(x['promotion'])}\t{x['temporary_registers']}\t{x['release']}" for x in halves) + "\n")
    print(shape, len(instructions), "max R", reg, "steady", hex(steady_start), hex(steady_end))
(root / "dependency.json").write_text(json.dumps(report, indent=2) + "\n")
