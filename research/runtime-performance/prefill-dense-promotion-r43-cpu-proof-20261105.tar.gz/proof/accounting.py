from pathlib import Path
import hashlib
import json
import re

repo = Path.cwd()
root = Path(__file__).resolve().parent
raw = Path("/srv/qwen-artifacts/41875058470/1")
source = raw / "source/source"
config = json.loads((repo / "configs/firmus-prefill-pp4.json").read_text())
records = []
for key, subdir in (("deep_gemm_overlay_patches", "deep-gemm-overlay"), ("sglang_overlay_patches", "sglang-overlay")):
    for path in config[key]:
        local = repo / path
        saved = source / subdir / local.name
        assert local.read_bytes() == saved.read_bytes(), path
        records.append({"path": path, "raw_path": str(saved), "sha256": hashlib.sha256(local.read_bytes()).hexdigest()})
inventory = [str(p.relative_to(raw)) for p in raw.rglob("*.cubin")]
assert not any("1d2d" in path for path in inventory)
data = {"patches_match_raw_in_order": records, "runtime_dense_header_sha256": "915bd4d3ee23e0ce6da735cd6b273700caa0d94a15a6917fb6eed93a4ac72350", "raw_cubin_inventory": inventory, "dense_cuda_13_0_cubin_found": False, "image": config["container_sha256"], "score": json.loads((raw / "results/results/score.json").read_text()), "slurm_accounting": (raw / "logs/logs/slurm-accounting.txt").read_text().strip(), "critical_wave_k128": 18 * 32 + 8 * 64, "clock_mhz_scenario_from_r24": 1410, "candidate_net_saving_us": None, "candidate_prediction_error_us": None}
data["required_clocks"] = {str(us): us * 1410 / data["critical_wave_k128"] for us in (25, 50)}
data["thirty_clock_equivalent_us"] = 30 * data["critical_wave_k128"] / 1410
data["operand_read_sensitivity"] = [{"assumed_effective_operand_B_per_clock": bw, "baseline_service_floor_clocks": max(1024, 98304 / bw), "n64_service_floor_clocks": max(1024, 131072 / bw), "added_floor_clocks": max(1024, 131072 / bw) - max(1024, 98304 / bw)} for bw in (96, 112, 128, 256)]
data["per_cta_k128"] = {"production": {"qgmma": 16, "groups": 4, "fence": 4, "completion_waits": 4, "ffma_per_thread": 128, "operand_smem_bytes": 98304, "tma_fill_bytes": 50176}, "n64_design": {"qgmma": 32, "groups": 8, "fence": 8, "completion_waits_steady": 8, "ffma_per_thread": 128, "operand_smem_bytes": 131072, "tma_fill_bytes": 50176}}
data["shapes"] = {}
for name, n, k in (("qkv", 9216, 4096), ("o", 4096, 8192)):
    tiles = 32 * (n // 128)
    blocks = tiles * (k // 128)
    data["shapes"][name] = {"m": 7988, "n": n, "k": k, "tiles": tiles, "cta_k128": blocks, "effective_flops": 2 * 7988 * n * k, "production_operand_smem_bytes": blocks * 98304, "n64_operand_smem_bytes": blocks * 131072, "added_operand_smem_bytes": blocks * 32768, "production_qgmma_collective_operations": blocks * 16, "n64_qgmma_collective_operations": blocks * 32, "logical_one_pass_io_bytes_including_fp32_scales": 7988 * k + n * k + 2 * 7988 * n + 4 * 7988 * (k // 128) + 4 * (n // 128) * (k // 128), "actual_hbm_bytes": None, "actual_nvlink_bytes": None}
for name in ("qkv", "o"):
    text = (root / f"{name}.sass").read_text()
    instructions = [(int(m[1], 16), m[2]) for m in re.finditer(r"/\*([0-9a-f]+)\*/\s+(.+?);", text)]
    # Exact repeated chunk starts at the backedge target and includes its branch.
    lo, hi = ((0x6A30, 0xC9F0) if name == "qkv" else (0x68B0, 0xC870))
    section = [s for pc, s in instructions if lo <= pc <= hi]
    assert len(section) == 1533, (name, len(section))
    assert sum("QGMMA" in s for s in section) == 64
    assert sum(s.startswith("FFMA") for s in section) == 1024
    assert sum("WARPGROUP.DEPBAR" in s for s in section) == 16
    assert sum("SYNCS.ARRIVE" in s for s in section) == 8
    data["shapes"][name]["steady_chunk"] = {"range": [hex(lo), hex(hi)], "slots": len(section), "qgmma": 64, "ffma": 1024, "wait0": 16, "empty_arrive": 8}
(root / "accounting.json").write_text(json.dumps(data, indent=2) + "\n")
print("PASS: patch identities, both 1533-slot steady chunks, operation and byte accounting")
