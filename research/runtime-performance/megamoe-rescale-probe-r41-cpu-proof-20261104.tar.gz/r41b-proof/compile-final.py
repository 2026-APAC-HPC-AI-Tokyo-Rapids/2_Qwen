from pathlib import Path
import subprocess,shutil,re,json,hashlib,time
root=Path.cwd(); work=root/'.r41b-work'; src=next((work/'.r40-proof/fixture/r32/r26').glob('DeepGEMM-*'))
dest=work/'final'; shutil.copytree(src/'deep_gemm',dest/'deep_gemm',dirs_exist_ok=True)
subprocess.run(['git','apply','--directory=.r41b-work/final','patches/deep-gemm-overlay/sm90-rescale-exposure-probe-r41.patch'],check=True)
rows={}
for variant in ('production','diagnostic'):
 source=dest/(variant+'.cu')
 # Original production proof source has only the production FC1 first-K define.
 text=(work/'.r40-proof/production.cu').read_text()
 if variant=='diagnostic': text='#define DG_R41_DIAGNOSTIC_NO_RESCALE 1\n#define sm90_fp8_mega_moe_impl sm90_fp8_mega_moe_rescale_exposure_diagnostic_impl\n'+text
 source.write_text(text)
 cmd=['/usr/local/cuda-13.4/bin/nvcc','--cubin','--std=c++20','--expt-relaxed-constexpr','--expt-extended-lambda','-O3','--diag-suppress=177','--ptxas-options=-v,-warn-spills','-gencode','arch=compute_90a,code=sm_90a','-I'+str(dest/'deep_gemm/include'),'-I'+str(work/'.r40-proof/fixture/r32/dependencies'),str(source),'-o',str(source.with_suffix('.cubin'))]
 begin=time.monotonic(); result=subprocess.run(cmd,capture_output=True,text=True); elapsed=time.monotonic()-begin
 (dest/(variant+'.compile.log')).write_text(result.stdout+result.stderr); assert result.returncode==0,result.stderr
 sass=subprocess.check_output(['/usr/local/cuda-13.4/bin/nvdisasm','-hex',str(source.with_suffix('.cubin'))],text=True);(dest/(variant+'.sass')).write_text(sass)
 encoding=b''.join(int(w,16).to_bytes(8,'little') for w in re.findall(r'/\* 0x([0-9a-f]{16}) \*/',sass))
 previous=(work/'r41-proof'/(variant+'.encoding')).read_bytes()
 assert encoding==previous,variant
 rows[variant]={'compile_seconds':elapsed,'registers':re.findall(r'Used (\d+) registers',result.stderr),'spills':re.findall(r'(\d+) bytes spill stores, (\d+) bytes spill loads',result.stderr),'stack':re.findall(r'(\d+) bytes stack frame',result.stderr),'encoding_sha256':hashlib.sha256(encoding).hexdigest(),'matches_accepted_r41_proof':True,'command':cmd}
 print(variant,json.dumps(rows[variant]),flush=True)
(dest/'compile-results.json').write_text(json.dumps(rows,indent=2)+'\n')
