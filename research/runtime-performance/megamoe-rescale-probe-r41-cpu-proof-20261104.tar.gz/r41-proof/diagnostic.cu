#define DG_R41_DIAGNOSTIC_NO_RESCALE 1
#define sm90_fp8_mega_moe_impl sm90_fp8_mega_moe_rescale_exposure_diagnostic_impl
#define DG_SM90_PREFILL_FC1_FIRST_K 1
#include <deep_gemm/impls/sm90_fp8_mega_moe.cuh>
extern "C" void* instantiate() { return reinterpret_cast<void*>(&deep_gemm::sm90_fp8_mega_moe_impl<8448,4096,1536,128,8,128,128,256,128,92160,1474560,4,64,64,256,132,1,cute::numeric_limits<float>::infinity(),true,0,true,true,false,false,false,true,false,true>); }
