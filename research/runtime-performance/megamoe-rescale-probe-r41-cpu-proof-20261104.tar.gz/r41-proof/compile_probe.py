"""CPU-only admission experiment, never imported or staged by serving."""
import collections
import difflib
import hashlib
import json
import re
import shutil
import subprocess
import time
from pathlib import Path

root = Path(__file__).resolve().parent
old = root / '.r40-proof'
include = root / 'trial/deep_gemm/include'
shutil.copytree(old / 'production/deep_gemm/include', include, dirs_exist_ok=True)
header = include / 'deep_gemm/impls/sm90_fp8_mega_moe.cuh'
before = header.read_text()
after = before
# Change only the two split-loop rescale callback bodies, preserving line numbers.
for marker in ('for (uint32_t i = h * kAccumPerThread / 8;', 'for (uint32_t i = h * kChunksPerWSF;'):
    start = after.index(marker)
    end = after.index('                            },', start)
    block = after[start:end]
    changed, count = re.subn(r'(final_accum\[i\*4\+[0-3]\] \*= [^;]+;)', r'if constexpr (!DG_R41_DIAGNOSTIC_NO_RESCALE) \1', block)
    assert count == 4
    after = after[:start] + changed + after[end:]
header.write_text(after)
(root / 'diagnostic-header.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='a/deep_gemm/include/deep_gemm/impls/sm90_fp8_mega_moe.cuh', tofile='b/deep_gemm/include/deep_gemm/impls/sm90_fp8_mega_moe.cuh')))
reports = {}
for name, diagnostic in (('production', False), ('diagnostic', True)):
    source = root / (name + '.cu')
    symbol = 'sm90_fp8_mega_moe_rescale_exposure_diagnostic_impl'
    source.write_text('#define DG_R41_DIAGNOSTIC_NO_RESCALE ' + str(int(diagnostic)) + '\n' + ('#define sm90_fp8_mega_moe_impl ' + symbol + '\n' if diagnostic else '') + (old / 'production.cu').read_text())
    cmd = ['/usr/local/cuda-13.4/bin/nvcc', '--cubin', '--std=c++20', '--expt-relaxed-constexpr', '--expt-extended-lambda', '-O3', '--diag-suppress=177', '--ptxas-options=-v,-warn-spills', '-gencode', 'arch=compute_90a,code=sm_90a', '-I' + str(include), '-I' + str(old / 'fixture/r32/dependencies'), str(source), '-o', str(source.with_suffix('.cubin'))]
    begin = time.monotonic()
    result = subprocess.run(cmd, capture_output=True, text=True)
    elapsed = time.monotonic() - begin
    (root / (name + '.compile.log')).write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stderr
    sass = subprocess.check_output(['/usr/local/cuda-13.4/bin/nvdisasm', '-hex', str(source.with_suffix('.cubin'))], text=True)
    (root / (name + '.sass')).write_text(sass)
    encoding = b''.join(int(w, 16).to_bytes(8, 'little') for w in re.findall(r'/\* 0x([0-9a-f]{16}) \*/', sass))
    (root / (name + '.encoding')).write_bytes(encoding)
    resources = subprocess.check_output(['/usr/local/cuda-13.4/bin/cuobjdump', '--dump-resource-usage', str(source.with_suffix('.cubin'))], text=True)
    (root / (name + '.resources.log')).write_text(resources)
    ops = re.findall(r'/\*[0-9a-f]+\*/\s+(?:@!?P\w+\s+)?([A-Z][A-Z0-9_.]*)', sass)
    reports[name] = {'command': cmd, 'elapsed_cpu_compile_seconds': elapsed, 'registers': re.findall(r'Used (\d+) registers', result.stderr), 'spill_store_load_bytes': re.findall(r'(\d+) bytes spill stores, (\d+) bytes spill loads', result.stderr), 'stack_bytes': re.findall(r'(\d+) bytes stack frame', result.stderr), 'encoding_bytes': len(encoding), 'encoding_sha256': hashlib.sha256(encoding).hexdigest(), 'max_register': max(map(int, re.findall(r'\bR(\d+)\b', sass))), 'opcodes': dict(collections.Counter(ops)), 'local_memory_ops': len(re.findall(r'\b(?:LDL|STL)\b', sass))}
    print(name, json.dumps(reports[name]), flush=True)
(root / 'compile-results.json').write_text(json.dumps(reports, indent=2) + '\n')
