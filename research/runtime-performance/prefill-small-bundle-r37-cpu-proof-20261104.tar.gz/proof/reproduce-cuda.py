from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import re
import shutil
import subprocess

root = Path(__file__).resolve().parent
out = root / 'proof'
out.mkdir(exist_ok=True)
r36 = root / 'r36'
r32 = root / 'r32'
source = next((r32 / 'r26').glob('DeepGEMM-*'))
oldprefix = '/tmp/claude-1000/-home-USER-2026-APAC-HPC-AI-Tokyo-Rapids-2-Qwen/00000000-0000-0000-0000-000000000000/scratchpad/codex-scratch/r36'
commands = json.loads((r36 / 'compile.json').read_text())
summary = json.loads((r36 / 'summary.json').read_text())
names = ['qkv', 'o', 'qkv-first', 'o-first', 'rope-int32_t', 'rope-int64_t', 'rope-int32_t-fixed', 'rope-int64_t-fixed']

def build(name):
    base = name.replace('-first', '').replace('-fixed', '')
    text = (r36 / 'compile' / (name + '.cu')).read_text().replace(oldprefix, str(r36))
    cu = out / (name + '.cu')
    cu.write_text(text)
    cmd = commands[base]['cmd']
    inc = r36/'dense-probe-include' if name.endswith('-first') else source/'deep_gemm/include'
    cmd = [x.replace(oldprefix, str(r36)) for x in cmd]
    cmd = ['-I'+str(inc) if x.startswith('-I') and 'baseline/deep_gemm/include' in x else x for x in cmd]
    cmd = [x.replace(str(r36/'r32/r32/dependencies'), str(r32/'dependencies')) for x in cmd]
    cmd = [str(cu) if x == str(r36/'compile'/(base+'.cu')) else str(cu.with_suffix('.cubin')) if x == str(r36/'compile'/(base+'.cubin')) else x for x in cmd]
    result = subprocess.run(cmd, capture_output=True, text=True)
    cu.with_suffix('.log').write_text(result.stdout + result.stderr)
    assert result.returncode == 0, result.stderr
    sass = subprocess.check_output(['/usr/local/cuda-13.4/bin/nvdisasm', '-hex', str(cu.with_suffix('.cubin'))], text=True)
    cu.with_suffix('.sass').write_text(sass)
    words = re.findall(r'/\* 0x([0-9a-f]{16}) \*/', sass)
    enc = b''.join(int(w,16).to_bytes(8,'little') for w in words)
    digest = hashlib.sha256(enc).hexdigest()
    assert digest == summary['builds'][name]['encoding_sha256'], (name, digest)
    record = {'command': cmd, 'encoding_sha256': digest, 'encoding_bytes': len(enc), 'instructions': len(enc)//16, 'registers': re.findall(r'Used (\d+) registers', result.stderr), 'spill': re.findall(r'(\d+) bytes spill stores, (\d+) bytes spill loads', result.stderr), 'r36_encoding_identical': True}
    assert record['spill'] == [('0', '0')]
    print(name, record, flush=True)
    return name, record

with ThreadPoolExecutor(max_workers=3) as pool:
    records = dict(pool.map(build, names))
(out/'cuda.json').write_text(json.dumps(records, indent=2)+'\n')
shutil.copy(r36/'div448-proof.cpp', out/'div448-proof.cpp')
cmd = ['g++','-O3','-std=c++20','-march=native','-fno-fast-math','-ffp-contract=off',str(out/'div448-proof.cpp'),'-o',str(out/'div448-proof')]
subprocess.run(cmd, check=True)
result = subprocess.run([str(out/'div448-proof')], capture_output=True, text=True, check=True)
(out/'div448-proof.log').write_text(result.stdout)
print(result.stdout, flush=True)
