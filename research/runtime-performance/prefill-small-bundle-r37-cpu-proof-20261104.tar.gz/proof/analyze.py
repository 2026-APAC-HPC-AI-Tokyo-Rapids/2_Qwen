from pathlib import Path
from collections import Counter
import re,json,hashlib
root=Path(__file__).resolve().parent

def parse(p):
 rows=[];labels={};pending=[]
 for line in p.read_text().splitlines():
  m=re.match(r'(\.L_x_\d+):',line.strip())
  if m:pending.append(m[1])
  m=re.search(r'/\*([0-9a-f]+)\*/\s+((?:@\S+\s+)?([A-Z][A-Z0-9_.]*)\s*.*?)\s*;.*?/\* 0x([0-9a-f]{16}) \*/',line)
  if m:
   pc=int(m[1],16)
   for label in pending:labels[label]=pc
   pending=[];rows.append({'pc':pc,'s':m[2].strip(),'op':m[3],'word':m[4]})
 return rows,labels

def cat(op):
 op=op.split('.')[0]
 if op in ('QGMMA','HGMMA','HMMA','MMA'):return 'tensor'
 if op in ('FMUL','FFMA'):return 'fmul_ffma'
 if op in ('LDS','LDG','LDSM','LDGSTS','LD'):return 'lds_ldg'
 if op in ('BAR','SYNCS','WARPGROUP','DEPBAR','MEMBAR','FENCE','LDGDEPBAR','WARPSYNC'):return 'sync'
 if op.startswith(('I','UI','LEA','ULEA','LOP','ULOP','SHF','USHF','BMSK','UBMSK','FLO','UFLO','POPC','UPOPC','PLOP','UPLOP','PSETP','UPSETP','S2UR','R2UR','VIADD','VIMNMX','PRMT','UPRMT')) or op in ('SEL','USEL','SGXT','USGXT'):return 'integer'
 return 'other'
report={}
for p in sorted((root).glob('*.sass')):
 rows,labels=parse(p);counter=Counter(r['op'].split('.')[0] for r in rows);edges=[]
 for r in rows:
  m=re.search(r'BRA.*`\((\.L_x_\d+)\)',r['s'])
  if m and labels.get(m[1],1e100)<=r['pc']:edges.append({'start':hex(labels[m[1]]),'end':hex(r['pc']),'span':(r['pc']-labels[m[1]])//16+1,'target':m[1]})
 (root/f'{p.stem}.isa').write_text('\n'.join(f"{r['pc']:05x} {r['s']}" for r in rows)+'\n')
 report[p.stem]={'count':len(rows),'opcode':dict(counter),'edges':edges}
(root/'inventory.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:{'count':v['count'],'edges':v['edges']} for k,v in report.items()},indent=2))
