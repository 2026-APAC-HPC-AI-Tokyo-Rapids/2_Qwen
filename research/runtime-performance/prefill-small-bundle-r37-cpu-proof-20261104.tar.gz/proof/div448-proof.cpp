#include <bit>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <limits>
int main() {
 const float rc=std::bit_cast<float>(0x3b124925u);
 const float refined=std::fma(std::fma(-448.0f,rc,1.0f),rc,rc);
 std::printf("reciprocal %08x refined %08x\n",std::bit_cast<unsigned>(rc),std::bit_cast<unsigned>(refined));
 uint64_t count=0,errors=0;unsigned first=0;
 const uint32_t begin=std::bit_cast<uint32_t>(1.0e-10f);
 for(uint32_t b=begin;b<0x7f800000u;b++) {
  const float x=std::bit_cast<float>(b);
  const float q0=std::fma(x,rc,0.f);
  const float error=std::fma(q0,-448.f,x);
  const float q=std::fma(rc,error,q0);
  const float ref=x/448.f;
  if(std::bit_cast<uint32_t>(q)!=std::bit_cast<uint32_t>(ref)){if(!errors)first=b;errors++;}
  count++;
 }
 std::printf("tested %llu positive finite inputs >=1e-10, errors %llu, first %08x; +inf handled by explicit selection\n",(unsigned long long)count,(unsigned long long)errors,first);
 return errors!=0;
}
