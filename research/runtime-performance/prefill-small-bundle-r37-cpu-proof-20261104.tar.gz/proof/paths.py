from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
x={'__file__':str(root/'analyze.py')};s=(root/'analyze.py').read_text();exec(s[:s.index('report={}')],x)
result={}
for n in ['rope-int64_t','rope-int64_t-fixed','rope-int32_t','rope-int32_t-fixed']:
 rows,labels=x['parse'](root/f'{n}.sass');index={r['pc']:i for i,r in enumerate(rows)}
 branches=[r for r in rows if r['op'].startswith('BRA')];result[n]={}
 for h in ['Q','K','V']:
  choices=[h=='Q',True,h=='V',True,False,h=='Q',True,h=='Q',True,False]
  decisions={b['pc']:v for b,v in zip(branches,choices)};path=[];i=0
  while i<len(rows):
   r=rows[i];path.append(r)
   if r['op']=='EXIT':break
   if decisions.get(r['pc'],False):i=index[labels[re.search(r'`\(([^)]+)\)',r['s'])[1]]]
   else:i+=1
  result[n][h]={'count':len(path),'opcode':dict(x['Counter'](r['op'].split('.')[0] for r in path)),'category':dict(x['Counter'](x['cat'](r['op']) for r in path))}
(root/'paths.json').write_text(json.dumps(result,indent=2))
for n,heads in result.items():print(n,[(h,v['count']) for h,v in heads.items()])
