# Round 37 CPU proof only

The bundle was stopped before deployment because the pinned DeepGEMM host cannot pass an independent first-promotion flag into the same dense template/JIT code. These are fresh reproductions of the round 36 audit probes, not production overlays or successful GPU gates.

All 10 fresh encoded SASS streams exactly match round 36, including both controls and probes. cuda.json records commands and ptxas resources. triton.json records Triton 3.7 metadata, explicit GPUTarget(cuda,90,32), and 16-byte pointer alignment. No compiled kernel was loaded or launched. div448-proof.cpp exhaustively checks positive finite FP32 at least float32(1e-10), with IEEE division and hardware FMA. The +Inf selector is in the onepass-div448 source in the input r36 archive; the finite proof does not establish GPU FTZ/NaN/output equivalence.

Inputs: r32-cpu-proof-20261104.tar.gz, SHA256 e2faa2a495c306729bf41f711bd28e5cdceb1a206454ef4df04f7ceaf21f8015; r36-cpu-proof-20261104.tar.gz, SHA256 650178e521c1fc5f23b290e5590f49a1053aae6640fc8452a289e0e9052894e8. Both were read from the original codex-scratch archives without modification.

To reproduce, extract the original r32 archive into a fresh workspace (it contains r32/), extract the original r36 archive into workspace/r36/, and place reproduce-cuda.py and reproduce-triton.py in workspace/. Rename them or retain their names; each uses its own parent as workspace. Run python3 reproduce-cuda.py. Then use uv run --no-project --python 3.12 --with triton==3.7.0 python reproduce-triton.py, setting TRITON_PTXAS_PATH=/usr/local/cuda-13.4/bin/ptxas and TRITON_CACHE_DIR to a directory in that workspace. The scripts regenerate proof/; the original r36 archive paths are translated to the new workspace. CUDA dependencies come from r32/, r36/jit-include, and the read-only tvm_ffi include cache listed in commands. No source mirror writes occur.

The retained helper scripts analyze static slots and source-defined branch paths only. Their counts do not measure runtime issue, hidden latency or serving throughput. All code size values refer to 16-byte encoded instruction slots, not the entire cubin file.
