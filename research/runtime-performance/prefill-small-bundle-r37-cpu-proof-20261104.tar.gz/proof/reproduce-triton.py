from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess
import triton
from triton.backends.compiler import GPUTarget
from triton.compiler import ASTSource
root = Path(__file__).resolve().parent
out = root/'proof'
assert triton.__version__ == '3.7.0'
records = {}
for name in ('onepass', 'onepass-div448'):
    source = root/'r36'/(name+'-body.py')
    spec = importlib.util.spec_from_file_location(name, source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    signature = {'O':'*bf16','R':'*bf16','W':'*bf16','G':'*bf16','Q':'*fp8e4nv','S':'*fp32','IDS':'*i64','TW':'*fp32','num_tokens':'i32','eps':'fp32'}
    kernel = triton.compile(ASTSource(module._onepass_moe_input, signature=signature, constexprs={'BLOCK_M':64}, attrs={(i,): [['tt.divisibility',16]] for i in range(8)}), target=GPUTarget('cuda',90,32), options={'num_warps':8,'num_stages':3})
    for ext in ('cubin','ptx','llir','ttgir'):
        data = kernel.asm[ext]
        (out/(name+'.'+ext)).write_bytes(data if isinstance(data, bytes) else data.encode())
    sass = subprocess.check_output(['/usr/local/cuda-13.4/bin/nvdisasm', '-hex', str(out/(name+'.cubin'))], text=True)
    (out/(name+'.sass')).write_text(sass)
    words = re.findall(r'/\* 0x([0-9a-f]{16}) \*/', sass)
    enc = b''.join(int(w,16).to_bytes(8,'little') for w in words)
    expected = json.loads((root/'r36/summary.json').read_text())['builds'][name]
    digest = hashlib.sha256(enc).hexdigest()
    assert digest == expected['encoding_sha256'], (name,digest)
    resource = subprocess.check_output(['/usr/local/cuda-13.4/bin/cuobjdump', '-res-usage', str(out/(name+'.cubin'))], text=True)
    assert 'LOCAL:0' in resource
    records[name] = {'triton':triton.__version__, 'metadata':str(kernel.metadata), 'encoding_sha256':digest,'instructions':len(enc)//16,'encoding_bytes':len(enc), 'resource':resource, 'r36_encoding_identical':True}
    print(name, records[name], flush=True)
(out/'triton.json').write_text(json.dumps(records,indent=2)+'\n')
