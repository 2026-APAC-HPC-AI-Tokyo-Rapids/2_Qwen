Round 42 phase-1 evidence, parent ede08bd. No candidate and no GPU execution.

Raw run 41875058470 stays at /srv/qwen-artifacts/41875058470/1/results/results/megamoe-rescale-probe/.
The evidence records raw source, cubin and per-rank JSON SHA256, and all twelve ELF text hashes.
Disassemble the recorded production cubin with /usr/local/cuda-13.4/bin/nvdisasm -hex.
For local source/dependencies, extract megamoe-mainloop-r40-cpu-proof-20261104.tar.gz.
Verify source-provenance.json patch hashes and order against the repository.
Apply the recorded r41 patch to its production tree; final header must be 1821ba235eddd2c1162a05418e282d22efd9095e4045731291a1e0c7699d81f3.
Use local-production.command.json, relocating temporary paths, to compile production only.
The local encoded SASS matches f157a6dd; it is not the run CUDA13.0 text 92b487c8.
Run audit.py through uv after relocating ROOT and setting the two SASS inputs and command/log files as recorded.
It checks 224 WGMMA instructions, 64 FMUL per steady half, full production source identity, and twelve matching ELF text sections.
Scalar reaching definitions are straight-line slices. The repeated FC1 chunk K8 entry is separate from the cyclic K16/K24 edge, whose instructions are explicitly retained.
No static issue count is converted into measured latency.
The note supplies the decision and interpretation; existing raw run output is not duplicated.
