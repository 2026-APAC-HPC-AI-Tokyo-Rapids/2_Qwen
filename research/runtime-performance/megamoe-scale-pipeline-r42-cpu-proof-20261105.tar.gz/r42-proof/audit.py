import hashlib
import json
import re
import struct
import statistics
from pathlib import Path

ROOT = Path('/tmp/r42-analysis')
RAW = Path('/srv/qwen-artifacts/41875058470/1/results/results/megamoe-rescale-probe')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def parse(path):
    rows = []
    for line in path.read_text().splitlines():
        match = re.match(r'\s*/\*([0-9a-f]+)\*/\s+(.*?)\s*;.*', line)
        if match:
            rows.append((int(match[1], 16), match[2]))
    return rows

def text_hash(path):
    b = path.read_bytes()
    offset = struct.unpack_from('<Q', b, 40)[0]
    size, count, strings = struct.unpack_from('<HHH', b, 58)
    sections = [struct.unpack_from('<IIQQQQIIQQ', b, offset+i*size) for i in range(count)]
    st = sections[strings]
    names = b[st[4]:st[4]+st[5]]
    text = [b[sec[4]:sec[4]+sec[5]] for sec in sections if names[sec[0]:].split(b'\0',1)[0].startswith(b'.text.')]
    assert len(text) == 1
    return hashlib.sha256(text[0]).hexdigest()

def encoding(path):
    return b''.join(int(word, 16).to_bytes(8, 'little') for word in re.findall(r'/\* 0x([0-9a-f]{16}) \*/', path.read_text()))

def audit(path):
    rows = parse(path)
    q = [(pc, op) for pc, op in rows if op.startswith('QGMMA.')]
    assert len(q) == 224
    previous = {}
    definitions = {}
    for pc, op in rows:
        match = re.match(r'(?:@!?P\d+ )?([A-Z0-9_.]+) (R\d+), (.*)', op)
        if not match:
            continue
        opcode, dest, args = match.groups()
        sources = re.findall(r'\bR\d+\b', args)
        definitions[pc] = {'pc': hex(pc), 'instruction': op, 'inputs': [previous.get(reg) for reg in sources]}
        previous[dest] = pc
    def slice_for(pc, seen):
        if pc is None or pc in seen or pc not in definitions:
            return
        node = definitions[pc]
        if not node['instruction'].startswith(('FMUL ', 'MUFU.RCP ', 'MOV ', 'LDS ', 'LDG.E.CONSTANT ')):
            return
        seen.add(pc)
        if node['instruction'].startswith(('LDS ', 'LDG.E.CONSTANT ')):
            return
        for parent in node['inputs']:
            slice_for(parent, seen)
    blocks = []
    for i in range(28):
        groups = [q[i*8:i*8+4], q[i*8+4:i*8+8]]
        # The peeled first chunk, repeated steady chunk, FC2.
        section = 'fc1_peeled' if i < 8 else ('fc1_repeat' if i < 16 else 'fc2')
        index = i if i < 8 else (i-8 if i < 16 else i-16)
        low = q[i*8-1][0] if i not in (0,16) else (0x1a00 if i==0 else 0x12000)
        hi = groups[1][-1][0]
        block = {'section': section, 'unrolled_k': index, 'halves': []}
        block['full_stage_wait'] = [[hex(pc),op] for pc,op in rows if low < pc <= groups[0][0][0] and 'SYNCS.PHASECHK' in op]
        block['stage_release'] = [[hex(pc),op] for pc,op in rows if low < pc <= hi and 'SYNCS.ARRIVE' in op]
        for h, group in enumerate(groups):
            start = low if h == 0 else groups[0][-1][0]
            end = group[0][0]
            accum_low, accum_high = (88,151) if h==0 else (24,87)
            muls=[]
            roots={}
            for pc,op in rows:
                m = re.match(r'FMUL (R\d+), (R\d+)(?:\.reuse)?, (R\d+)(?:\.reuse)?$',op)
                if low < pc < end and m and accum_low <= int(m[1][1:]) <= accum_high:
                    assert m[1] in (m[2],m[3])
                    muls.append((pc,op))
                    input_pos=1 if m[1]==m[2] else 0
                    root=definitions[pc]['inputs'][input_pos]
                    roots[root]=True
            if not (section=='fc1_peeled' and index==0) and not (section=='fc2' and index==0):
                assert len(muls)==64,(section,index,h,len(muls))
            seen=set()
            for root in roots:
                slice_for(root,seen)
            block['halves'].append({
                'half': h,
                'wait': [[hex(pc),op] for pc,op in rows if start < pc < end and op.startswith('WARPGROUP.DEPBAR')],
                'accumulator_fmul_count':len(muls),
                'accumulator_fmul_first_last':[hex(muls[0][0]),hex(muls[-1][0])] if muls else None,
                'ratio_definitions':[definitions[pc]['pc'] for pc in roots if pc is not None],
                'scalar_reaching_definitions':[{k:v for k,v in definitions[pc].items() if k!='inputs'} for pc in sorted(seen)],
                'fence': [[hex(pc),op] for pc,op in rows if start < pc < end and op=='WARPGROUP.ARRIVE'],
                'wgmma': [[hex(pc),op] for pc,op in group],
                'previous_same_half_last':hex(q[i*8+h*4-5][0]) if i not in (0,16) else None,
            })
        if section.startswith('fc1') and not (section=='fc1_peeled' and index==0):
            assert set(block['halves'][0]['ratio_definitions']) == set(block['halves'][1]['ratio_definitions'])
        blocks.append(block)
    is_run = path.name == 'run-production.sass'
    # The repeated chunk enters through two edges: the peeled chunk and the backedge.
    # Do not use sequential reaching definitions for the cyclic edge.
    boundary_low, boundary_high, entry = (0xddd0, 0xdff0, 0x79c0) if is_run else (0xdd00, 0xdf30, 0x7a90)
    boundary = [[hex(pc), op] for pc, op in rows if boundary_low <= pc <= boundary_high]
    blocks[8]['entry_context'] = 'Sequential scalar slices describe K8 only; K16/K24 use the boundary prefetch and jump below.'
    blocks[8]['backedge_instructions'] = boundary
    blocks[8]['backedge_entry_pc'] = hex(entry)
    blocks[8]['backedge_previous_same_half_last'] = [hex(q[15*8+3][0]), hex(q[15*8+7][0])]
    enc=encoding(path)
    return {'encoding_sha256':hashlib.sha256(enc).hexdigest(),'encoding_bytes':len(enc),'max_register':max(map(int,re.findall(r'\bR(\d+)\b',path.read_text()))),'ldl_stl_count':sum(bool(re.search(r'\b(?:LDL|STL)\b',op)) for _,op in rows),'blocks':blocks,'stage_producer_excerpt':[[hex(pc),op] for pc,op in rows if (0x1e980<=pc<=0x1eac0 or 0x214d0<=pc<=0x21690)] if is_run else None}

run=audit(ROOT/'run-production.sass')
local=audit(ROOT/'local-production.sass')
assert local['encoding_sha256']=='f157a6dddb926f5944f751e46448afb69091eb9cfbcccd17e21fe852205e8c41'
summary=json.loads((RAW/'summary.json').read_text())
paths=list(RAW.glob('worker-*/rank-*.json'))
assert len(paths)==12
identities=[]
for rank_path in sorted(paths):
    rank=json.loads(rank_path.read_text())
    assert rank['status']=='complete'
    assert rank['runtime_header_sha256']=='1821ba235eddd2c1162a05418e282d22efd9095e4045731291a1e0c7699d81f3'
    assert len(rank['samples'])==24
    med=statistics.median(r['production_us']-r['diagnostic_us'] for r in rank['samples'])
    assert med==rank['median_delta_us']
    expected=next(g for g in summary['gpus'] if g['gpu_uuid']==rank['gpu_uuid'])
    assert expected['median_delta_us']==med
    assert expected['sm_clock_mhz_mean']==statistics.mean(rank['sm_clock_samples_mhz'])
    cu=next(p for p in (rank_path.parent/('jit-rank-'+rank_path.stem.split('-')[-1])/'cache').glob('kernel.sm90_fp8_mega_moe.*/kernel.cu') if '#define DG_R41_DIAGNOSTIC_NO_RESCALE 1' not in p.read_text())
    assert sha(cu)==rank['jit']['production']['generated_source_sha256']
    identities.append({'rank_json':str(rank_path),'rank_sha256':sha(rank_path),'source':str(cu),'source_sha256':sha(cu),'cubin_sha256':sha(cu.with_suffix('.cubin')),'text_sha256':text_hash(cu.with_suffix('.cubin'))})
assert len({i['text_sha256'] for i in identities})==1
assert len({i['source_sha256'] for i in identities})==1
assert len({g['gpu_uuid'] for g in summary['gpus']})==12
assert statistics.median(g['median_delta_us'] for g in summary['gpus'])==summary['median_12gpu_delta_us']
clocks=[g['sm_clock_mhz_mean'] for g in summary['gpus']]
result={'schema_version':'megamoe-scale-pipeline-r42/1','decision':'NO-GO','basis':'Phase 1 does not support a precision-preserving design saving at least 30 us/layer. Dynamic scale subpath exposure remains unidentified.','parent_commit':'ede08bd','raw_run':'41875058470','runtime_header_sha256':'1821ba235eddd2c1162a05418e282d22efd9095e4045731291a1e0c7699d81f3','probe_summary_sha256':sha(RAW/'summary.json'),'all_12_production_identity':identities,'scale_path_upper_bound_us':summary['median_12gpu_delta_us'],'target_us':30,'target_fraction_of_bound':30/summary['median_12gpu_delta_us'],'steady_cta_k128_equivalents':292358,'target_exposed_clocks_by_gpu':[30*132*f/292358 for f in clocks],'attainable_saving_us':None,'prediction_error_us':None,'run_cuda_13_0_88':run,'local_cuda_13_4_92':local,'local_command':json.loads((ROOT/'local-production.command.json').read_text()),'local_compile_log':(ROOT/'local-production.compile.log').read_text(),'register_budget':{'launch':168,'math':224,'math_highwater_free_span_local':17,'dispatch':48,'loader':40,'total_assigned':62976,'source_assert_limit':64512,'next_math_232_total':65024,'naive_full_product_plus_sum_accumulators':256},'new_gpu_measurement':False,'candidate_implemented':False,'require_build':False}
(ROOT/'evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print('run',run['encoding_sha256'],run['encoding_bytes'],run['max_register'])
print('local',local['encoding_sha256'],local['encoding_bytes'],local['max_register'])
print('target clocks',min(result['target_exposed_clocks_by_gpu']),max(result['target_exposed_clocks_by_gpu']))
for name,data in [('run',run),('local',local)]:
    print(name)
    for b in data['blocks']:
        print(b['section'],b['unrolled_k'],' '.join(f"h{h['half']} wait:{','.join(x[0] for x in h['wait'])} FMUL:{h['accumulator_fmul_first_last']} Q:{h['wgmma'][0][0]}..{h['wgmma'][-1][0]}" for h in b['halves']))
