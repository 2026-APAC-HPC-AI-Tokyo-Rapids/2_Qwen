from pathlib import Path
import re,json,hashlib
root=Path(__file__).resolve().parent
records=json.loads((root/'compile.json').read_text())
expected=json.loads((root/'expected-encodings.json').read_text())
summary={}
for shape in ('qkv','o'):
 for variant in ('production','candidate','diagnostic'):
  stem=f'{shape}-{variant}';r=records[stem];sass=(root/f'{stem}.sass').read_text();log=(root/f'{stem}.log').read_text()
  assert r['exit_code']==0 and r['local_ops']==0 and not r['serialization_warning']
  assert r['encoding_sha256']==expected[stem]
  assert '0 bytes stack frame, 0 bytes spill stores, 0 bytes spill loads' in log
  ins=[(int(pc,16),code.strip()) for pc,code in re.findall(r'/\*([0-9a-f]+)\*/\s+(.+?)\s*/\* 0x[0-9a-f]+ \*/',sass)]
  q=[x for x in ins if 'QGMMA.' in x[1]];w0=[x for x in ins if 'WARPGROUP.DEPBAR.LE gsb0, 0x0 ;' in x[1]];w1=[x for x in ins if 'WARPGROUP.DEPBAR.LE gsb0, 0x1 ;' in x[1]]
  ffma=[x for x in ins if re.search(r'\bFFMA\b',x[1])]
  gprs=[int(v) for v in re.findall(r'\bR(\d+)\b',sass)]
  assert len(q)==r['qgmma'] and len(w0)==r['wait0'] and len(w1)==r['wait1'] and len(ffma)==r['ffma']
  if variant=='candidate':assert (len(q),len(w0),len(w1),len(ffma))==(256,2,62,2048)
  if variant=='diagnostic':assert (len(q),len(w0),len(w1),len(ffma))==(64,1,8,0)
  if variant=='production':assert (len(q),len(w0),len(w1),len(ffma))==(128,32,0,2048)
  words=re.findall(r'/\* 0x([0-9a-f]{16}) \*/',sass)
  summary[stem]={'launch_registers':168,'math_budget':232,'max_gpr':max(gprs),'stack':0,'spill_stores':0,'spill_loads':0,'ldl_stl':0,'C75xx':False,'qgmma':len(q),'wait0':len(w0),'wait1':len(w1),'ffma':len(ffma),'encoded_bytes':8*len(words),'encoding_sha256':r['encoding_sha256']}
  if variant=='candidate':
   out=[]
   for ix,(pc,code) in enumerate(ins):
    if 'WARPGROUP.DEPBAR.LE' not in code:continue
    # Include the immediately preceding tensor group and next issuing group,
    # with all promotion instructions between them. PCs are compile evidence,
    # not runtime cycle counts.
    before=max((j for j in range(ix) if 'QGMMA.' in ins[j][1]),default=ix)
    after=next((j for j in range(ix+1,len(ins)) if 'QGMMA.' in ins[j][1]),len(ins))
    section=ins[before:after+1]
    f=[(p,c) for p,c in section if re.search(r'\bFFMA\b',c)]
    out.append({'wait_pc':hex(pc),'wait':code,'previous_qgmma_pc':hex(ins[before][0]),'next_qgmma_pc':hex(ins[after][0]) if after<len(ins) else None,'ffma_count_until_next_issue':len(f)})
   (root/f'{shape}-candidate-chains.json').write_text(json.dumps(out,indent=2)+'\n')
(root/'sass-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
