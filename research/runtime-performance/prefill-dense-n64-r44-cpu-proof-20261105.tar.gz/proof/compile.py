from pathlib import Path
import subprocess,time,json,re,hashlib,concurrent.futures
root=Path(__file__).resolve().parent;out=root;work=root.parent/'work'
inc=work/'.r40-proof/production/deep_gemm/include';dep=work/'.r40-proof/fixture/r32/dependencies'
def build(shape,variant):
 source=(root/f'{shape}-production.cu').read_text();p=out/f'{shape}-{variant}'
 if variant!='production':p.with_suffix('.cu').write_text(source)
 flags=['-DDG_SM90_PREFILL_DENSE_FIRST_K=1']
 if variant=='candidate':flags+=['-DDG_SM90_PREFILL_DENSE_N64=1']
 if variant=='diagnostic':flags+=['-DDG_R44_DIAGNOSTIC_NO_PROMOTION=1','-Dsm90_fp8_gemm_1d2d_impl=sm90_fp8_gemm_promotion_diagnostic_impl']
 cmd=['/usr/local/cuda-13.4/bin/nvcc','--cubin','--std=c++20','--expt-relaxed-constexpr','--expt-extended-lambda','-O3','--diag-suppress=177','--ptxas-options=-v,-warn-spills','-gencode','arch=compute_90a,code=sm_90a','-I'+str(inc),'-I'+str(dep),*flags,str(p.with_suffix('.cu')),'-o',str(p.with_suffix('.cubin'))]
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,text=True);p.with_suffix('.log').write_text(r.stdout+r.stderr)
 record={'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start}
 if not r.returncode:
  sass=subprocess.check_output(['/usr/local/cuda-13.4/bin/nvdisasm','-hex',str(p.with_suffix('.cubin'))],text=True);p.with_suffix('.sass').write_text(sass)
  resource=subprocess.check_output(['/usr/local/cuda-13.4/bin/cuobjdump','-res-usage',str(p.with_suffix('.cubin'))],text=True);p.with_suffix('.resources').write_text(resource)
  record.update(resources=resource,local_ops=len(re.findall(r'\b(?:LDL|STL)\b',sass)),qgmma=len(re.findall(r'\bQGMMA\.',sass)),wait0=len(re.findall(r'WARPGROUP.DEPBAR.LE gsb0, 0x0 ;',sass)),wait1=len(re.findall(r'WARPGROUP.DEPBAR.LE gsb0, 0x1 ;',sass)),ffma=len(re.findall(r'\bFFMA\b',sass)),serialization_warning=bool(re.search(r'C75\d\d',r.stderr)))
  words=re.findall(r'/\* 0x([0-9a-f]{16}) \*/',sass);record['encoding_sha256']=hashlib.sha256(b''.join(int(w,16).to_bytes(8,'little') for w in words)).hexdigest()
 print(shape,variant,record,flush=True);return f'{shape}-{variant}',record
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 results=dict(pool.map(lambda pair:build(*pair),[(s,v) for s in ('qkv','o') for v in ('production','candidate','diagnostic')]))
(out/'compile.json').write_text(json.dumps(results,indent=2)+'\n')
