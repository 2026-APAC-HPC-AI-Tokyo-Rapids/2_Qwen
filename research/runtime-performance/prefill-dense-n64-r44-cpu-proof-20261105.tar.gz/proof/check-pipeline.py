from pathlib import Path
import json
import resource
import subprocess

root = Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
original = (root / 'production-dense.cuh').read_text()
start = original.index('    auto advance_pipeline =')
advance = original[start:original.index('\n    };', start) + len('\n    };')]
results = {}
for version, path in [('final', root / 'patched-dense.cuh'), ('rejected-k-index', root / 'rejected-k-index/dense.cuh')]:
    header = path.read_text()
    start = header.index('                        // Release the OLD stage')
    body = header[start:header.index('\n                    } else\n#endif', start)]
    source = (root / 'pipeline-harness.cpp').read_text().replace('// ADVANCE_PIPELINE', advance).replace('// R44_BODY', body)
    for diagnostic in (False, True):
        key = version + ('-diagnostic' if diagnostic else '-candidate')
        cpp, executable = root / (key + '.cpp'), root / (key + '.cpu')
        cpp.write_text(source)
        command = ['g++', '-std=c++20', '-O2', '-DDG_R44_DIAGNOSTIC_NO_PROMOTION=' + str(int(diagnostic)), str(cpp), '-o', str(executable)]
        subprocess.run(command, check=True, capture_output=True)
        result = subprocess.run([str(executable)], check=False, capture_output=True, text=True)
        assert (result.returncode == 0) == (version == 'final')
        results[key] = {'compile_command': command, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr, 'scope': 'CPU logical WGMMA/TMA stubs execute the actual device loop; not GPU arithmetic'}
        executable.unlink()
(root / 'pipeline-simulation.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
