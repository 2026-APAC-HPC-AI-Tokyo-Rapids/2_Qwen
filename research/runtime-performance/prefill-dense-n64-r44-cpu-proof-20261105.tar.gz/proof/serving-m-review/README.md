Parent review correction of the uncommitted round 44 implementation.

The initial proof at the archive root records the earlier implementation and
its CUDA 13.4 compilation. This review does not compile CUDA, build images,
start containers, submit jobs, commit, push or run GPUs. The device header hash
is unchanged, so the original SHAPE_M=0 resource/SASS evidence remains applicable.

findings.json gives the final M choices. The first 4001-row dense dispatch is
AIPerf warmup, not the scored profiling phase. The pinned image's AIPerf worker
adds a warmup system message. The model template yields 3994/3995 user-only
rows from 3986/3987 content tokens, with another seven tokens for that warmup
system message. Profile pair timing therefore stays at 7988, single timing and
prewarm add 3994, and GPU numerical admission also covers 4001/8002/8003.
Rare profiling pair sizes 7989/7990 and warmup pair sizes 8003/8004 are possible
sums; the archived logs do not retain exact rare-pair ordering. Page counters
4032/8064 are admission accounting, not dense tensor padding.

Read-only ssh firmus obtains the model tokenizer configuration and a seek/read
stream of the pinned image. The local PySquashfsImage reader only reads that
stream; it neither extracts nor starts a container on the server. Saved image
AIPerf source proves warmup and payload ISL semantics. The tokenizer hashes
match the archived tokenizer.sha256; the 11 MB tokenizer.json itself remains
in its existing source of truth and is not duplicated in this archive.

serving-m-tokenization.json contains the complete 12800-payload raw/template
counts. client-isl-distribution.json and phase-timestamps.json summarize actual
recorded requests. SGLang source excerpts and serving log excerpts show the page
rounding and row-preserving QKV/O path. The clock offset of the server log is
inferred as UTC+8 from its first warmup line and the epoch timestamps; JST in
the phase file is UTC+9. No server was contacted to run an inference request.

The final tests execute the actual host source generator over several M values,
verify exact flag-off bytes and an M-independent cache source, retain unchanged
TMA producer/epilogue and descriptors, emulate final partial tiles, exercise
all five M numerical-admission requirements with CPU fixtures, and execute
prewarm/dispatch with doubles. GPU numeric and timing results remain unknown.
The v2 real sbatch block is also exercised with a stub timeout in four CPU-only
cases, never invoking a scheduler. Final suite logs and current repository-input
hashes accompany these files. Older root logs describe the initial implementation.
