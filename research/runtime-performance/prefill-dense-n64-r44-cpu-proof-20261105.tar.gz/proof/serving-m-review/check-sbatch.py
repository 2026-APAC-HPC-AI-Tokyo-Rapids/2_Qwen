from pathlib import Path
import json
import os
import subprocess
import tempfile

repo = Path.cwd()
root = Path(__file__).resolve().parent
batch = (repo / 'platforms/firmus/framework-comparison/sglang.sbatch').read_text()
begin = batch.index('# Dense N64 gate:')
block = batch[begin:batch.index('# FC1 first-K is pinned', begin)]
records = {}
with tempfile.TemporaryDirectory(prefix='r44-sbatch-cpu-') as temporary:
    directory = Path(temporary)
    for case, seconds in [('adopted', 285), ('rejected', 249), ('timeout', 257), ('skipped', 286)]:
        run = directory / case
        (run / 'source').mkdir(parents=True)
        (run / 'bin').mkdir()
        (run / 'source/prefill-kernels.env').write_text('DG_SM90_PREFILL_DENSE_FIRST_K=1\nDG_SM90_PREFILL_DENSE_N64=0\n')
        (run / 'source/firmus-framework.json').write_text('{"images":{"sglang":{"sha256":"cpu-fixture"}}}')
        timeout = run / 'bin/timeout'
        timeout.write_text('#!/usr/bin/env bash\nif [[ "${CASE}" == timeout ]]; then exit 137; fi\nadopted=false\nif [[ "${CASE}" == adopted ]]; then adopted=true; fi\nprintf \'{"schema_version":"prefill-dense-r44/v2","status":"complete","adopted":%s}\\n\' "${adopted}" >"${ROOT}/results/prefill-dense-r44/summary.json"\n')
        timeout.chmod(0o755)
        script = 'set -euo pipefail\nprefill_pp=4\nHEAD=head\nTAIL=tail\nSGLANG=cpu-fixture\nMODEL=cpu-fixture\nSLURM_JOB_ID=cpu-fixture\nmounts() { echo cpu-fixture; }\nSECONDS=' + str(seconds) + '\n' + block
        result = subprocess.run(['bash', '-c', script], env={**os.environ, 'ROOT': str(run), 'CASE': case, 'PATH': str(run / 'bin') + ':' + os.environ['PATH']}, capture_output=True, text=True, check=True)
        env = (run / 'source/prefill-kernels.env').read_text()
        summary = json.loads((run / 'results/prefill-dense-r44/summary.json').read_text())
        assert ('DG_SM90_PREFILL_DENSE_N64=1\n' in env) == (case == 'adopted')
        assert summary['status'] == {'adopted':'complete','rejected':'complete','timeout':'incomplete','skipped':'skipped'}[case]
        records[case] = {'seconds': seconds, 'exit_code': result.returncode, 'environment': env, 'summary': summary, 'mode': 'CPU-only real sbatch block with stubbed timeout; no srun or scheduler invocation'}
(root / 'sbatch-cpu-gate.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records, indent=2))
