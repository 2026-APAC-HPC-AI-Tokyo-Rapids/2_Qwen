import io
import json
import shlex
import subprocess
from pathlib import Path
from PySquashfsImage import SquashFsImage

remote = '''import sys
f=open('/scratch/home/ACCOUNT/qwen/containers/41853888382.sqsh','rb')
for line in sys.stdin.buffer:
 offset,size=map(int,line.split())
 f.seek(offset)
 data=f.read(size)
 sys.stdout.buffer.write(str(len(data)).encode()+b'\\n'+data)
 sys.stdout.buffer.flush()
'''
cmd = 'uv run --no-project --offline python -u -c ' + shlex.quote(remote)
p = subprocess.Popen(['ssh','firmus',cmd], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
class RemoteFile(io.RawIOBase):
 def __init__(self): self.pos=0; self.pages={}; self.page_size=4*1024*1024
 def seek(self,offset,whence=0):
  self.pos=offset if whence==0 else self.pos+offset if whence==1 else 12299583488+offset
  return self.pos
 def tell(self): return self.pos
 def read(self,size=-1):
  assert size>=0
  result=bytearray()
  while size:
   page=self.pos//self.page_size;within=self.pos%self.page_size
   if page not in self.pages:
    p.stdin.write(f'{page*self.page_size} {self.page_size}\n'.encode());p.stdin.flush()
    n=int(p.stdout.readline());data=bytearray()
    while len(data)<n: data.extend(p.stdout.read(n-len(data)))
    self.pages[page]=bytes(data)
   data=self.pages[page][within:within+size]
   if not data: break
   result.extend(data);self.pos+=len(data);size-=len(data)
  return bytes(result)
try:
 fs=SquashFsImage(RemoteFile())
 print('image metadata loaded',flush=True)
 paths=['/opt/sglang/venv/lib/python3.12/site-packages/aiperf/workers/worker.py','/opt/sglang/venv/lib/python3.12/site-packages/aiperf/common/constants.py','/opt/sglang/venv/lib/python3.12/site-packages/aiperf/endpoints/openai_chat.py','/opt/sglang/venv/lib/python3.12/site-packages/aiperf/records/inference_result_parser.py']
 for path in paths:
  node=fs.select(path)
  data=node.read_bytes()
  Path('/tmp/r44-serving-review/image-'+Path(path).name).write_bytes(data)
  print(path,len(data),flush=True)
finally:
 p.stdin.close();p.wait(timeout=30)
