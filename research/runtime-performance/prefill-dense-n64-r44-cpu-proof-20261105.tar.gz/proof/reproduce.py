"""Run with uv run --no-project python proof/reproduce.py /path/to/repository."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

root = Path(__file__).resolve().parent
repo = Path(sys.argv[1]).resolve()
inputs = json.loads((root / 'inputs.json').read_text())
archive = repo / inputs['r40_archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == inputs['r40_archive_sha256']
work = root.parent / 'work'
work.mkdir(exist_ok=True)
with tarfile.open(archive) as handle:
    handle.extractall(work, filter='data')
shutil.copy2(root / 'patched-dense.cuh', work / '.r40-proof/production/deep_gemm/include/deep_gemm/impls/sm90_fp8_gemm_1d2d.cuh')
subprocess.run(['uv', 'run', '--no-project', 'python', str(root / 'compile.py')], check=True)
subprocess.run(['uv', 'run', '--no-project', 'python', str(root / 'audit.py')], check=True)
subprocess.run(['uv', 'run', '--no-project', '--with', 'numpy>=1.26,<3', 'python', str(root / 'emulate.py')], check=True)
