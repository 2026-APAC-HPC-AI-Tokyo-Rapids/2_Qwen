This root proof records the initial implementation. The parent-review correction,
read-only SSH source investigation, current input hashes and final tests are in
serving-m-review/. Earlier root logs and source hashes remain historical evidence.

Round 44 CPU proof, parent e2f8689. No GPU execution, scheduler submission, SSH,
image build, commit or push. CUDA 13.4.92 sm_90a is a local substitute for the
image CUDA 13.0.88; no GPU performance or numerical adoption is claimed.

Six final compiles cover both full template shapes and production, N64, isolated
no-promotion diagnostic. The diagnostic includes the actual renamed kernel symbol.
compile.json contains actual invocations, times, exit codes and encodings;
*.log, *.cubin, *.sass and *.resources are raw outputs. sass-audit.json checks
zero stack/spills/local-memory instructions and no C75xx serialization warning.
*-candidate-chains.json records every static wait and surrounding issuing group.
These PCs/instruction counts are not exposed runtime cycles.

production-dense.cuh is the saved r43 control; patched-dense.cuh is the complete
runtime overlay. The final source patch and history-independent source fixture
are repository files whose hashes are recorded in repository-inputs.json.
Rejected attempt 1 crossed a backedge and spilled; attempt 2 changed only the
operand fence and still spilled; attempt 3 separated the last K but serialized
with C7514. Their sources/logs/SASS exist only in this proof. The final candidate
drains eight-K chunks. Rejected artifacts are evidence and must not be deployed.

layout.cpp checks 8192 CLayout_64x64/CLayout_64x128 mappings and row scale lanes
using the archived CUTLASS dependency. emulate.py checks one M256/N128 CTA for
both full K values with representable E4M3 samples and FP32 K128 scales. Bitwise
CPU equality and FP64 error are in emulation.json, not GPU numeric results.

For a fresh local reconstruction, extract this archive outside the worktree and
run, after exporting PATH=$HOME/.local/bin:$PATH:
uv run --no-project python proof/reproduce.py /path/to/repository
This uses the existing r40 dependency/source archive checked by SHA256, writes
only a sibling work directory and fresh proof outputs, and uses no git history.
The CPU tests execute the real extracted generator, type-check the new diagnostic
against the real scale-transform signature, and reconstruct all SGLang overlays
from fixtures. The builder still must compile/link/import the full TVM-FFI ABI
in the future image build; local stub type checking does not claim that result.

The required full pytest transcript completion and Ruff output are retained with
exit status. Final archive member SHA256 values are in manifest.json; the outer
archive digest and validation status are in the repository CPU-validation JSON.

The initial full pytest completion log has two stale-expectation failures: the
explicit environment map omitted the new default-zero flag, and a test already
collected before editing still executed its old optional-gate assertion while
traceback displayed the new source. A just-started local retry was interrupted
to load the corrected collection. No Actions or scheduler job was interrupted.
The final complete run and settings-targeted run use the corrected expectations.

The first fresh-path reproduction found an evidence-script race: the parallel
production compile rewrote its immutable control TU while the diagnostic task
read it. One empty diagnostic TU compiled successfully and the audit correctly
rejected it. The reproducer now never rewrites that shared input; the final
fresh-path reconstruction compiles and audits all six nonempty kernels. This
fix is confined to the archived proof scripts and adds no runtime retry or lock.

The source-level audit also found a genuine arithmetic issue before submission:
advance_pipeline takes K by reference and increments it. The pre-correction
candidate loaded the next B scale one index too far, and the diagnostic also
incremented K in its for clause, skipping half the product. rejected-k-index/
retains those binaries and source for rejection evidence, never deployment.
The final source uses the advanced index for the next scale and only one
increment in the diagnostic loop. check-pipeline.py executes the actual header
body with logical WGMMA/TMA stubs: every K block, phase, release and fragment
output is checked. Both old variants fail, and both final variants pass at
32/64 K128 blocks. Final six-kernel encodings are from the corrected body.
This complements the independent numerical CTA emulation; it is not GPU
arithmetic, asynchronous execution or performance evidence.

sbatch-cpu-gate.json executes the real isolated sbatch block with only timeout
stubbed: adoption at SECONDS=285 enables the flag; rejection, SIGKILL status
and insufficient budget at 286 leave production selected. It does not invoke
srun, a scheduler or a GPU. CPU fixtures and source fragments are recorded by
SHA256. Permanent tests include the actual pipeline-body regression.
