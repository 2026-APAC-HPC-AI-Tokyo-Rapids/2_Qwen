#include <cute/atom/mma_traits_sm90_gmma.hpp>
#include <cassert>
#include <iostream>
int main() {
    cute::GMMA::CLayout_64x64 l64;
    cute::GMMA::CLayout_64x128 l128;
    for (int thread=0;thread<128;++thread) for(int reg=0;reg<32;++reg) {
        assert(l128(thread,reg)==l64(thread,reg));
        assert(l128(thread,reg+32)==l64(thread,reg)+64*64);
        int warp=thread/32,lane=thread%32;
        int row=warp*16+lane/4+((reg%4)/2)*8;
        assert(l64(thread,reg)%64==row);
    }
    std::cout << "8192 N64/N128 register mappings and row-scale lanes pass\n";
}
