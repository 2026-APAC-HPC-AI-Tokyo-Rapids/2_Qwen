from pathlib import Path
import numpy as np
import json,time
root=Path(__file__).resolve().parent
records={}
for k in (4096,8192):
 start=time.monotonic();rng=np.random.default_rng(44+k)
 a=rng.integers(-16,17,(256,k)).astype(np.float32)/8
 b=rng.integers(-16,17,(128,k)).astype(np.float32)/8
 sa=rng.uniform(.001,.01,(256,k//128)).astype(np.float32)
 sb=rng.uniform(.001,.01,(k//128,)).astype(np.float32)
 prod=np.zeros((256,128),np.float32);candidate=prod.copy();reference=np.zeros(prod.shape,np.float64)
 for kb in range(k//128):
  product=np.zeros_like(prod)
  for kk in range(4):
   sl=slice(kb*128+kk*32,kb*128+(kk+1)*32)
   product+=a[:,sl]@b[:,sl].T
  scale=(sa[:,kb]*sb[kb])[:,None]
  prod[:]=(scale.astype(np.float64)*product+prod.astype(np.float64)).astype(np.float32)
  reference+=scale.astype(np.float64)*(a[:,kb*128:(kb+1)*128].astype(np.float64)@b[:,kb*128:(kb+1)*128].astype(np.float64).T)
  for wg in range(2):
   for wave in range(2):
    rows=slice(wg*64+wave*128,wg*64+wave*128+64)
    for half in range(2):
     cols=slice(half*64,half*64+64);block=np.zeros((64,64),np.float32)
     for kk in range(4):
      sl=slice(kb*128+kk*32,kb*128+(kk+1)*32)
      block+=a[rows,sl]@b[cols,sl].T
     candidate[rows,cols]=(scale[rows].astype(np.float64)*block+candidate[rows,cols].astype(np.float64)).astype(np.float32)
 equal=np.array_equal(prod.view(np.uint32),candidate.view(np.uint32));assert equal
 error=np.abs(candidate-reference)
 records[str(k)]={'scope':'M256/N128 CTA emulation, both math WGs, both M64 waves, full K, exactly representable E4M3 samples and FP32 K128 scales; not GPU arithmetic','bitwise_equal_production':equal,'elements':prod.size,'production_max_abs':float(np.abs(candidate-prod).max()),'production_max_rel':float((np.abs(candidate-prod)/np.maximum(np.abs(prod),2**-24)).max()),'fp64_reference_max_abs':float(error.max()),'fp64_reference_max_rel':float((error/np.maximum(np.abs(reference),2**-24)).max()),'seconds':time.monotonic()-start}
(root/'emulation.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records,indent=2))
