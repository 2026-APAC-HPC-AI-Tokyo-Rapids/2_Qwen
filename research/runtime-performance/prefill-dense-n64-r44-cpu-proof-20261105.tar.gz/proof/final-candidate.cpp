// CPU-only execution of the actual patched loop. WGMMA and TMA are logical
// stubs; this checks all K blocks, scale indices, stage phases and releases.
#include <cassert>
#include <bit>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <type_traits>
#define CUTLASS_LAMBDA_FUNC_INLINE
namespace cute {
template<int N> using Int = std::integral_constant<int,N>;
int block_rank_in_cluster() {return 0;}
}
float sfa_data[3][256], sfb_data[64];
int logical[3], next_k, releases, mma64_calls, mma128_calls;
bool available[3];
float scale_a(int k,int row) {return (k+1)*.001f+(row+1)*.0001f;}
float scale_b(int k) {return (k+1)*.003f+.01f;}
float value(int k,int wave,int half,int reg,int kk) {return float((k+1)*8+wave*4+half*2+reg+kk);}
struct Desc {uint32_t reg32_[2]={0,0};};
struct Full {
 int stage;
 void wait(uint32_t phase) {
  assert(stage==next_k%3 && phase==uint32_t((next_k/3)%2));
  assert(available[stage]); available[stage]=false; logical[stage]=next_k++;
  for(int r=0;r<256;++r) sfa_data[stage][r]=scale_a(logical[stage],r);
 }
};
struct Empty {
 int stage;
 void arrive(int) {assert(!available[stage]); available[stage]=true; ++releases;}
};
struct Fake64 {
 static void wgmma(const Desc& a,const Desc& b,float* dst,bool add) {
  int stage=a.reg32_[0]/2048, wave=(a.reg32_[0]%2048)*16/128/128;
  int half=(b.reg32_[0]%1024)*16/128/64, kk=(a.reg32_[0]*16%128)/32;
  assert(stage==int(b.reg32_[0]/1024) && !available[stage]);
  ++mma64_calls;
  for(int i=0;i<32;++i) {float v=value(logical[stage],wave,half,i,kk);dst[i]=add?dst[i]+v:v;}
 }
};
struct Fake128 {
 static void wgmma(const Desc& a,const Desc& b,float* dst,bool add) {
  int stage=a.reg32_[0]/2048,wave=(a.reg32_[0]%2048)*16/128/128,kk=(a.reg32_[0]*16%128)/32;
  assert(stage==int(b.reg32_[0]/1024) && !available[stage]);
  ++mma128_calls;
  for(int i=0;i<64;++i) {float v=value(logical[stage],wave,i/32,i%32,kk);dst[i]=add?dst[i]+v:v;}
 }
};
namespace mma::sm90 {template<int N> struct FP8MMASelector {static_assert(N==64);using type=Fake64;};}
namespace ptx {
void warpgroup_fence_operand(float&) {}
void warpgroup_arrive() {}
void warpgroup_commit_batch() {}
template<int N> void warpgroup_wait() {static_assert(N==0||N==1);}
float ld_shared(const float* p) {assert(p>=sfb_data && p<sfb_data+64 || p>=&sfa_data[0][0] && p<&sfa_data[2][256]);return *p;}
}
float __fmaf_rn(float a,float b,float c) {return std::fma(a,b,c);}
int main() {
 for(uint32_t num_total_k_blocks: {32u,64u}) {
  next_k=releases=mma64_calls=mma128_calls=0;
  for(int i=0;i<3;++i) {available[i]=true;logical[i]=-1;}
  for(int i=0;i<64;++i) sfb_data[i]=scale_b(i);
  constexpr uint32_t BLOCK_K=128,kNumStages=3,kNumTMAMulticast=2,SMEM_A_SIZE_PER_STAGE=32768,SMEM_B_SIZE_PER_STAGE=16384,WAVE_BLOCK_M=128;
  uint32_t stage_idx=0,phase=0,lane_idx=0,r_0=0,r_1=8,a_desc_lo=0,b_desc_lo=0;
  Full full[3]={{0},{1},{2}};Full* full_barriers[3]={full,full+1,full+2};
  Empty empty[3]={{0},{1},{2}};Empty* empty_barriers[3]={empty,empty+1,empty+2};
  float* smem_sfa[3]={sfa_data[0],sfa_data[1],sfa_data[2]};float* smem_sfb=sfb_data;
  struct {bool is_peer_cta_alive=true;} scheduler;
  using WGMMA=Fake128;
  Desc a_desc,b_desc;
  float final_accum[128]={0};
    auto advance_pipeline = [&](uint32_t& k_block_idx) {
        ++ k_block_idx;

        // Flip phases only if reach the next first stage
        stage_idx = stage_idx == kNumStages - 1 ? 0 : stage_idx + 1;
        phase ^= stage_idx == 0;
    };
                        // Release the OLD stage only after its last asynchronous reader.
                        auto release = [&](uint32_t old_stage) CUTLASS_LAMBDA_FUNC_INLINE {
                            auto target_cta = scheduler.is_peer_cta_alive ? lane_idx : cute::block_rank_in_cluster();
                            lane_idx < kNumTMAMulticast ? empty_barriers[old_stage]->arrive(target_cta) : void();
                        };
#if defined(DG_R44_DIAGNOSTIC_NO_PROMOTION) && DG_R44_DIAGNOSTIC_NO_PROMOTION
                        // TIMING ONLY, numerically wrong: no scales or CUDA promotion.
                        // One group per K128 contains both M64 waves. Tensor-core sums
                        // remain live across K; only the previous stage is released.
                        #pragma unroll
                        for (uint32_t i = 0; i < 128; ++i) ptx::warpgroup_fence_operand(final_accum[i]);
                        ptx::warpgroup_arrive();
                        uint32_t previous_stage = stage_idx;
                        #pragma unroll 8
                        for (uint32_t kb = 0; kb < num_total_k_blocks; advance_pipeline(kb)) {
                            full_barriers[stage_idx]->wait(phase);
                            #pragma unroll
                            for (uint32_t wave = 0; wave < 2; ++wave) {
                                #pragma unroll
                                for (uint32_t kk = 0; kk < 4; ++kk) {
                                    a_desc.reg32_[0] = a_desc_lo + stage_idx * (SMEM_A_SIZE_PER_STAGE / 16) + (wave * WAVE_BLOCK_M * BLOCK_K + kk * 32) / 16;
                                    b_desc.reg32_[0] = b_desc_lo + stage_idx * (SMEM_B_SIZE_PER_STAGE / 16) + kk * 32 / 16;
                                    WGMMA::wgmma(a_desc, b_desc, final_accum + wave * 64, kb != 0 || kk != 0);
                                }
                            }
                            ptx::warpgroup_commit_batch();
                            ptx::warpgroup_wait<1>();
                            if (kb != 0) release(previous_stage);
                            previous_stage = stage_idx;
                        }
                        // The sole wait0 is the tile drain, outside the hot K loop.
                        ptx::warpgroup_wait<0>();
                        #pragma unroll
                        for (uint32_t i = 0; i < 128; ++i) ptx::warpgroup_fence_operand(final_accum[i]);
                        release(previous_stage);
#else
                        using MMA64 = typename mma::sm90::FP8MMASelector<64>::type;
                        float t0[32], t1[32];
                        // N64 accumulator layout is the first/second 32-register
                        // half of N128; each group of four is two columns x two rows.
                        auto issue = [&](float* t, auto wave_c, auto half_c) CUTLASS_LAMBDA_FUNC_INLINE {
                            constexpr uint32_t wave = decltype(wave_c)::value, half = decltype(half_c)::value;
                            #pragma unroll
                            for (uint32_t i = 0; i < 32; ++i) ptx::warpgroup_fence_operand(t[i]);
                            ptx::warpgroup_arrive();
                            #pragma unroll
                            for (uint32_t kk = 0; kk < 4; ++kk) {
                                a_desc.reg32_[0] = a_desc_lo + stage_idx * (SMEM_A_SIZE_PER_STAGE / 16) + (wave * WAVE_BLOCK_M * BLOCK_K + kk * 32) / 16;
                                b_desc.reg32_[0] = b_desc_lo + stage_idx * (SMEM_B_SIZE_PER_STAGE / 16) + (half * 64 * BLOCK_K + kk * 32) / 16;
                                MMA64::wgmma(a_desc, b_desc, t, kk != 0);
                            }
                            ptx::warpgroup_commit_batch();
                        };
                        auto promote = [&](float* t, auto wave_c, auto half_c, float s0, float s1, auto first_c) CUTLASS_LAMBDA_FUNC_INLINE {
                            constexpr uint32_t wave = decltype(wave_c)::value, half = decltype(half_c)::value;
                            constexpr bool first = decltype(first_c)::value;
                            // Only the completed temporary is fenced/read. Never
                            // put a compiler operand fence on the other pending group.
                            #pragma unroll
                            for (uint32_t i = 0; i < 32; ++i) ptx::warpgroup_fence_operand(t[i]);
                            auto dst = final_accum + wave * 64 + half * 32;
                            #pragma unroll
                            for (uint32_t i = 0; i < 8; ++i) {
                                dst[4*i+0] = __fmaf_rn(s0, t[4*i+0], first ? 0.0f : dst[4*i+0]);
                                dst[4*i+1] = __fmaf_rn(s0, t[4*i+1], first ? 0.0f : dst[4*i+1]);
                                dst[4*i+2] = __fmaf_rn(s1, t[4*i+2], first ? 0.0f : dst[4*i+2]);
                                dst[4*i+3] = __fmaf_rn(s1, t[4*i+3], first ? 0.0f : dst[4*i+3]);
                            }
                        };
                        auto chunk = [&](auto first_chunk, uint32_t begin) CUTLASS_LAMBDA_FUNC_INLINE {
                        full_barriers[stage_idx]->wait(phase);
                        float sb = ptx::ld_shared(smem_sfb + begin);
                        float s0 = ptx::ld_shared(smem_sfa[stage_idx] + r_0) * sb;
                        float s1 = ptx::ld_shared(smem_sfa[stage_idx] + r_1) * sb;
                        issue(t0, cute::Int<0>{}, cute::Int<0>{});
                        issue(t1, cute::Int<0>{}, cute::Int<1>{});
                        auto step = [&](auto first_c, auto next_c, uint32_t kb) CUTLASS_LAMBDA_FUNC_INLINE {
                            float m1s0 = ptx::ld_shared(smem_sfa[stage_idx] + r_0 + WAVE_BLOCK_M) * sb;
                            float m1s1 = ptx::ld_shared(smem_sfa[stage_idx] + r_1 + WAVE_BLOCK_M) * sb;
                            ptx::warpgroup_wait<1>();
                            promote(t0, cute::Int<0>{}, cute::Int<0>{}, s0, s1, first_c);
                            issue(t0, cute::Int<1>{}, cute::Int<0>{});
                            ptx::warpgroup_wait<1>();
                            promote(t1, cute::Int<0>{}, cute::Int<1>{}, s0, s1, first_c);
                            issue(t1, cute::Int<1>{}, cute::Int<1>{});
                            ptx::warpgroup_wait<1>();
                            promote(t0, cute::Int<1>{}, cute::Int<0>{}, m1s0, m1s1, first_c);
                            uint32_t old_stage = stage_idx;
                            advance_pipeline(kb);
                            if constexpr (decltype(next_c)::value) {
                                full_barriers[stage_idx]->wait(phase);
                                sb = ptx::ld_shared(smem_sfb + kb);
                                s0 = ptx::ld_shared(smem_sfa[stage_idx] + r_0) * sb;
                                s1 = ptx::ld_shared(smem_sfa[stage_idx] + r_1) * sb;
                                issue(t0, cute::Int<0>{}, cute::Int<0>{});
                                ptx::warpgroup_wait<1>();
                                release(old_stage);
                                promote(t1, cute::Int<1>{}, cute::Int<1>{}, m1s0, m1s1, first_c);
                                issue(t1, cute::Int<0>{}, cute::Int<1>{});
                            } else {
                                ptx::warpgroup_wait<0>();
                                release(old_stage);
                                promote(t1, cute::Int<1>{}, cute::Int<1>{}, m1s0, m1s1, first_c);
                            }
                        };
                        // No pending WGMMA register crosses a backedge. Drain
                        // each eight-K chunk to avoid ptxas C7514 serialization.
                        step(first_chunk, std::true_type{}, begin);
                        #pragma unroll
                        for (uint32_t u = 1; u < 7; ++u) step(std::false_type{}, std::true_type{}, begin + u);
                        step(std::false_type{}, std::false_type{}, begin + 7);
                        };
                        chunk(std::true_type{}, 0);
                        for (uint32_t begin = 8; begin < num_total_k_blocks; begin += 8) chunk(std::false_type{}, begin);
#endif
  assert(next_k==int(num_total_k_blocks) && releases==int(num_total_k_blocks));
  for(bool free:available) assert(free);
  for(int wave=0;wave<2;++wave) for(int half=0;half<2;++half) for(int i=0;i<32;++i) {
   float expected=0;
   for(int k=0;k<int(num_total_k_blocks);++k) {
#if DG_R44_DIAGNOSTIC_NO_PROMOTION
    for(int kk=0;kk<4;++kk) expected+=value(k,wave,half,i,kk);
#else
    float product=0;for(int kk=0;kk<4;++kk) product+=value(k,wave,half,i,kk);
    int row=wave*128+(i%4>=2?8:0);
    expected=std::fma(scale_a(k,row)*scale_b(k),product,expected);
#endif
   }
   assert(std::bit_cast<uint32_t>(final_accum[wave*64+half*32+i])==std::bit_cast<uint32_t>(expected));
  }
#if DG_R44_DIAGNOSTIC_NO_PROMOTION
  assert(mma128_calls==int(num_total_k_blocks)*8 && mma64_calls==0);
#else
  assert(mma64_calls==int(num_total_k_blocks)*16 && mma128_calls==0);
#endif
  std::cout << "K128 blocks=" << next_k << " releases=" << releases << " mma64=" << mma64_calls << " mma128=" << mma128_calls << " all 128 fragment outputs bitwise equal\n";
 }
}
