from pathlib import Path
import ast,hashlib,importlib.util,json,re,subprocess,time
import triton
from triton.compiler import ASTSource
from triton.backends.compiler import GPUTarget
w=Path(__file__).resolve().parent;out=w/'production-proof';records={}
for name,path,flag in [('onepass-base',w/'base',None),('onepass-off',w/'prod',False),('onepass-on',w/'prod',True)]:
 text=(path/'python/sglang/kernels/ops/moe/prefill_moe_input.py').read_text();tree=ast.parse(text);f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==('_onepass_moe_input_div448' if flag else '_onepass_moe_input'))
 p=out/(name+'.py');p.write_text('import triton\nimport triton.language as tl\n@triton.jit\n'+ast.get_source_segment(text,f)+'\n')
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 signature={'O':'*bf16','R':'*bf16','W':'*bf16','G':'*bf16','Q':'*fp8e4nv','S':'*fp32','IDS':'*i64','TW':'*fp32','num_tokens':'i32','eps':'fp32'}
 start=time.monotonic();k=triton.compile(ASTSource(getattr(m, f.name),signature=signature,constexprs={'BLOCK_M':64},attrs={(i,):[['tt.divisibility',16]] for i in range(8)}),target=GPUTarget('cuda',90,32),options={'num_warps':8,'num_stages':3})
 for ext in ('cubin','ptx','llir','ttgir'):
  b=k.asm[ext];(out/(name+'.'+ext)).write_bytes(b if isinstance(b,bytes) else b.encode())
 sass=subprocess.check_output(['/usr/local/cuda-13.4/bin/nvdisasm','-hex',str(out/(name+'.cubin'))],text=True);(out/(name+'.sass')).write_text(sass)
 enc=b''.join(int(x,16).to_bytes(8,'little') for x in re.findall(r'/\* 0x([0-9a-f]{16}) \*/',sass))
 records[name]={'sass_sha256':hashlib.sha256(enc).hexdigest(),'sass_bytes':len(enc),'cubin_sha256':hashlib.sha256((out/(name+'.cubin')).read_bytes()).hexdigest(),'metadata':str(k.metadata),'seconds':time.monotonic()-start}
 print(name,records[name],flush=True)
assert records['onepass-base']['sass_sha256']==records['onepass-off']['sass_sha256']
assert (out/'onepass-base.cubin').read_bytes()==(out/'onepass-off.cubin').read_bytes()
(out/'triton.json').write_text(json.dumps(records,indent=2)+'\n')
