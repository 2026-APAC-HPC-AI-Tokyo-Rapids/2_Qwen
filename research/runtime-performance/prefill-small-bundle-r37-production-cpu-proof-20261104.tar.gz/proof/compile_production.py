from pathlib import Path
import concurrent.futures,hashlib,json,re,subprocess,time
r=Path.cwd();w=r/'.r37-work';out=w/'production-proof';out.mkdir(exist_ok=True)
dep=w/'r32/r32/dependencies';original=next((w/'r32/r32/r26').glob('DeepGEMM-*'))/'deep_gemm/include'
prod=w/'prod/deep_gemm/include'
# Only one changed header, retain all other installed dependency headers.
import shutil
shutil.copytree(original,prod,dirs_exist_ok=True,ignore=lambda d,n: ['sm90_fp8_gemm_1d2d.cuh'] if d.endswith('/impls') else [])
cmds=json.loads((w/'r36/compile.json').read_text())
def build_group(group):
 records={}
 for job in group:
    name,source,includes,macro=job
    family=name.rsplit('-',1)[0]
    inp=out/'inputs'/family;inp.mkdir(parents=True,exist_ok=True)
    p=inp/'kernel.cu';record=out/(name+'.cu');record.write_text(source)
    if family.startswith('rope'):
        header=includes[0] if False else (w/('base' if name.endswith('-base') else 'prod')/'python/sglang/kernels/jit/csrc/elementwise/rope.cuh')
        target=inp/'rope.cuh';target.write_text(header.read_text())
        source=source.replace(str(header),str(target))
    else:
        target=inp/'deep_gemm/impls/sm90_fp8_gemm_1d2d.cuh';target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text((includes[0]/'deep_gemm/impls/sm90_fp8_gemm_1d2d.cuh').read_text())
        includes=[inp,original,dep]
    p.write_text(source)
    cubin=record.with_suffix('.cubin')
    cmd=['/usr/local/cuda-13.4/bin/nvcc','--cubin','--std=c++20','--expt-relaxed-constexpr','--expt-extended-lambda','-O3','--diag-suppress=177','--ptxas-options=-v,-warn-spills','-gencode','arch=compute_90a,code=sm_90a',*['-I'+str(i) for i in includes],*macro,str(p),'-o',str(cubin)]
    start=time.monotonic();res=subprocess.run(cmd,capture_output=True,text=True);record.with_suffix('.log').write_text(res.stdout+res.stderr);assert res.returncode==0,(name,res.stderr)
    sass=subprocess.check_output(['/usr/local/cuda-13.4/bin/nvdisasm','-hex',str(cubin)],text=True);record.with_suffix('.sass').write_text(sass)
    words=re.findall(r'/\* 0x([0-9a-f]{16}) \*/',sass);enc=b''.join(int(x,16).to_bytes(8,'little') for x in words)
    records[name]={'sass_sha256':hashlib.sha256(enc).hexdigest(),'sass_bytes':len(enc),'cubin_sha256':hashlib.sha256(cubin.read_bytes()).hexdigest(),'seconds':time.monotonic()-start,'command':cmd}
    print(name,records[name]['sass_sha256'],flush=True)
 return records

jobs=[]
for shape in ['qkv','o']:
 source=(w/'proof'/(shape+'.cu')).read_text()
 for mode,inc,macro in [('base',original,[]),('off',prod,[]),('on',prod,['-DDG_SM90_PREFILL_DENSE_FIRST_K=1'])]:jobs.append((shape+'-'+mode,source,[inc,dep],macro))
# Non-target template guards: representative deviations from every guarded axis.
source=(w/'proof/qkv.cu').read_text();args=source.split('impl<')[1].split('>);')[0].split(',')
variants={1:'8192',2:'8192',3:'8192',4:'2',5:'128',6:'64',8:'0',10:'0',11:'4',13:'128',14:'1',15:'false',16:'128',17:'deep_gemm::GemmType::GroupedContiguous'}
# Avoid invalid swizzle/layout combinations and grouped scheduling test without descriptors.
for i in (1,2,3,4,5,6,11,14,15,16):
 v=args.copy();v[i]=variants[i];text=source.replace(','.join(args),','.join(v))
 for mode,inc,macro in [('base',original,[]),('off',prod,[]),('on',prod,['-DDG_SM90_PREFILL_DENSE_FIRST_K=1'])]:jobs.append((f'guard-{i}-{mode}',text,[inc,dep],macro))
for typ in ['int32_t','int64_t']:
 for mode,path,template in [('base',w/'base',''),('off',w/'prod',''),('on',w/'prod','')]:
  header=path/'python/sglang/kernels/jit/csrc/elementwise/rope.cuh'
  source=f'#include "{header}"\nextern "C" void* instantiate() {{ return reinterpret_cast<void*>(&qknorm_rope_prefill_fp32_kernel<true,{typ}{template}>); }}\n'
  if mode == 'on':source=source.replace('qknorm_rope_prefill_fp32_kernel','qknorm_rope_prefill_fp32_fixed_kernel')
  inc=[x[2:] for x in cmds['rope-'+typ]['cmd'] if x.startswith('-I')]
  old='/tmp/claude-1000/-home-USER-2026-APAC-HPC-AI-Tokyo-Rapids-2-Qwen/00000000-0000-0000-0000-000000000000/scratchpad/codex-scratch/r36'
  inc=[Path(x.replace(old,str(w/'r36'))) for x in inc]
  jobs.append(('rope-'+typ+'-'+mode,source,inc,['-DSGL_CUDA_ARCH=900']))
records={}
groups={}
for job in jobs:groups.setdefault(job[0].rsplit('-',1)[0],[]).append(job)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
 for results in pool.map(build_group,groups.values()):records.update(results)
(out/'cuda.json').write_text(json.dumps(records,indent=2)+'\n')
for name in ['qkv','o',*['guard-'+str(i) for i in (1,2,3,4,5,6,11,14,15,16)],'rope-int32_t','rope-int64_t']:
 assert records[name+'-base']['sass_sha256']==records[name+'-off']['sass_sha256'],name
 assert records[name+'-base']['cubin_sha256']==records[name+'-off']['cubin_sha256'],name
 if name.startswith('guard'):assert records[name+'-base']['sass_sha256']==records[name+'-on']['sass_sha256'],name
print('All off and non-target encodings identical',flush=True)
