#include <deep_gemm/impls/sm90_fp8_gemm_1d2d.cuh>
extern "C" void* instantiate() { return reinterpret_cast<void*>(&deep_gemm::sm90_fp8_gemm_1d2d_impl<cute::UMMA::Major::K,0,9216,4096,1,128,128,128,128,128,128,3,128,256,2,true,132,deep_gemm::GemmType::Normal,cutlass::bfloat16_t,deep_gemm::epilogue::transform::EpilogueIdentity>); }
