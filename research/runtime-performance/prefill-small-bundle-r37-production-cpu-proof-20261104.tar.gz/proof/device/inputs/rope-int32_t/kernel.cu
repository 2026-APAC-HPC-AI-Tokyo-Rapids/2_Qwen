#include "/tmp/claude-1000/-home-USER-2026-APAC-HPC-AI-Tokyo-Rapids-2-Qwen/00000000-0000-0000-0000-000000000000/scratchpad/wt/r37/.r37-work/production-proof/inputs/rope-int32_t/rope.cuh"
extern "C" void* instantiate() { return reinterpret_cast<void*>(&qknorm_rope_prefill_fp32_fixed_kernel<true,int32_t>); }
