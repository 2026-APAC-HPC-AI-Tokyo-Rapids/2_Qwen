#pragma once

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-attributes"

#include <cstdint>
#include <type_traits>
#include <cutlass/arch/barrier.h>
#include <cutlass/arch/reg_reconfig.h>

#include <cute/arch/cluster_sm90.hpp>
#include <cute/arch/copy_sm90_tma.hpp>

#include <deep_gemm/common/math.cuh>
#include <deep_gemm/common/tma_copy.cuh>
#include <deep_gemm/common/utils.cuh>
#include <deep_gemm/comm/barrier.cuh>
#include <deep_gemm/layout/sym_buffer.cuh>
#include <deep_gemm/layout/mega_moe.cuh>
#include <deep_gemm/mma/sm90.cuh>
#include <deep_gemm/scheduler/mega_moe.cuh>
#include <deep_gemm/ptx/ld_st.cuh>
#include <deep_gemm/ptx/tma.cuh>
#include <deep_gemm/ptx/utils.cuh>
#include <deep_gemm/ptx/wgmma.cuh>
#define __CLION_IDE__

namespace deep_gemm {

template <float kActivationClamp>
__forceinline__ __device__ float sm90_fp8_mega_moe_clamp_gate(float x) {
    if constexpr (kActivationClamp != cute::numeric_limits<float>::infinity())
        x = cute::min(x, kActivationClamp);
    return x;
}

template <float kActivationClamp>
__forceinline__ __device__ float sm90_fp8_mega_moe_clamp_up(float x) {
    if constexpr (kActivationClamp != cute::numeric_limits<float>::infinity())
        x = cute::min(cute::max(x, -kActivationClamp), kActivationClamp);
    return x;
}

template <bool kFastMath>
__forceinline__ __device__ float sm90_fp8_mega_moe_silu(float x) {
    const float e = kFastMath ? __expf(-x) : expf(-x);
    const float sig = kFastMath ? math::fast_rcp(1.0f + e) : 1.0f / (1.0f + e);
    return x * sig;
}

template <bool kFastMath, float kActivationClamp>
__forceinline__ __device__ float sm90_fp8_mega_moe_swiglu(float g, float u) {
    g = sm90_fp8_mega_moe_clamp_gate<kActivationClamp>(g);
    u = sm90_fp8_mega_moe_clamp_up<kActivationClamp>(u);
    return sm90_fp8_mega_moe_silu<kFastMath>(g) * u;
}

// Continuous FP32 activation scale. SM90 WGMMA has no hardware block-scale operand (the SF
// is a plain FFMA in the epilogue), so the previous UE8M0 (power-of-two) scale bought nothing
// on SM90 and only cost precision; the SF pool is already fp32, so this is byte/layout neutral.
// clamp amax before the reciprocal: padded rows have amax==0, and 448/0=inf -> 0*inf=NaN.
__forceinline__ __device__ void sm90_fp8_mega_moe_get_e4m3_sf_and_sf_inv(
    const float2& amax, float2& sf, float2& sf_inv) {
    constexpr float kScale = 1.0f / 448.0f;
    const auto ax = fmaxf(amax.x, 1e-10f);
    const auto ay = fmaxf(amax.y, 1e-10f);
    sf.x = __fmul_rn(ax, kScale), sf_inv.x = 1.0f / sf.x;
    sf.y = __fmul_rn(ay, kScale), sf_inv.y = 1.0f / sf.y;
}

template <uint32_t BLOCK_M, uint32_t BLOCK_N, uint32_t BLOCK_K,
          uint32_t L1_SHAPE_N, uint32_t L1_SHAPE_K,
          uint32_t L2_SHAPE_N, uint32_t L2_SHAPE_K,
          uint32_t kNumExpertsPerRank,
          uint32_t kNumExpertsPerWave,
          uint32_t kNumSMs, uint32_t kNumRanks,
          uint32_t kNumExpertsPerLane,
          uint32_t kNumL1BlockNs, uint32_t kNumL2BlockNs,
          uint32_t kNumL1BlockKs, uint32_t kNumL2BlockKs,
          typename WorkspaceT, typename L1Func, typename L2Func>
CUTLASS_DEVICE void sm90_fp8_mega_moe_for_each_block_split(
    sched::MegaMoEScheduler<BLOCK_M, BLOCK_N, BLOCK_K,
                            L1_SHAPE_N, L1_SHAPE_K,
                            L2_SHAPE_N, L2_SHAPE_K,
                            kNumExpertsPerRank,
                            kNumExpertsPerWave,
                            kNumSMs, kNumRanks,
                            kNumExpertsPerLane,
                            kNumL1BlockNs, kNumL2BlockNs,
                            kNumL1BlockKs, kNumL2BlockKs,
                            WorkspaceT>& scheduler,
    L1Func&& l1_func, L2Func&& l2_func) {
    scheduler.fetch_expert_recv_count();
    scheduler.set_expert_idx(0);

    while (true) {
        CUTE_TIE_DECL(scheduler.get_next_block(), block_phase, current_local_expert_idx, m_block_idx, n_block_idx);
        if (block_phase == sched::BlockPhase::None)
            break;

        if (block_phase == sched::BlockPhase::Linear1) {
            l1_func(current_local_expert_idx, kNumL1BlockKs, m_block_idx, n_block_idx);
        } else {
            l2_func(current_local_expert_idx, kNumL2BlockKs, m_block_idx, n_block_idx);
        }
    }
}

// Qwen Prefill (single expert wave): FC1 blocks keep the static round-robin
// assignment, FC2 blocks are claimed dynamically. With the static split the
// CTAs of a rank finish the last FC2 wave tens of microseconds apart (uneven
// FC1 block counts, staggered first dispatch arrivals) and the combine waits
// for the slowest; claiming FC2 blocks in order evens that out without
// changing what any block computes.
// `get_l2_block()` returns the next FC2 block of this CTA already decoded:
// x = local expert << 24 | n block << 16 | m block, y = expert pool block
// offset << 16 | expert token count, or x = ~0 when the wave is exhausted.
// One role claims and decodes (`sm90_fp8_mega_moe_decode_l2_block`), the
// others receive the same words, so the consumers keep no scheduler state live
// across FC2 blocks.
// Paired tails (host DG_SM90_PREFILL_TAIL_PAIR, kPrefillTailPair): a pool block with at
// most kPairRows valid rows is one warpgroup's rows. Its N blocks run in pairs: the item of
// N block 2 j computes N blocks 2 j and 2 j + 1 on the two warpgroups and consumes two
// pipeline stages per K block; the item of N block 2 j + 1 is skipped. Every role (A loader,
// B loader, math warps) walks the same item stream through this driver with its own
// scheduler copy, and the skip and the pairing are this one predicate of (valid rows, N
// block), so all roles skip the same items and advance the stage ring by the same count.
template <uint32_t kPairRows>
CUTLASS_DEVICE bool sm90_fp8_mega_moe_tail_pair(const uint32_t& valid_m) {
    return valid_m <= kPairRows;
}

template <uint32_t kNumSMs, uint32_t kNumL1BlockNs, uint32_t kNumL1BlockKs, uint32_t kNumL2BlockKs,
          bool kTailPair = false, uint32_t kPairRows = 0,
          typename Scheduler, typename GetL2Block, typename L1Func, typename L2Func>
CUTLASS_DEVICE void sm90_fp8_mega_moe_for_each_block_dynamic_l2(
    Scheduler& scheduler, GetL2Block&& get_l2_block, L1Func&& l1_func, L2Func&& l2_func) {
    scheduler.fetch_expert_recv_count();
    scheduler.set_expert_idx(0);

    while (scheduler.fetch_next_l1_block()) {
        const uint32_t n_block_idx = scheduler.block_idx - scheduler.m_block_idx * kNumL1BlockNs;
        scheduler.block_idx += kNumSMs;
        if constexpr (kTailPair) {
            if ((n_block_idx & 1u) and sm90_fp8_mega_moe_tail_pair<kPairRows>(scheduler.template get_valid_m<false>()))
                continue;
        }
        l1_func(scheduler.current_local_expert_idx, kNumL1BlockKs, scheduler.m_block_idx, n_block_idx);
    }

    scheduler.set_expert_idx(0);
    scheduler.block_idx = 0;
    while (true) {
        const uint2 info = get_l2_block();
        if (info.x == 0xffffffffu)
            break;
        scheduler.current_local_expert_idx = info.x >> 24;
        scheduler.m_block_idx = info.x & 0xffffu;
        scheduler.current_pool_block_offset = info.y >> 16;
        scheduler.current_num_tokens = info.y & 0xffffu;
        if constexpr (kTailPair) {
            if (((info.x >> 16) & 1u) and sm90_fp8_mega_moe_tail_pair<kPairRows>(scheduler.template get_valid_m<false>()))
                continue;
        }
        l2_func(info.x >> 24, kNumL2BlockKs, info.x & 0xffffu, (info.x >> 16) & 0xffu);
    }
}

// Decode a claimed FC2 block index (strictly increasing per CTA) with the
// scheduler's expert walk; `scheduler.block_idx` holds the index relative to
// the current expert and `prev_l2_block_idx` the previous claim.
template <uint32_t kNumL2BlockNs, typename Scheduler>
CUTLASS_DEVICE uint2 sm90_fp8_mega_moe_decode_l2_block(
    Scheduler& scheduler, const uint32_t& l2_block_idx, uint32_t& prev_l2_block_idx) {
    scheduler.block_idx += l2_block_idx - prev_l2_block_idx;
    prev_l2_block_idx = l2_block_idx;
    while (scheduler.block_idx >= scheduler.get_current_num_m_blocks() * kNumL2BlockNs) {
        scheduler.block_idx -= scheduler.get_current_num_m_blocks() * kNumL2BlockNs;
        scheduler.advance_expert_idx();
    }
    const uint32_t m_block_idx = scheduler.block_idx / kNumL2BlockNs;
    const uint32_t n_block_idx = scheduler.block_idx - m_block_idx * kNumL2BlockNs;
    return make_uint2((scheduler.current_local_expert_idx << 24) | (n_block_idx << 16) | m_block_idx,
                      (scheduler.current_pool_block_offset << 16) | scheduler.current_num_tokens);
}

// ============================================================================
// SM90 (Hopper) FP8 MegaMoE — full implementation
// ----------------------------------------------------------------------------
// Pipeline (cluster=1, no TMA multicast):
//   * Dispatch warps: pull tokens (FP8) and SF (per-128 channel float) from
//     remote ranks via NVLink into the local L1 pool.
//   * GEMM TMA-load warps (1 for A+SFA, 1 for B+SFB) feed the pipeline stages.
//   * Math warpgroups (totalling kNumEpilogueThreads) consume each
//     stage with WGMMA, accumulate into registers, then run the epilogue:
//       - L1 (Linear1): SwiGLU with gate/up granularity-8 interleaved layout,
//         per-row amax over each output-SF group, FP8 e4m3 quantize, stage
//         through SMEM, then TMA store to local L1 output buffer.
//         The per-row SF is written as a *float* into the L2-acts SF buffer at
//         per-64 K granularity (one SF per L1 N block), so each block is fully
//         self-contained and no cross-CTA amax synchronisation is needed.
//       - L2 (Linear2): BF16 cast of the GEMM output, stage through SMEM,
//         then NVLink scatter to remote combine buffers.
//   * After all GEMM blocks, the math warps run the COMBINE step (top-k
//     reduction in BF16) — ported verbatim from the SM100 kernel.
// ============================================================================

template <
    uint32_t kNumMaxTokensPerRank,
    uint32_t kHidden, uint32_t kIntermediateHidden,
    uint32_t kNumExperts, uint32_t kNumTopk,
    uint32_t kNumExpertsPerWave,
    uint32_t BLOCK_M, uint32_t BLOCK_N, uint32_t BLOCK_K,
    uint32_t kNumMaxPoolTokens,
    uint32_t kNumPaddedSFPoolTokens,
    uint32_t kNumStages,
    uint32_t kNumDispatchThreads, uint32_t kNumNonEpilogueThreads,
    uint32_t kNumEpilogueThreads,
    uint32_t kNumSMs, uint32_t kNumRanks,
    float kActivationClamp,
    bool kFastMath,
    uint32_t kEpilogueRegisterBudget,
    bool kReuseAccumAsFinal,
    bool kL2ArrivalCounter,
    bool kL2EpilogueRequiresFullSync,
    bool kSplitPhaseHotPath,
    bool kFP8SwapAB = false,
    bool kPrefillLean = false,
    bool kPrefillTailPair = false,
    bool kPrefillSplitAccum = false,
    uint32_t L1_SHAPE_N = kIntermediateHidden * 2,
    uint32_t L1_SHAPE_K = kHidden,
    uint32_t L2_SHAPE_N = kHidden,
    uint32_t L2_SHAPE_K = kIntermediateHidden,
    uint32_t kNumDispatchWarps = kNumDispatchThreads / 32,
    uint32_t kNumMMANonEpilogueWarps = kNumNonEpilogueThreads / 32,
    uint32_t kNumEpilogueWarps = kNumEpilogueThreads / 32,
    uint32_t kNumEpilogueWarpgroups = kNumEpilogueWarps / 4,
    uint32_t kNumThreads = kNumDispatchThreads + kNumNonEpilogueThreads + kNumEpilogueThreads,
    uint32_t kNumTokensPerWarp = 32 / kNumTopk,
    uint32_t kNumExpertsPerRank = kNumExperts / kNumRanks
>
CUTLASS_GLOBAL __launch_bounds__(kNumThreads, 1) void
sm90_fp8_mega_moe_impl(void* y,
                       int* cumulative_local_expert_recv_stats,
                       const uint32_t num_tokens,
                       const __grid_constant__ layout::SymBuffer<kNumRanks> sym_buffer,
                       const __grid_constant__ cute::TmaDescriptor tensor_map_l1_acts,
                       const __grid_constant__ cute::TmaDescriptor tensor_map_l1_acts_sf,
                       const __grid_constant__ cute::TmaDescriptor tensor_map_l1_weights,
                       const float* __restrict__ l1_weights_sf,
                       const __grid_constant__ cute::TmaDescriptor tensor_map_l1_output,
                       const __grid_constant__ cute::TmaDescriptor tensor_map_l2_acts,
                       const __grid_constant__ cute::TmaDescriptor tensor_map_l2_acts_sf,
                       const __grid_constant__ cute::TmaDescriptor tensor_map_l2_weights,
                       const float* __restrict__ l2_weights_sf) {
#if (defined(__CUDA_ARCH__) and (__CUDA_ARCH__ >= 900) and (__CUDA_ARCH__ < 1000)) or defined(__CLION_IDE__)
    using Barrier = cutlass::arch::ClusterTransactionBarrier;

    // =====================================================================
    // Template checks
    // =====================================================================
    DG_STATIC_ASSERT(kNumDispatchThreads >= 64 and kNumDispatchThreads % 64 == 0,
                     "Invalid number of dispatch threads");
    DG_STATIC_ASSERT(kNumNonEpilogueThreads == 64 or kNumNonEpilogueThreads == 128,
                     "Invalid number of GEMM TMA warps");
    DG_STATIC_ASSERT((kNumDispatchThreads + kNumNonEpilogueThreads) % 128 == 0,
                     "Math warpgroup start must be 128-thread aligned");
    DG_STATIC_ASSERT(kNumEpilogueThreads % 128 == 0, "Invalid number of math/epilogue threads");
    DG_STATIC_ASSERT(kNumExperts % kNumRanks == 0, "Invalid number of experts or ranks");
    DG_STATIC_ASSERT(BLOCK_M % 64 == 0, "BLOCK_M must be a multiple of WGMMA::M (64)");
    DG_STATIC_ASSERT(BLOCK_N == 128 or BLOCK_N == 256 or BLOCK_N == 512,
                     "SM90 MegaMoE supports CTA BLOCK_N=128/256/512");
    DG_STATIC_ASSERT(BLOCK_K == 128, "BLOCK_K is fixed to 128 (per-128 SF)");

    // Qwen Prefill with two math warpgroups: the host launches this tile with
    // 256 math threads only under DG_SM90_PREFILL_2WG=1 (64 + 64 + 256 = 384
    // threads, so the kernel-wide register cap is 168 instead of 96). Each
    // warpgroup owns a 64x256 row half of the 128x256 tile with one m64n256 SS
    // WGMMA accumulator (128 FP32 registers per thread), rescaled per K block
    // exactly like the four-warpgroup path. Per K block the WGMMA operand reads
    // from shared memory drop from 96 KiB (four m64n128 warpgroups: A 4 x 8, B
    // 4 x 16) to 80 KiB (A 2 x 8, B 2 x 32). Same tile, scheduler, pipeline, K
    // order, FP32 accumulation, scales and quantization granularity. The
    // 512-thread instantiation is unchanged (every edit below is constexpr-gated).
    // Every warp writes and publishes its own FC1 output rows (see the
    // kPrefill2WG L1 epilogue).
    // Same math/quantization path for a pipeline stage owning all experts.
    // The host enables this geometry only with DG_SM90_PREFILL_LOCAL_EP1.
    constexpr bool kQwenPrefillRanks = kNumRanks == 4 or
        (kNumRanks == 1 and kNumExperts == 128 and kNumEpilogueThreads == 256);
    constexpr bool kPrefill2WG =
        kHidden == 4096 && kIntermediateHidden == 1536 && kQwenPrefillRanks &&
        BLOCK_M == 128 && BLOCK_N == 256 && kNumEpilogueThreads == 256 && kReuseAccumAsFinal;
    // Specialize the same scheduler stream into FC1/FC2 loops for Qwen
    // Prefill. This removes dynamic phase state from the register-heavy math
    // loop while retaining the existing block order and pipeline barriers.
    constexpr bool kSpecializePhase = kSplitPhaseHotPath ||
        (kHidden == 4096 && kIntermediateHidden == 1536 && kQwenPrefillRanks &&
         BLOCK_M == 128 && BLOCK_N == 256 && (kNumEpilogueThreads == 512 || kPrefill2WG) && kReuseAccumAsFinal);
    // Qwen Prefill only: FC2 blocks are claimed from a per-rank counter instead
    // of the static round-robin split (see sm90_fp8_mega_moe_for_each_block_dynamic_l2).
    constexpr bool kDynamicL2 = kSpecializePhase and not kFP8SwapAB and
        kNumExpertsPerWave == kNumExpertsPerRank;
    // Qwen Prefill only: the FC2 activation (SwiGLU output) carries one FP32
    // scale per token per 128 K (the standard per-token-group granularity)
    // instead of per 64. One L1 output tile of 128 columns, produced by the two
    // N-split warpgroups of a row pair, is one scale group, so the per-row amax
    // is exchanged inside the pair before quantizing, the first warpgroup of the
    // pair publishes the scale at group slot `n_block_idx`, and FC2 consumes one
    // scale per K block: one WGMMA group of four per K block with a single
    // rescale, like FC1, instead of two half-K groups with a `wait<0>` between.
    // The SF buffer and the TMA descriptor keep the host's per-64 layout (24
    // group slots); only slots 0..11 are used, so no host change is needed.
    // Decode keeps its per-64 path untouched.
    constexpr bool kL2ActsSF128 = kDynamicL2 and kL2ArrivalCounter and
        BLOCK_M == 128 and BLOCK_N == 256 and (kNumEpilogueThreads == 512 or kPrefill2WG) and kReuseAccumAsFinal;
    DG_STATIC_ASSERT(not kPrefill2WG or (kL2ActsSF128 and kNumDispatchThreads == 64 and kNumNonEpilogueThreads == 64),
                     "The Prefill 2-warpgroup path needs the host's Prefill flags (arrival counter, one expert wave, "
                     "no SwapAB) and 64 dispatch + 64 loader threads");

    // =====================================================================
    // Thread / warp identification
    // =====================================================================
    const uint32_t sm_idx     = blockIdx.x;
    const uint32_t thread_idx = threadIdx.x;
    const uint32_t warp_idx   = cutlass::canonical_warp_idx_sync();
    const uint32_t lane_idx   = ptx::get_lane_idx();

    // Prefetch all TMA descriptors at the very beginning
    if (warp_idx == 0 and cute::elect_one_sync()) {
        cute::prefetch_tma_descriptor(&tensor_map_l1_acts);
        cute::prefetch_tma_descriptor(&tensor_map_l1_acts_sf);
        cute::prefetch_tma_descriptor(&tensor_map_l1_weights);
        cute::prefetch_tma_descriptor(&tensor_map_l1_output);
        cute::prefetch_tma_descriptor(&tensor_map_l2_acts);
        cute::prefetch_tma_descriptor(&tensor_map_l2_acts_sf);
        cute::prefetch_tma_descriptor(&tensor_map_l2_weights);
    }

    // =====================================================================
    // Workspaces and symmetric buffer slicing (mirror SM100 layout, except SF
    // for L2 activations uses per-64 K granularity)
    // =====================================================================
    constexpr uint32_t SF_BLOCK_M = math::constexpr_align(BLOCK_M, 128u);
    constexpr uint32_t kNumPoolBlocks = kNumMaxPoolTokens / BLOCK_M;
    DG_STATIC_ASSERT(kNumMaxPoolTokens % BLOCK_M == 0, "Invalid SM90 MegaMoE pool size");
    DG_STATIC_ASSERT(kNumPaddedSFPoolTokens >= kNumPoolBlocks * SF_BLOCK_M,
                     "Invalid SM90 MegaMoE SF pool capacity");

    const auto workspace = layout::SM90Workspace(
        sym_buffer.get_base_ptr(), kNumRanks, kNumExperts, kNumMaxTokensPerRank, kNumTopk);

    constexpr auto fp8_token_layout              = layout::Data(kHidden);
    constexpr auto bf16_token_layout             = layout::Data(kHidden * sizeof(nv_bfloat16));
    constexpr auto fp8_intermediate_token_layout = layout::Data(kIntermediateHidden);
    // Per-128 K float SF: 4 bytes per per-128 group => `kHidden / 32` bytes/token (same as SM100 packing)
    constexpr auto fp8_sf_layout                 = layout::Data(kHidden / 32);
    // Per-64 K float SF (SM90 only): 4 bytes per per-64 group => `kIntermediateHidden / 16` bytes/token
    constexpr auto fp8_intermediate_sf_layout    = layout::Data(kIntermediateHidden / 16);
    constexpr auto input_topk_idx_layout         = layout::Data(kNumTopk * sizeof(int64_t), false);
    constexpr auto input_topk_weights_layout     = layout::Data(kNumTopk * sizeof(float), false);
    constexpr auto l1_topk_weights_layout        = layout::Data(sizeof(float), false);

    // Registered input area
    const auto input_token_buffer        = layout::Buffer(fp8_token_layout, 1, kNumMaxTokensPerRank, workspace.get_end_ptr());
    const auto input_sf_buffer           = layout::Buffer(fp8_sf_layout, 1, kNumMaxTokensPerRank, input_token_buffer.get_end_ptr());
    const auto input_topk_idx_buffer     = layout::Buffer(input_topk_idx_layout, 1, kNumMaxTokensPerRank, input_sf_buffer.get_end_ptr());
    const auto input_topk_weights_buffer = layout::Buffer(input_topk_weights_layout, 1, kNumMaxTokensPerRank, input_topk_idx_buffer.get_end_ptr());

    // L1 input area
    const auto l1_token_buffer        = layout::Buffer(fp8_token_layout, 1, kNumMaxPoolTokens, input_topk_weights_buffer.get_end_ptr());
    const auto l1_sf_buffer           = layout::Buffer(fp8_sf_layout, 1, kNumPaddedSFPoolTokens, l1_token_buffer.get_end_ptr());
    const auto l1_topk_weights_buffer = layout::Buffer(l1_topk_weights_layout, 1, kNumMaxPoolTokens, l1_sf_buffer.get_end_ptr());

    // L2 input area
    const auto l2_token_buffer = layout::Buffer(fp8_intermediate_token_layout, 1, kNumMaxPoolTokens, l1_topk_weights_buffer.get_end_ptr());
    const auto l2_sf_buffer    = layout::Buffer(fp8_intermediate_sf_layout, 1, kNumPaddedSFPoolTokens, l2_token_buffer.get_end_ptr());

    // Combine input area
    const auto combine_token_buffer = layout::Buffer(bf16_token_layout, kNumTopk, kNumMaxTokensPerRank, l2_sf_buffer.get_end_ptr());

    // =====================================================================
    // GEMM data types and shape constants
    // =====================================================================
    using a_dtype_t = cutlass::float_e4m3_t;
    using b_dtype_t = cutlass::float_e4m3_t;
    // Each Decode math WG owns a complete M64/N128 task and SF64 group.
    // Its paired load warp owns all A/B/SF traffic on a private three-stage queue.
    constexpr bool kIndependentWG = kNumStages == 6 and kHidden == 4096 and kIntermediateHidden == 1536 and kNumRanks == 4 and kNumExperts == 128 and kNumTopk == 8 and kFP8SwapAB and BLOCK_M == 64 and BLOCK_N == 128 and kNumEpilogueWarpgroups == 2;
    constexpr uint32_t kTaskQueues = kIndependentWG ? 2 : 1;
    constexpr uint32_t kQueueStages = kIndependentWG ? 3 : kNumStages;
    DG_STATIC_ASSERT(not kIndependentWG or (kNumDispatchThreads == 64 and kNumNonEpilogueThreads == 64), "Independent WG requires two dispatch and two load warps");
    DG_STATIC_ASSERT(not kIndependentWG or (not kSplitPhaseHotPath and not kL2ArrivalCounter and not kReuseAccumAsFinal), "Independent WG requires dynamic Decode scheduling, mask arrivals and explicit accumulators");
    const uint32_t task_queue = kIndependentWG ? (warp_idx < 4 ? warp_idx % 2 : (warp_idx - 4) / 4) : 0;
    constexpr bool kSplitNWarpgroups =
        BLOCK_M == 64 and kNumEpilogueWarpgroups > 1 and
        BLOCK_N % kNumEpilogueWarpgroups == 0 and
        ((BLOCK_N / kNumEpilogueWarpgroups == 64) or (BLOCK_N / kNumEpilogueWarpgroups == 128));
    constexpr bool kSplitMNWarpgroups =
        BLOCK_M == 128 and BLOCK_N == 256 and kNumEpilogueWarpgroups == 4;
    constexpr uint32_t kWarpgroupSplitM = kSplitNWarpgroups ? 1 :
        (kSplitMNWarpgroups ? 2 : kNumEpilogueWarpgroups);
    constexpr uint32_t kWarpgroupSplitN = kSplitNWarpgroups ? kNumEpilogueWarpgroups :
        (kSplitMNWarpgroups ? 2 : 1);
    constexpr uint32_t WG_BLOCK_M = BLOCK_M / kWarpgroupSplitM;
    constexpr uint32_t WG_BLOCK_N = kIndependentWG ? BLOCK_N : BLOCK_N / kWarpgroupSplitN;
    constexpr uint32_t kNumCombineWarps = kNumEpilogueWarps;
    using L1WGMMA   = typename mma::sm90::FP8MMASelector<WG_BLOCK_N>::type;  // M=64, N=WG_BLOCK_N, K=32
    using L2WGMMA   = typename mma::sm90::FP8MMASelector<WG_BLOCK_N>::type;
    // kPrefill2WG publishes every FC1 tile per warp (16 rows each, see its L1 epilogue).
    constexpr uint32_t kL1OutputArrivalParts = kPrefill2WG ? 4 : 1;
    static_assert(L1WGMMA::M == 64 and L1WGMMA::N == WG_BLOCK_N and L1WGMMA::K == 32,
                  "Unexpected WGMMA shape");
    DG_STATIC_ASSERT(kWarpgroupSplitM * kWarpgroupSplitN == kNumEpilogueWarpgroups,
                     "Invalid warpgroup split");
    DG_STATIC_ASSERT(WG_BLOCK_M == L1WGMMA::M,
                     "Each warpgroup must run exactly one WGMMA-M tile");
    DG_STATIC_ASSERT(kNumCombineWarps <= kNumEpilogueWarps,
                     "Combine warp count must fit in epilogue warps");

    // Cluster=1 -> no multicast, A/B are loaded full-sized
    constexpr uint32_t LOAD_BLOCK_M    = BLOCK_M;
    constexpr uint32_t LOAD_BLOCK_N    = BLOCK_N;
    constexpr uint32_t L1_OUT_BLOCK_N  = BLOCK_N / 2;  // post-SwiGLU
    constexpr uint32_t WG_L1_OUT_BLOCK_N = WG_BLOCK_N / 2;
    // When WG_L1_OUT_BLOCK_N < 64 the two N-split warpgroups jointly own a
    // single per-64 L2-acts SF group, so they must publish ONE shared SF slot
    // (k_sf_idx == n_block_idx) instead of one per warpgroup. The amax that
    // feeds that shared SF must be reduced across both warpgroups.
    constexpr bool kSplitNSharesSF = kSplitNWarpgroups and (WG_L1_OUT_BLOCK_N < 64);
    constexpr bool kSwapABEligible =
        kFP8SwapAB and kSplitNWarpgroups and (BLOCK_M == 64) and (BLOCK_N == 128) and
        (kWarpgroupSplitN == 2);
    DG_STATIC_ASSERT(not kFP8SwapAB or kSwapABEligible,
                     "SwapAB requires M64/N128 with two split-N warpgroups");
    constexpr bool kSwapABActive = kSwapABEligible;

    // Decode-only changes (SwapAB geometry; Prefill code is untouched).
    constexpr bool kDecodeTail = kSwapABActive;
    // Next dynamically assigned Decode block (minus kNumSMs), in the L2 arrival-mask slots
    // past this geometry's pool blocks: the workspace sizes those slots for the smallest
    // candidate BLOCK_M (8), so with BLOCK_M 64 they are allocated, zeroed with the buffer
    // and never touched otherwise. SM 0 resets it during cleanup. Computed at each use:
    // keeping the pointer live costs registers in the 48-register dispatch and 168-register
    // math regions.
    DG_STATIC_ASSERT(not kDecodeTail or kNumPoolBlocks + 1 <= kNumMaxPoolTokens / layout::kMinCandidateBlockM,
                     "No spare workspace slot for the Decode block counter");
    const auto decode_block_counter = [&]() {
        return reinterpret_cast<uint32_t*>(workspace.get_l2_arrival_mask_ptr(kNumPoolBlocks));
    };
    constexpr uint32_t kSwapABTokenChunks = BLOCK_M / 8;
    DG_STATIC_ASSERT(not kSwapABEligible or (BLOCK_M % 8 == 0),
                     "swapAB epilogue token chunks assume BLOCK_M is a multiple of 8");
    constexpr uint32_t kSwizzleAMode   = BLOCK_K * sizeof(a_dtype_t);   // 128
    constexpr uint32_t kSwizzleBMode   = BLOCK_K * sizeof(b_dtype_t);   // 128
    constexpr uint32_t kSwizzleCDMode  = 128;
    constexpr uint32_t kGranK          = 128;          // L1 acts SF, weights SF
    constexpr uint32_t kL2ActsSFGranK  = 64;           // L2 acts SF (per-64 K, SM90 only)

    // =====================================================================
    // Shared memory layout
    // =====================================================================
    constexpr uint32_t kSharedMemoryAlignment = 1024;
    extern __shared__ __align__(kSharedMemoryAlignment) uint8_t smem_buffer[];

    constexpr uint32_t SMEM_EXPERT_COUNT_SIZE =
        math::constexpr_align<uint32_t>(kNumExperts * sizeof(uint32_t), kSharedMemoryAlignment);
    constexpr uint32_t SMEM_SEND_BUFFER_SIZE =
        math::constexpr_align(fp8_token_layout.get_num_bytes() * kNumDispatchWarps, kSharedMemoryAlignment);
    constexpr uint32_t SMEM_A_SIZE_PER_STAGE = LOAD_BLOCK_M * BLOCK_K * sizeof(a_dtype_t);
    constexpr uint32_t SMEM_B_SIZE_PER_STAGE = LOAD_BLOCK_N * BLOCK_K * sizeof(b_dtype_t);
    // SFA per-stage must be sized for the larger of L1 (BLOCK_M floats) and L2 (2*BLOCK_M floats per-64).
    constexpr uint32_t SMEM_SFA_SIZE_PER_STAGE =
        math::constexpr_align<uint32_t>(2 * BLOCK_M * sizeof(float), 128u);
    // Block (128, 128) weight SF is loaded directly from global by the math
    // warpgroup, so no SMEM is needed.
    constexpr uint32_t SMEM_SFB_SIZE_PER_STAGE = 0;

    // CD output: max of L1 FP8 (BLOCK_M * (BLOCK_N/2) * 1 byte), L2 BF16
    // (BLOCK_M * BLOCK_N * 2 bytes), and the swapAB L1 FP32+FP8 staging
    // buffers. Split-M warpgroups own disjoint row slices; shared-SF split-N
    // warpgroups stage disjoint column slices into one CTA tile.
    constexpr uint32_t SMEM_CD_L1_SIZE = BLOCK_M * L1_OUT_BLOCK_N * sizeof(cutlass::float_e4m3_t);
    constexpr uint32_t SMEM_CD_L2_SIZE = BLOCK_M * BLOCK_N * sizeof(nv_bfloat16);
    constexpr uint32_t SMEM_CD_SWAP_L1_FP32_SIZE =
        kSwapABActive ? BLOCK_M * L1_OUT_BLOCK_N * sizeof(float) : 0;
    constexpr uint32_t SMEM_CD_SWAP_L1_FP8_SIZE =
        kSwapABActive ? BLOCK_M * L1_OUT_BLOCK_N * sizeof(cutlass::float_e4m3_t) : 0;
    constexpr uint32_t SMEM_CD_SWAP_L1_SIZE =
        kSwapABActive ? (SMEM_CD_SWAP_L1_FP32_SIZE + SMEM_CD_SWAP_L1_FP8_SIZE) : 0;
    constexpr uint32_t SMEM_CD_BASE_SIZE =
        SMEM_CD_L1_SIZE > SMEM_CD_L2_SIZE ? SMEM_CD_L1_SIZE : SMEM_CD_L2_SIZE;
    // kPrefill2WG with four stages (host DG_SM90_PREFILL_4STAGE=1): the CD area
    // is only the per-warp 16-row x 144-byte slices (18 KiB) that the FC1
    // epilogue stages through, and the FC2 epilogue passes its BF16 tile through
    // the same slices in four 64-column steps. The 46 KiB freed from the 64 KiB
    // BF16 tile buys the fourth 48 KiB A/B stage. Three stages are unchanged.
    constexpr bool kPrefillWarpCD = kPrefill2WG and kNumStages == 4;
    constexpr uint32_t kPrefillWarpCDRowBytes = 128 + 16;
    // Host DG_SM90_PREFILL_LEAN=1 (four-stage EP1 tile): drop the
    // cross-rank machinery a single rank does not need, with the same bytes everywhere.
    //  * Every CTA adds its per-expert counts straight into the receive sums that the
    //    scheduler polls (ready at kNumSMs arrivals, as with SM 0's single sum before),
    //    so SM 0's republication with system-scope atomics, its self-signal and the
    //    second dispatch grid sync go away; the slot offsets are the same atomic returns.
    //  * The pull loop takes rank 0 and the slot itself instead of the rank round robin.
    //  * Before the combine, the grid sync after SM 0's self-signal goes away.
    //  * The FC2 staging writes each four n8 chunks with one stmatrix.x4 (16 per tile
    //    instead of 64 STS.32), same bytes at the same slice offsets.
    DG_STATIC_ASSERT(not kPrefillLean or (kPrefillWarpCD and kNumRanks == 1),
                     "The lean path is the four-stage EP1 tile");
    // Host DG_SM90_PREFILL_TAIL_PAIR=1 (on top of the lean path): pool blocks with at most
    // 64 valid rows run N blocks in pairs on both warpgroups (see
    // sm90_fp8_mega_moe_tail_pair). Each warpgroup computes its N block exactly as the one
    // working warpgroup of such a tile did (same rows, B bytes, K order, scales, epilogue),
    // so the outputs are the same bytes. The FC2 A loader's arrival count is unchanged: a
    // tail block gets 4 arrivals per warpgroup per N block either way (12 x 4).
    DG_STATIC_ASSERT(not kPrefillTailPair or kPrefillLean, "Tail pairing is layered on the lean path");
    // Host DG_SM90_PREFILL_SPLIT_ACCUM=1 (on top of the lean path, without tail pairing): the
    // unpaired FC1/FC2 K loops issue each warpgroup's m64n256 accumulator as two m64n128 halves
    // (B rows 0..127 and 128..255 of the same stage). The carried-scale rescale of half h of K
    // block k waits only for half h of K block k-1 (wgmma.wait_group 1) while the other half and
    // the other warpgroup keep the tensor core busy; the serving loop's rescale of all 128
    // accumulators sat between two WGMMA groups of the same warpgroup (a mainloop model without
    // the rescale ran 17% faster: kernels/probes/megamoe-mainloop.cu, Genkai 40978170082). Every
    // output element gets the same products, K order, ratios and final scale: the same bytes.
    // ptxas tracks WGMMA groups only in straight-line code (a group pending across a loop edge or
    // a branch around a rescale makes it serialize every WGMMA), so K blocks run in unrolled
    // chunks, drained at the chunk end. The math warpgroups take 224 registers.
    DG_STATIC_ASSERT(not kPrefillSplitAccum or (kPrefillLean and not kPrefillTailPair),
                     "The split accumulator is layered on the lean path without tail pairing");
    constexpr uint32_t kL1SplitUnroll = 8, kL2SplitUnroll = 12;
    constexpr uint32_t SMEM_CD_PER_QUEUE = kPrefillWarpCD ?
        math::constexpr_align(kNumEpilogueWarps * 16 * kPrefillWarpCDRowBytes, kSharedMemoryAlignment) :
        math::constexpr_align(
        SMEM_CD_BASE_SIZE > SMEM_CD_SWAP_L1_SIZE ? SMEM_CD_BASE_SIZE : SMEM_CD_SWAP_L1_SIZE,
        kSharedMemoryAlignment);

    constexpr uint32_t SMEM_CD_SIZE = kTaskQueues * SMEM_CD_PER_QUEUE;

    constexpr uint32_t SMEM_BEFORE_BARRIER_SIZE =
        SMEM_EXPERT_COUNT_SIZE + SMEM_SEND_BUFFER_SIZE + SMEM_CD_SIZE +
        kNumStages * (SMEM_A_SIZE_PER_STAGE + SMEM_B_SIZE_PER_STAGE);

    // SMEM pointers
    auto smem_expert_count = reinterpret_cast<uint32_t*>(smem_buffer);
    // Dynamic FC2 claims travel from the A loader (which claims) to the B loader
    // and the math warps through a small ring at the end of the padding after
    // the expert counters (the 128 bytes right after the counters stay free for
    // instrumentation). The combine below starts past this padding when kDynamicL2.
    constexpr uint32_t kL2RingSlots = 2;
    constexpr uint32_t kL2RingOffset = SMEM_EXPERT_COUNT_SIZE - 64;
    constexpr uint32_t kL2RingBarrierOffset = kL2RingOffset + 2 * kL2RingSlots * sizeof(uint32_t);
    DG_STATIC_ASSERT(not kDynamicL2 or
                     (kL2RingOffset % 8 == 0 and kL2RingOffset >= kNumExperts * sizeof(uint32_t) + 128 and
                      kL2RingBarrierOffset + 2 * kL2RingSlots * sizeof(Barrier) <= SMEM_EXPERT_COUNT_SIZE),
                     "No room for the dynamic FC2 ring");
    auto smem_l2_ring = reinterpret_cast<uint32_t*>(smem_buffer + kL2RingOffset);
    auto l2_ring_full_barriers = utils::PatternVisitor([=](const uint32_t& i) {
        return reinterpret_cast<Barrier*>(smem_buffer + kL2RingBarrierOffset) + i;
    });
    auto l2_ring_empty_barriers = utils::PatternVisitor([=](const uint32_t& i) {
        return reinterpret_cast<Barrier*>(smem_buffer + kL2RingBarrierOffset) + kL2RingSlots + i;
    });
    // The combine buffers start after the expert-count region whenever it holds a block-assignment ring
    // (Prefill dynamic FC2 claims, Decode dynamic block assignment): the rings' last barrier arrivals are
    // not ordered before the combine.
    constexpr uint32_t kCombineSmemOffset = (kDynamicL2 or kDecodeTail) ? SMEM_EXPERT_COUNT_SIZE : 0;
    // Qwen Prefill only: continuous paired-load combine (see the COMBINE section).
    constexpr bool kPairedCombine = kSpecializePhase and not kFP8SwapAB;

    // Decode block-assignment ring (4 slots + full/empty barriers) in the spare bytes of the
    // expert-count region, past the expert counters and the bench timeline's counters.
    constexpr uint32_t kDecodeRingDepth = 4;
    constexpr uint32_t kDecodeRingOffset = 768;
    DG_STATIC_ASSERT(not kDecodeTail or (kNumExperts * sizeof(uint32_t) + 128 <= kDecodeRingOffset and
                     kDecodeRingOffset + 32 + kTaskQueues * kDecodeRingDepth * 2 * sizeof(Barrier) <= SMEM_EXPERT_COUNT_SIZE),
                     "No spare shared memory for the Decode block ring");
    auto decode_ring_slots = reinterpret_cast<uint32_t*>(smem_buffer + kDecodeRingOffset);
    auto decode_ring_full = reinterpret_cast<Barrier*>(smem_buffer + kDecodeRingOffset + 32);
    auto decode_ring_empty = decode_ring_full + kTaskQueues * kDecodeRingDepth;
    const auto smem_send_buffers = layout::Buffer(
        fp8_token_layout, kNumDispatchWarps, 1,
        math::advance_ptr(smem_buffer, SMEM_EXPERT_COUNT_SIZE));

    auto smem_gemm_base = math::advance_ptr(
        smem_buffer, SMEM_EXPERT_COUNT_SIZE + SMEM_SEND_BUFFER_SIZE);

    // CD output is shared by L1 (FP8) and L2 (BF16); reinterpret-cast as needed.
    auto smem_cd_base = math::advance_ptr(smem_gemm_base, task_queue * SMEM_CD_PER_QUEUE);
    auto smem_cd_l1 = reinterpret_cast<cutlass::float_e4m3_t*>(smem_cd_base);
    auto smem_cd_l2 = reinterpret_cast<nv_bfloat16*>(smem_cd_base);
    auto smem_cd_swap_l1_fp32 = reinterpret_cast<float*>(smem_cd_base);
    auto smem_cd_swap_l1_fp8 = reinterpret_cast<cutlass::float_e4m3_t*>(
        math::advance_ptr(smem_cd_base, SMEM_CD_SWAP_L1_FP32_SIZE));

    auto smem_a = utils::PatternVisitor([=](const uint32_t& i) {
        return math::advance_ptr<a_dtype_t>(smem_gemm_base, SMEM_CD_SIZE + i * SMEM_A_SIZE_PER_STAGE);
    });
    auto smem_b = utils::PatternVisitor([=](const uint32_t& i) {
        return math::advance_ptr<b_dtype_t>(smem_gemm_base, SMEM_CD_SIZE + kNumStages * SMEM_A_SIZE_PER_STAGE + i * SMEM_B_SIZE_PER_STAGE);
    });
    auto sf_start_ptr = math::advance_ptr<uint8_t>(smem_gemm_base,
        SMEM_CD_SIZE + kNumStages * (SMEM_A_SIZE_PER_STAGE + SMEM_B_SIZE_PER_STAGE));
    auto smem_sfa = utils::PatternVisitor([=](const uint32_t& i) {
        return reinterpret_cast<float*>(sf_start_ptr + i * SMEM_SFA_SIZE_PER_STAGE);
    });

    // Barriers live after SF (SFB is loaded directly from global, no SMEM)
    auto barrier_start_ptr = reinterpret_cast<Barrier*>(
        sf_start_ptr + kNumStages * SMEM_SFA_SIZE_PER_STAGE);
    auto dispatch_barriers = utils::PatternVisitor([=](const uint32_t& i) { return barrier_start_ptr + i; });
    auto full_barriers     = utils::PatternVisitor([=](const uint32_t& i) { return barrier_start_ptr + kNumDispatchWarps + i; });
    auto empty_barriers    = utils::PatternVisitor([=](const uint32_t& i) { return barrier_start_ptr + kNumDispatchWarps + kNumStages + i; });
    auto combine_barriers  = utils::PatternVisitor([=](const uint32_t& i) { return barrier_start_ptr + kNumDispatchWarps + kNumStages * 2 + i; });

    // =====================================================================
    // Initialization
    // =====================================================================
    if (warp_idx == 0) {
        // Clean expert-count shared memory
        #pragma unroll
        for (uint32_t i = lane_idx; i < kNumExperts; i += 32)
            ptx::st_shared(smem_expert_count + i, 0u);
    } else if (warp_idx == 1) {
        // Init dispatch m-barriers
        #pragma unroll
        for (uint32_t i = lane_idx; i < kNumDispatchWarps; i += 32)
            dispatch_barriers[i]->init(1);
        if constexpr (kDecodeTail) {
            // Full: the loader publishes a block. Independent queues have only their
            // own 128 math-thread readers; the shared queue also has the B warp.
            if (lane_idx < kTaskQueues * kDecodeRingDepth) {
                (decode_ring_full + lane_idx)->init(1);
                (decode_ring_empty + lane_idx)->init(kIndependentWG ? 128 : 32 + kNumEpilogueThreads);
            }
        }
        cutlass::arch::fence_barrier_init();
    } else if (warp_idx == 2) {
        // Init GEMM full/empty barriers and combine barriers
        if (cute::elect_one_sync()) {
            #pragma unroll
            for (uint32_t i = 0; i < kNumStages; ++ i) {
                // Shared queue: A and B producers each arrive. Independent queue:
                // one producer issues A+B+SF and accounts for all bytes.
                full_barriers[i]->init(kIndependentWG ? 1 : 2);
                // Each math warp arrives once per stage release.
                empty_barriers[i]->init(kIndependentWG ? 4 : kNumEpilogueWarps);
            }
            #pragma unroll
            for (uint32_t i = 0; i < kNumCombineWarps * 2; ++ i)
                combine_barriers[i]->init(1);
            if constexpr (kDynamicL2) {
                // Full: the A loader publishes. Empty: the B loader and every math warp.
                #pragma unroll
                for (uint32_t i = 0; i < kL2RingSlots; ++ i) {
                    l2_ring_full_barriers[i]->init(1);
                    l2_ring_empty_barriers[i]->init(1 + kNumEpilogueWarps);
                }
            }
        }
        cutlass::arch::fence_barrier_init();
    }
    __syncthreads();

    // =====================================================================
    // Scheduler (cluster=1)
    // =====================================================================
    constexpr uint32_t kNumExpertsPerLane = math::constexpr_ceil_div(kNumExpertsPerRank, 32u);
    constexpr uint32_t kNumL1BlockNs = L1_SHAPE_N / BLOCK_N;
    constexpr uint32_t kNumL2BlockNs = L2_SHAPE_N / BLOCK_N;
    constexpr uint32_t kNumL1BlockKs = L1_SHAPE_K / BLOCK_K;
    constexpr uint32_t kNumL2BlockKs = L2_SHAPE_K / BLOCK_K;
    auto scheduler = sched::MegaMoEScheduler<
        BLOCK_M, BLOCK_N, BLOCK_K,
        L1_SHAPE_N, L1_SHAPE_K,
        L2_SHAPE_N, L2_SHAPE_K,
        kNumExpertsPerRank, kNumExpertsPerWave,
        kNumSMs, kNumRanks,
        kNumExpertsPerLane, kNumL1BlockNs, kNumL2BlockNs,
        kNumL1BlockKs, kNumL2BlockKs,
        layout::SM90Workspace>(workspace);

    // Pipeline state shared by TMA loaders and math warpgroups
    uint32_t stage_idx = task_queue * kQueueStages, phase = 0;
    auto advance_pipeline = [&](uint32_t& k_block_idx) {
        ++ k_block_idx;
        stage_idx = stage_idx == (task_queue + 1) * kQueueStages - 1 ? task_queue * kQueueStages : stage_idx + 1;
        phase ^= stage_idx == task_queue * kQueueStages;
    };

    // Decode: dynamic block assignment. The static scheduler hands CTA i the blocks i,
    // i + kNumSMs, ... so CTAs with six FC1 and eight FC2 blocks (and the heavier experts)
    // finish up to ~10 us after the rest. Here each CTA starts with block sm_idx and then
    // claims the next unassigned block from a rank-wide counter before its A loader waits
    // for the current block's activations. The B loader can then prefetch the next block's
    // weights as soon as it has issued this block's weights, independently of A's progress.
    // The A loader passes the claimed index to the B loader and the math
    // warps through a shared-memory ring. The index space and its decoding are the
    // scheduler's own (FC1 blocks of a wave, then its FC2 blocks), a CTA's claims only grow,
    // and every block waits only on blocks with smaller indices, so the order is
    // deadlock-free. A block's arithmetic does not depend on which CTA runs it.
    auto decode_for_each_block = [&]<bool kClaimAhead = false>(const auto& func, const auto& next_block_delta) CUTLASS_LAMBDA_FUNC_INLINE {
        if constexpr (kIndependentWG)
            scheduler.block_idx = sm_idx * 2 + task_queue;
        scheduler.fetch_expert_recv_count();
        scheduler.set_expert_idx(0);
        while (true) {
            CUTE_TIE_DECL(scheduler.get_next_block(), block_phase, local_expert_idx, m_block_idx, n_block_idx);
            if (block_phase == sched::BlockPhase::None)
                break;
            // Arithmetic select: a `?:` of the two constants became a local-memory table.
            const uint32_t num_k_blocks = kNumL1BlockKs +
                static_cast<uint32_t>(block_phase == sched::BlockPhase::Linear2) * (kNumL2BlockKs - kNumL1BlockKs);
            // Only the A loader publishes ahead. B and math still consume after their
            // current block, so every role observes the same block stream and stage phases.
            uint32_t next_delta = 0;
            if constexpr (kClaimAhead)
                next_delta = next_block_delta();
            func(block_phase, local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
            // `get_next_block` already advanced by kNumSMs; the ring carries the remaining
            // unsigned correction (claimed - current - kNumSMs). Independent queues
            // can claim current+1, so this wraps; adding it to the scheduler's
            // already-advanced index gives the claimed task modulo uint32_t.
            if constexpr (not kClaimAhead)
                next_delta = next_block_delta();
            scheduler.block_idx += next_delta;
        }
    };
    // Ring position: slot = iteration % depth, phase parity = (iteration / depth) % 2.
    uint32_t decode_ring_iter = 0;
    uint32_t decode_global_block_idx = sm_idx * kTaskQueues + task_queue;  // A loader only
    auto decode_claim_block = [&]() {
        const uint32_t slot = task_queue * kDecodeRingDepth + decode_ring_iter % kDecodeRingDepth;
        uint32_t next_global_block_idx = 0;
        if (lane_idx == 0) {
            (decode_ring_empty + slot)->wait(((decode_ring_iter / kDecodeRingDepth) & 1) ^ 1);
            next_global_block_idx = atomicAdd(decode_block_counter(), 1u) + kNumSMs * kTaskQueues;
            ptx::st_shared(decode_ring_slots + slot, next_global_block_idx - decode_global_block_idx - kNumSMs);
            (decode_ring_full + slot)->arrive();
        }
        next_global_block_idx = __shfl_sync(0xffffffff, next_global_block_idx, 0);
        const uint32_t delta = next_global_block_idx - decode_global_block_idx - kNumSMs;
        decode_global_block_idx = next_global_block_idx;
        ++ decode_ring_iter;
        return delta;
    };
    auto decode_receive_block = [&]() {
        const uint32_t slot = task_queue * kDecodeRingDepth + decode_ring_iter % kDecodeRingDepth;
        (decode_ring_full + slot)->wait((decode_ring_iter / kDecodeRingDepth) & 1);
        const uint32_t delta = ptx::ld_shared(decode_ring_slots + slot);
        // Every reading thread releases the slot itself (no lane predicate to keep live).
        (decode_ring_empty + slot)->arrive();
        ++ decode_ring_iter;
        return delta;
    };

    // Intra-SM barrier indices (mirroring SM100)
    constexpr uint32_t kDispatchBarrierIdx              = 0;
    constexpr uint32_t kDispatchWithEpilogueBarrierIdx  = 1;
    constexpr uint32_t kEpilogueFullBarrierIdx          = 2;
    constexpr uint32_t kEpilogueWGBarrierStartIdx       = 3;

    // Cross-rank NVLink barrier tags
    constexpr uint32_t kBeforeDispatchPullBarrierTag    = 1;
    constexpr uint32_t kBeforeCombineReduceBarrierTag   = 2;
    constexpr uint32_t kAfterWorkspaceCleanBarrierTag   = 3;

    // Register reconfiguration counts (chosen to fit in 64512 reg budget).
    // For the 256-epilogue-thread split-N decode path:
    //   64*48 + 64*40 + 256*168 = 48640 <= 64512.
    // For the 512-epilogue-thread split-MN path, trim dispatch and loader roles
    // so launch bounds still leave enough WGMMA registers.
    // Reduced-thread decode (kNumThreads<=256) raises the launch-bounds
    // register ceiling to 65536/256=256; grant the epilogue warpgroup the full
    // 256 so the accumulator double-buffer fits without spilling.
    //   64*48 + 64*40 + 128*256 = 38400 <= 64512.
    constexpr uint32_t kNumEpilogueRegisters    =
        kEpilogueRegisterBudget == 0 ?
            (kNumEpilogueThreads == 512 ? 112 :
                (kNumEpilogueThreads == 256 ? (kPrefillSplitAccum ? 224 : 168) :
                    (kNumThreads <= 256u ? 256 : 208))) :
            kEpilogueRegisterBudget;
    // The 512-epilogue-thread path has only 3584 registers of headroom at
    // epilogue=112.  Raising epilogue to 120 is not viable without changing
    // the role topology: dispatch=24 stalls the split-MN path, while
    // non-epilogue=16 is below ptxas' setmaxnreg.dec legal minimum.
    constexpr uint32_t kNumDispatchRegisters =
        kNumEpilogueThreads == 512 ? 32 : 48;
    constexpr uint32_t kNumNonEpilogueRegisters =
        kNumEpilogueThreads == 512 ? 24 : 40;
    DG_STATIC_ASSERT(kNumDispatchRegisters * kNumDispatchThreads +
                     kNumNonEpilogueRegisters * kNumNonEpilogueThreads +
                     kNumEpilogueRegisters * kNumEpilogueThreads <= 64512,
                     "Too many registers");

    constexpr uint32_t kDispatchGridSyncIndex = 0;
    constexpr uint32_t kEpilogueGridSyncIndex = 1;
    // Grid-sync slot 3 is otherwise unused; Prefill uses it as the per-rank FC2
    // claim counter, reset with the rest of the workspace after the combine barrier.
    constexpr uint32_t kL2ClaimCounterIndex = 3;
    const auto take_l2_block = [&](uint32_t& ring_count) {
        const uint32_t slot = ring_count % kL2RingSlots;
        l2_ring_full_barriers[slot]->wait((ring_count / kL2RingSlots) & 1);
        const auto info = make_uint2(ptx::ld_shared(smem_l2_ring + slot * 2), ptx::ld_shared(smem_l2_ring + slot * 2 + 1));
        __syncwarp();
        if (lane_idx == 0)
            l2_ring_empty_barriers[slot]->arrive();
        __syncwarp();
        ++ ring_count;
        return info;
    };

    // =====================================================================
    // ROLE 1: DISPATCH WARPS
    //   Mirrors SM100 dispatch with two changes:
    //     * SF is per-128 channel float (no UTCCP transpose). We store the
    //       remote per-token SF directly into the local L1 SF buffer in
    //       MN-major layout: `local_sf[k_chunk * num_padded_sf_pool_tokens + token_idx]`.
    //     * The "token_idx_in_expert" → SF token index is now the simple
    //       per-block linear mapping (no 4×32 transpose).
    // =====================================================================
    if (warp_idx < kNumDispatchWarps) {
        cutlass::arch::warpgroup_reg_dealloc<kNumDispatchRegisters>();

        DG_STATIC_ASSERT(kNumTopk <= 32, "Invalid number of topk");
        constexpr uint32_t kNumActivateLanes = kNumTokensPerWarp * kNumTopk;
        const auto read_topk_idx = [&](const auto& process) {
            #pragma unroll
            for (uint32_t i = (sm_idx * kNumDispatchWarps + warp_idx) * kNumTokensPerWarp;
                 i < num_tokens;
                 i += kNumSMs * kNumDispatchWarps * kNumTokensPerWarp) {
                int expert_idx = -1;
                if (i + (lane_idx / kNumTopk) < num_tokens and lane_idx < kNumActivateLanes) {
                    expert_idx = static_cast<int>(
                        __ldg(input_topk_idx_buffer.get_base_ptr<int64_t>() + i * kNumTopk + lane_idx));
                    if (expert_idx >= 0)
                        process(i * kNumTopk + lane_idx, expert_idx);
                }
                __syncwarp();
            }
        };

        // Count tokens per expert
        read_topk_idx([&](const uint32_t& token_topk_idx, const int& expert_idx) {
            atomicAdd_block(smem_expert_count + expert_idx, 1);
        });
        ptx::sync_aligned(kNumDispatchThreads, kDispatchBarrierIdx);

        // Stake out per-expert SM offsets via global atomic
        #pragma unroll
        for (uint32_t i = thread_idx; i < kNumExperts; i += kNumDispatchThreads) {
            const uint64_t send_value = (1ull << 32) | static_cast<uint64_t>(smem_expert_count[i]);
            smem_expert_count[i] = static_cast<uint32_t>(
                ptx::atomic_add(kPrefillLean ? workspace.get_expert_recv_count_sum_ptr(i) : workspace.get_expert_send_count_ptr(i), send_value));
        }
        ptx::sync_aligned(kNumDispatchThreads, kDispatchBarrierIdx);

        // Write source token-topk indices to remote ranks
        read_topk_idx([&](const uint32_t& token_topk_idx, const int& expert_idx) {
            const auto dst_rank_idx = expert_idx / kNumExpertsPerRank;
            const auto dst_slot_idx = atomicAdd_block(smem_expert_count + expert_idx, 1);
            const auto dst_ptr = workspace.get_src_token_topk_idx_ptr(
                expert_idx % kNumExpertsPerRank, sym_buffer.rank_idx, dst_slot_idx);
            *sym_buffer.map(dst_ptr, dst_rank_idx) = token_topk_idx;
        });

        comm::grid_sync<kNumSMs, kDispatchGridSyncIndex>(
            workspace, sm_idx, thread_idx,
            [=]() { ptx::sync_aligned(kNumDispatchThreads, kDispatchBarrierIdx); }
        );

        if constexpr (not kPrefillLean) {
        if (sm_idx == 0) {
            #pragma unroll
            for (uint32_t i = thread_idx; i < kNumExperts; i += kNumDispatchThreads) {
                const auto dst_rank_idx = i / kNumExpertsPerRank;
                const auto dst_local_expert_idx = i % kNumExpertsPerRank;
                const auto expert_status = *workspace.get_expert_send_count_ptr(i);
                *sym_buffer.map(
                    workspace.get_expert_recv_count_ptr(sym_buffer.rank_idx, dst_local_expert_idx),
                    dst_rank_idx) = expert_status & 0xffffffff;
                ptx::atomic_add_sys(
                    sym_buffer.map(workspace.get_expert_recv_count_sum_ptr(dst_local_expert_idx), dst_rank_idx),
                    expert_status);
            }
        }
        ptx::sync_aligned(kNumDispatchThreads, kDispatchBarrierIdx);

        comm::nvlink_barrier<kNumRanks, kNumSMs, kNumDispatchThreads,
                             kDispatchGridSyncIndex, kBeforeDispatchPullBarrierTag>(
            workspace, sym_buffer, sm_idx, thread_idx,
            [=]() { ptx::sync_aligned(kNumDispatchThreads, kDispatchBarrierIdx); },
            false, true);
        }

        // Sync with epilogue warps before pulling tokens.
        ptx::sync_unaligned(kNumDispatchThreads + kNumEpilogueThreads, kDispatchWithEpilogueBarrierIdx);

        // Token / SF pull loop
        uint32_t pull_mbarrier_phase = 0;
        const auto pull_buffer = smem_send_buffers.get_rank_buffer(warp_idx).get_data_buffer(0);
        const auto pull_mbarrier = dispatch_barriers[warp_idx];

        scheduler.fetch_expert_recv_count();

        constexpr uint32_t kNumRanksPerLane = math::constexpr_ceil_div(kNumRanks, 32u);
        int      current_expert_idx = -1;
        uint32_t stored_rank_count[kNumRanksPerLane] = {};
        uint32_t expert_start_idx = 0, expert_end_idx = 0;
        uint32_t expert_pool_block_offset = 0;

        constexpr uint32_t kNumGlobalWarps = kNumSMs * kNumDispatchWarps;
        for (uint32_t token_idx = sm_idx * kNumDispatchWarps + warp_idx; ; token_idx += kNumGlobalWarps) {
                int old_expert_idx = current_expert_idx;
                while (token_idx >= expert_end_idx) {
                    if (++ current_expert_idx >= kNumExpertsPerRank)
                        break;
                    expert_pool_block_offset += math::ceil_div(expert_end_idx - expert_start_idx, BLOCK_M);
                    expert_start_idx = expert_end_idx;
                    expert_end_idx += scheduler.get_num_tokens(current_expert_idx);
                }
                if (current_expert_idx >= kNumExpertsPerRank)
                    break;

                uint32_t token_idx_in_expert = token_idx - expert_start_idx;
                uint32_t current_rank_in_expert_idx;
                uint32_t token_idx_in_rank;
                if constexpr (kPrefillLean) {
                    // One rank: the round robin below always picks rank 0 at the slot itself.
                    current_rank_in_expert_idx = 0;
                    token_idx_in_rank = token_idx_in_expert;
                } else {
                if (old_expert_idx != current_expert_idx) {
                    old_expert_idx = current_expert_idx;
                    #pragma unroll
                    for (uint32_t i = 0; i < kNumRanksPerLane; ++ i) {
                        const uint32_t j = i * 32 + lane_idx;
                        stored_rank_count[i] = j < kNumRanks ?
                            static_cast<uint32_t>(*workspace.get_expert_recv_count_ptr(j, current_expert_idx)) : 0;
                    }
                }

                // Round-robin rank selection (identical to SM100)
                uint32_t remaining[kNumRanksPerLane];
                #pragma unroll
                for (uint32_t i = 0; i < kNumRanksPerLane; ++ i)
                    remaining[i] = stored_rank_count[i];
                uint32_t offset = 0;
                uint32_t slot_idx = token_idx_in_expert;
                while (true) {
                    uint32_t num_actives_in_lane = 0;
                    uint32_t min_in_lane = 0xffffffff;
                    #pragma unroll
                    for (uint32_t i = 0; i < kNumRanksPerLane; ++ i) {
                        num_actives_in_lane += remaining[i] > 0;
                        if (remaining[i] > 0)
                            min_in_lane = cute::min(min_in_lane, remaining[i]);
                    }
                    const uint32_t num_active_ranks = __reduce_add_sync(0xffffffff, num_actives_in_lane);
                    const uint32_t length = __reduce_min_sync(0xffffffff, min_in_lane);

                    const uint32_t num_round_tokens = length * num_active_ranks;
                    if (slot_idx < num_round_tokens) {
                        const uint32_t slot_idx_in_round = slot_idx % num_active_ranks;
                        uint32_t num_seen_ranks = 0;
                        current_rank_in_expert_idx = 0;
                        #pragma unroll
                        for (uint32_t i = 0; i < kNumRanksPerLane; ++ i) {
                            const uint32_t mask = __ballot_sync(0xffffffff, remaining[i] > 0);
                            const uint32_t num_active_lanes = __popc(mask);
                            if (slot_idx_in_round >= num_seen_ranks and slot_idx_in_round < num_seen_ranks + num_active_lanes)
                                current_rank_in_expert_idx = i * 32 + __fns(mask, 0, slot_idx_in_round - num_seen_ranks + 1);
                            num_seen_ranks += num_active_lanes;
                        }
                        token_idx_in_rank = offset + (slot_idx / num_active_ranks);
                        break;
                    }
                    slot_idx -= num_round_tokens;
                    offset += length;
                    #pragma unroll
                    for (uint32_t i = 0; i < kNumRanksPerLane; ++ i)
                        remaining[i] -= cute::min(remaining[i], length);
                }
                }

                const uint32_t src_token_topk_idx = *workspace.get_src_token_topk_idx_ptr(
                    current_expert_idx, current_rank_in_expert_idx, token_idx_in_rank);
                const uint32_t src_token_idx = src_token_topk_idx / kNumTopk;
                const uint32_t src_topk_idx  = src_token_topk_idx % kNumTopk;

                const uint32_t pool_token_idx = expert_pool_block_offset * BLOCK_M + token_idx_in_expert;

                // Pull token data. Overlap a remote TMA load with SF copy and
                // then use TMA store to materialize the local L1 input.
                if (cute::elect_one_sync()) {
                    ptx::tma_load_1d(
                        pull_buffer.get_base_ptr(),
                        sym_buffer.map(input_token_buffer.get_data_buffer(src_token_idx).get_base_ptr(),
                                       current_rank_in_expert_idx),
                        pull_mbarrier, kHidden);
                }
                __syncwarp();

                // Copy SF: per-128 K floats, written linearly (no UTCCP transpose).
                constexpr uint32_t kNumSFFloats = kHidden / 128;
                DG_STATIC_ASSERT(kNumSFFloats > 0 and kHidden % 128 == 0, "Invalid SF");
                const auto remote_sf_ptr = sym_buffer.map(
                    input_sf_buffer.get_data_buffer(src_token_idx).get_base_ptr<float>(),
                    current_rank_in_expert_idx);
                const auto local_sf_ptr  = l1_sf_buffer.get_base_ptr<float>();
                const uint32_t pool_block_idx = expert_pool_block_offset + token_idx_in_expert / BLOCK_M;
                const uint32_t token_idx_in_block = token_idx_in_expert % BLOCK_M;
                const uint32_t sf_pool_token_idx = pool_block_idx * SF_BLOCK_M + token_idx_in_block;
                // The routing weight is not pulled into the L1 weight pool: since the late
                // FP32 top-k patch the combine reads it from the local input buffer, and nothing
                // reads that pool (komoriyuta's sm90-combine-parallel). The pool stays in the
                // buffer layout shared with the host.
                if constexpr (kSwapABActive) {
                    // Decode: load all remote SF values into registers first so that their
                    // NVLink round trips overlap each other and the token TMA load.
                    constexpr uint32_t kNumSFFloatsPerLane = math::constexpr_ceil_div(kNumSFFloats, 32u);
                    float sf_values[kNumSFFloatsPerLane];
                    #pragma unroll
                    for (uint32_t i = 0; i < kNumSFFloatsPerLane; ++ i) {
                        const uint32_t j = i * 32 + lane_idx;
                        if (j < kNumSFFloats)
                            sf_values[i] = remote_sf_ptr[j];
                    }
                    #pragma unroll
                    for (uint32_t i = 0; i < kNumSFFloatsPerLane; ++ i) {
                        const uint32_t j = i * 32 + lane_idx;
                        if (j < kNumSFFloats)
                            local_sf_ptr[j * kNumPaddedSFPoolTokens + sf_pool_token_idx] = sf_values[i];
                    }
                    __syncwarp();
                } else {
                #pragma unroll
                for (uint32_t i = 0; i < math::constexpr_ceil_div(kNumSFFloats, 32u); ++ i) {
                    const uint32_t j = i * 32 + lane_idx;
                    if (j < kNumSFFloats)
                        local_sf_ptr[j * kNumPaddedSFPoolTokens + sf_pool_token_idx] = remote_sf_ptr[j];
                }
                __syncwarp();
                }

                if (cute::elect_one_sync()) {
                    ptx::mbarrier_arrive_and_set_tx(pull_mbarrier, kHidden);
                    ptx::mbarrier_wait_and_flip_phase(pull_mbarrier, pull_mbarrier_phase);

                    ptx::tma_store_1d(
                        l1_token_buffer.get_data_buffer(pool_token_idx).get_base_ptr(),
                        pull_buffer.get_base_ptr(), pull_buffer.get_num_bytes());

                    *workspace.get_token_src_metadata_ptr(pool_token_idx) =
                        {current_rank_in_expert_idx, src_token_idx, src_topk_idx};

                    cute::tma_store_arrive();
                    ptx::tma_store_wait<0>();
                    ptx::red_add_rel(
                        workspace.get_l1_arrival_count_ptr(pool_block_idx), 1);
                }
                __syncwarp();
            }

        // Cleanup workspace, overlapping with combine.
        ptx::sync_unaligned(kNumDispatchThreads + kNumEpilogueThreads, kDispatchWithEpilogueBarrierIdx);

        DG_STATIC_ASSERT(kNumSMs > 1, "Invalid SM count");
        if (sm_idx == 0) {
            #pragma unroll
            for (uint32_t i = thread_idx; i < kNumExperts; i += kNumDispatchThreads)
                *workspace.get_expert_send_count_ptr(i) = 0;
            if constexpr (kDynamicL2) {
                if (thread_idx == 0)
                    *workspace.template get_grid_sync_count_ptr<kL2ClaimCounterIndex>() = 0;
            }
            // Every CTA's math has finished, so all of this call's claims are done.
            if constexpr (kDecodeTail) {
                if (thread_idx == 0)
                    *decode_block_counter() = 0;
            }
        } else {
            for (uint32_t i = sm_idx - 1; i < kNumExpertsPerRank; i += kNumSMs - 1) {
                const auto num_recv_tokens = static_cast<uint32_t>(
                    *workspace.get_expert_recv_count_sum_ptr(i));
                const auto num_recv_m_blocks = math::ceil_div(num_recv_tokens, BLOCK_M);

                expert_pool_block_offset = scheduler.get_pool_block_offset(i);

                ptx::sync_aligned(kNumDispatchThreads, kDispatchBarrierIdx);

                DG_STATIC_ASSERT(kNumDispatchWarps >= 2, "Not enough dispatch warps");
                if (warp_idx == 0) {
                    *workspace.get_expert_recv_count_sum_ptr(i) = 0;
                } else if (warp_idx == 1) {
                    if (cute::elect_one_sync() and cumulative_local_expert_recv_stats != nullptr)
                        ptx::red_add(cumulative_local_expert_recv_stats + i, static_cast<int>(num_recv_tokens));
                    __syncwarp();
                }

                for (uint32_t j = thread_idx; j < kNumRanks; j += kNumDispatchThreads)
                    *workspace.get_expert_recv_count_ptr(j, i) = 0;
                __syncwarp();

                for (uint32_t j = thread_idx; j < num_recv_m_blocks; j += kNumDispatchThreads) {
                    *workspace.get_l1_arrival_count_ptr(expert_pool_block_offset + j) = 0;
                    *workspace.get_l2_arrival_mask_ptr(expert_pool_block_offset + j) = 0;
                }
                __syncwarp();
            }
        }

        comm::nvlink_barrier<kNumRanks, kNumSMs, kNumDispatchThreads,
                             kDispatchGridSyncIndex, kAfterWorkspaceCleanBarrierTag>(
            workspace, sym_buffer, sm_idx, thread_idx,
            [=]() { ptx::sync_aligned(kNumDispatchThreads, kDispatchBarrierIdx); },
            true, false);

    // =====================================================================
    // ROLE 2: GEMM TMA LOAD warps (load A+SFA, B+SFB)
    //   Warps inside `kNumNonEpilogueThreads`: warp 0 loads A + SFA,
    //   warp 1 loads B.
    // =====================================================================
    } else if (kIndependentWG and warp_idx >= kNumDispatchWarps and warp_idx < kNumDispatchWarps + 2) {
        cutlass::arch::warpgroup_reg_dealloc<kNumNonEpilogueRegisters>();
        auto process_task_load = [&](const auto& block_phase, const uint32_t& local_expert_idx, const uint32_t& num_k_blocks, const uint32_t& m_block_idx, const uint32_t& n_block_idx) CUTLASS_LAMBDA_FUNC_INLINE {
            const bool l2 = block_phase == sched::BlockPhase::Linear2;
            const uint32_t pool_block = scheduler.get_current_pool_block_offset() + m_block_idx;
            if (l2) {
                constexpr uint64_t expected = (1ull << kNumL1BlockNs) - 1ull;
                while (ptx::ld_acq_gpu(workspace.get_l2_arrival_mask_ptr(pool_block)) != expected);
            } else {
                const uint32_t expected = scheduler.template get_valid_m<false>();
                while (ptx::ld_acq(workspace.get_l1_arrival_count_ptr(pool_block)) != expected);
            }
            const auto acts = l2 ? &tensor_map_l2_acts : &tensor_map_l1_acts;
            const auto scales = l2 ? &tensor_map_l2_acts_sf : &tensor_map_l1_acts_sf;
            const auto weights = l2 ? &tensor_map_l2_weights : &tensor_map_l1_weights;
            const uint32_t weight_row = local_expert_idx * (l2 ? L2_SHAPE_N : L1_SHAPE_N) + n_block_idx * BLOCK_N;
            for (uint32_t k = 0; k < num_k_blocks; advance_pipeline(k)) {
                empty_barriers[stage_idx]->wait(phase ^ 1);
                if (cute::elect_one_sync()) {
                    tma::copy<BLOCK_K, LOAD_BLOCK_M, kSwizzleAMode, a_dtype_t>(acts, full_barriers[stage_idx], smem_a[stage_idx], k * BLOCK_K, pool_block * BLOCK_M, 1);
                    tma::copy<BLOCK_K, LOAD_BLOCK_N, kSwizzleBMode, b_dtype_t>(weights, full_barriers[stage_idx], smem_b[stage_idx], k * BLOCK_K, weight_row, 1);
                    tma::copy<BLOCK_M, 1, 0, float>(scales, full_barriers[stage_idx], smem_sfa[stage_idx], pool_block * SF_BLOCK_M, k * (l2 ? 2 : 1), 1);
                    if (l2)
                        tma::copy<BLOCK_M, 1, 0, float>(scales, full_barriers[stage_idx], smem_sfa[stage_idx] + BLOCK_M, pool_block * SF_BLOCK_M, k * 2 + 1, 1);
                    full_barriers[stage_idx]->arrive_and_expect_tx(SMEM_A_SIZE_PER_STAGE + SMEM_B_SIZE_PER_STAGE + BLOCK_M * sizeof(float) * (l2 ? 2 : 1));
                }
                __syncwarp();
            }
        };
        decode_for_each_block.template operator()<true>(process_task_load, decode_claim_block);
    } else if (warp_idx == kNumDispatchWarps) {
        cutlass::arch::warpgroup_reg_dealloc<kNumNonEpilogueRegisters>();

        auto process_a_sfa_block = [&](const auto& block_phase,
                                       const uint32_t& local_expert_idx,
                                       const uint32_t& num_k_blocks,
                                       const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
            const auto tensor_map_a_ptr = block_phase == sched::BlockPhase::Linear2
                ? &tensor_map_l2_acts : &tensor_map_l1_acts;
            const auto tensor_map_sfa_ptr = block_phase == sched::BlockPhase::Linear2
                ? &tensor_map_l2_acts_sf : &tensor_map_l1_acts_sf;

            const uint32_t pool_block_idx = scheduler.get_current_pool_block_offset() + m_block_idx;

            // Wait for the pool to be ready
            if (block_phase == sched::BlockPhase::Linear1) {
                const auto ptr = workspace.get_l1_arrival_count_ptr(pool_block_idx);
                const auto expected = scheduler.template get_valid_m<false>();
                while (ptx::ld_acq(ptr) != expected);
            } else {
                constexpr uint32_t kNumL1BlockNs = L1_SHAPE_N / BLOCK_N;
                if constexpr (kL2ArrivalCounter) {
                    const auto ptr = reinterpret_cast<const uint32_t*>(
                        workspace.get_l2_arrival_mask_ptr(pool_block_idx));
                    const uint32_t active_m_wgs = math::ceil_div(
                        scheduler.template get_valid_m<false>(), WG_BLOCK_M);
                    const uint32_t expected =
                        kNumL1BlockNs * active_m_wgs * kWarpgroupSplitN * kL1OutputArrivalParts;
                    while (ptx::ld_acq(ptr) != expected);
                    // kPrefill2WG writes the FC1 output tile with generic stores: order
                    // them (acquired above) before this warp's TMA loads of it.
                    if constexpr (kPrefill2WG)
                        asm volatile("fence.proxy.async.global;" ::: "memory");
                } else {
                    const auto ptr = workspace.get_l2_arrival_mask_ptr(pool_block_idx);
                    const uint64_t expected = (kNumL1BlockNs >= 64)
                        ? ~0ull : ((1ull << kNumL1BlockNs) - 1ull);
                    while (ptx::ld_acq_gpu(ptr) != expected);
                }
            }
            if constexpr (kPrefillTailPair) {
                if (sm90_fp8_mega_moe_tail_pair<WG_BLOCK_M>(scheduler.template get_valid_m<false>())) {
                    uint32_t slot = 0;
                    for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; ++ k_block_idx) {
                        empty_barriers[stage_idx]->wait(phase ^ 1);
                        if (cute::elect_one_sync()) {
                            tma::copy<BLOCK_K, LOAD_BLOCK_M, kSwizzleAMode, a_dtype_t>(
                                tensor_map_a_ptr, full_barriers[stage_idx], smem_a[stage_idx],
                                k_block_idx * BLOCK_K, pool_block_idx * BLOCK_M, 1);
                            tma::copy<BLOCK_M, 1, 0, float>(
                                tensor_map_sfa_ptr, full_barriers[stage_idx], smem_sfa[stage_idx],
                                pool_block_idx * SF_BLOCK_M, k_block_idx, 1);
                            full_barriers[stage_idx]->arrive_and_expect_tx(SMEM_A_SIZE_PER_STAGE + BLOCK_M * sizeof(float));
                        }
                        __syncwarp();
                        advance_pipeline(slot);
                        empty_barriers[stage_idx]->wait(phase ^ 1);
                        if (cute::elect_one_sync())
                            full_barriers[stage_idx]->arrive();
                        __syncwarp();
                        advance_pipeline(slot);
                    }
                    return;
                }
            }
            for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                empty_barriers[stage_idx]->wait(phase ^ 1);

                if (cute::elect_one_sync()) {
                    const uint32_t m_idx = pool_block_idx * BLOCK_M;
                    const uint32_t sfa_m_idx = pool_block_idx * SF_BLOCK_M;
                    const uint32_t k_idx = k_block_idx * BLOCK_K;

                    // TMA load A
                    tma::copy<BLOCK_K, LOAD_BLOCK_M, kSwizzleAMode, a_dtype_t>(
                        tensor_map_a_ptr, full_barriers[stage_idx], smem_a[stage_idx],
                        k_idx, m_idx, 1);

                    // TMA load SFA
                    if (block_phase == sched::BlockPhase::Linear1) {
                        // L1 SFA per-128: load (BLOCK_M, 1) at K=k_block_idx
                        tma::copy<BLOCK_M, 1, 0, float>(
                            tensor_map_sfa_ptr, full_barriers[stage_idx], smem_sfa[stage_idx],
                            sfa_m_idx, k_block_idx, 1);
                        full_barriers[stage_idx]->arrive_and_expect_tx(
                            SMEM_A_SIZE_PER_STAGE + BLOCK_M * sizeof(float));
                    } else if constexpr (kL2ActsSF128) {
                        // L2 SFA per-128: group slot k_block_idx of the per-64-sized buffer.
                        tma::copy<BLOCK_M, 1, 0, float>(
                            tensor_map_sfa_ptr, full_barriers[stage_idx], smem_sfa[stage_idx],
                            sfa_m_idx, k_block_idx, 1);
                        full_barriers[stage_idx]->arrive_and_expect_tx(
                            SMEM_A_SIZE_PER_STAGE + BLOCK_M * sizeof(float));
                    } else {
                        // L2 SFA per-64: descriptor box is (block_mn, 1) (see make_tma_sf_desc),
                        // so we must issue two single-group TMAs and place them at smem offsets
                        // 0 and BLOCK_M to match math's load offsets (`+ 0 * BLOCK_M` / `+ 1 * BLOCK_M`).
                        tma::copy<BLOCK_M, 1, 0, float>(
                            tensor_map_sfa_ptr, full_barriers[stage_idx], smem_sfa[stage_idx],
                            sfa_m_idx, k_block_idx * 2, 1);
                        tma::copy<BLOCK_M, 1, 0, float>(
                            tensor_map_sfa_ptr, full_barriers[stage_idx],
                            smem_sfa[stage_idx] + BLOCK_M,
                            sfa_m_idx, k_block_idx * 2 + 1, 1);
                        full_barriers[stage_idx]->arrive_and_expect_tx(
                            SMEM_A_SIZE_PER_STAGE + 2 * BLOCK_M * sizeof(float));
                    }
                }
                __syncwarp();
            }
        };

        if constexpr (kDynamicL2) {
            // The A loader is the first role to need the next FC2 block, so it
            // claims (one relaxed atomic per block, issued a block ahead so its
            // latency hides behind the current block), decodes and publishes it.
            DG_STATIC_ASSERT(kNumExpertsPerRank <= 256 and kNumL2BlockNs <= 256 and
                             kNumMaxPoolTokens / BLOCK_M <= 65536 and kNumRanks * kNumMaxTokensPerRank <= 65535,
                             "Dynamic FC2 block info does not fit the packed ring words");
            const auto claim_counter = workspace.template get_grid_sync_count_ptr<kL2ClaimCounterIndex>();
            uint32_t ring_count = 0, claimed = 0, num_l2_blocks = 0, prev_l2_block_idx = 0;
            sm90_fp8_mega_moe_for_each_block_dynamic_l2<kNumSMs, kNumL1BlockNs, kNumL1BlockKs, kNumL2BlockKs, kPrefillTailPair, WG_BLOCK_M>(
                scheduler,
                [&]() {
                    if (ring_count == 0) {
                        num_l2_blocks = scheduler.get_pool_block_offset(kNumExpertsPerRank) * kNumL2BlockNs;
                        if (lane_idx == 0)
                            claimed = atomicAdd(claim_counter, 1u);
                    }
                    const uint32_t l2_block_idx = __shfl_sync(0xffffffff, claimed, 0);
                    auto info = make_uint2(0xffffffffu, 0u);
                    if (l2_block_idx < num_l2_blocks)
                        info = sm90_fp8_mega_moe_decode_l2_block<kNumL2BlockNs>(scheduler, l2_block_idx, prev_l2_block_idx);
                    const uint32_t slot = ring_count % kL2RingSlots;
                    l2_ring_empty_barriers[slot]->wait(((ring_count / kL2RingSlots) & 1) ^ 1);
                    if (lane_idx == 0) {
                        ptx::st_shared(smem_l2_ring + slot * 2, info.x, info.y);
                        l2_ring_full_barriers[slot]->arrive();
                    }
                    __syncwarp();
                    ++ ring_count;
                    if (l2_block_idx < num_l2_blocks and lane_idx == 0)
                        claimed = atomicAdd(claim_counter, 1u);
                    return info;
                },
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_a_sfa_block(
                        std::integral_constant<sched::BlockPhase, sched::BlockPhase::Linear1>{},
                        local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                },
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_a_sfa_block(
                        std::integral_constant<sched::BlockPhase, sched::BlockPhase::Linear2>{},
                        local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                });
        } else if constexpr (kSpecializePhase) {
            sm90_fp8_mega_moe_for_each_block_split(
                scheduler,
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_a_sfa_block(
                        std::integral_constant<sched::BlockPhase, sched::BlockPhase::Linear1>{},
                        local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                },
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_a_sfa_block(
                        std::integral_constant<sched::BlockPhase, sched::BlockPhase::Linear2>{},
                        local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                });
        } else if constexpr (kDecodeTail) {
            decode_for_each_block.template operator()<true>(process_a_sfa_block, decode_claim_block);
        } else {
            scheduler.for_each_block([&](const sched::BlockPhase& block_phase,
                                         const uint32_t& local_expert_idx,
                                         const uint32_t& num_k_blocks,
                                         const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                process_a_sfa_block(block_phase, local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
            });
        }

    } else if (warp_idx == kNumDispatchWarps + 1) {
        cutlass::arch::warpgroup_reg_dealloc<kNumNonEpilogueRegisters>();

        const auto process_b_block = [&](const sched::BlockPhase& block_phase,
                                         const uint32_t& local_expert_idx,
                                         const uint32_t& num_k_blocks,
                                         const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
            const auto tensor_map_b_ptr =
                block_phase == sched::BlockPhase::Linear2 ? &tensor_map_l2_weights : &tensor_map_l1_weights;

            const uint32_t shape_n = block_phase == sched::BlockPhase::Linear2 ? L2_SHAPE_N : L1_SHAPE_N;

            if constexpr (kPrefillTailPair) {
                if (sm90_fp8_mega_moe_tail_pair<WG_BLOCK_M>(scheduler.template get_valid_m<false>())) {
                    DG_STATIC_ASSERT(LOAD_BLOCK_N == BLOCK_N and LOAD_BLOCK_N <= 256, "Paired tails load one B block per stage");
                    uint32_t slot = 0;
                    for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; ++ k_block_idx) {
                        #pragma unroll
                        for (uint32_t half = 0; half < 2; ++ half) {
                            empty_barriers[stage_idx]->wait(phase ^ 1);
                            if (cute::elect_one_sync()) {
                                tma::copy<BLOCK_K, LOAD_BLOCK_N, kSwizzleBMode, b_dtype_t>(
                                    tensor_map_b_ptr, full_barriers[stage_idx], smem_b[stage_idx],
                                    k_block_idx * BLOCK_K, local_expert_idx * shape_n + (n_block_idx + half) * BLOCK_N, 1);
                                full_barriers[stage_idx]->arrive_and_expect_tx(SMEM_B_SIZE_PER_STAGE);
                            }
                            __syncwarp();
                            advance_pipeline(slot);
                        }
                    }
                    return;
                }
            }

            for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                empty_barriers[stage_idx]->wait(phase ^ 1);

                if (cute::elect_one_sync()) {
                    const uint32_t n_idx = local_expert_idx * shape_n + n_block_idx * BLOCK_N;
                    const uint32_t k_idx = k_block_idx * BLOCK_K;

                    // TMA load B (weight SF is now loaded directly by math warps from global)
                    if constexpr (LOAD_BLOCK_N <= 256) {
                        tma::copy<BLOCK_K, LOAD_BLOCK_N, kSwizzleBMode, b_dtype_t>(
                            tensor_map_b_ptr, full_barriers[stage_idx], smem_b[stage_idx],
                            k_idx, n_idx, 1);
                    } else {
                        DG_STATIC_ASSERT(LOAD_BLOCK_N % 256 == 0,
                                         "Large B tiles are loaded as 256-column TMA slices");
                        #pragma unroll
                        for (uint32_t b_slice_idx = 0; b_slice_idx < LOAD_BLOCK_N / 256; ++ b_slice_idx) {
                            tma::copy<BLOCK_K, 256, kSwizzleBMode, b_dtype_t>(
                                tensor_map_b_ptr, full_barriers[stage_idx],
                                smem_b[stage_idx] + b_slice_idx * 256 * BLOCK_K,
                                k_idx, n_idx + b_slice_idx * 256, 1);
                        }
                    }

                    full_barriers[stage_idx]->arrive_and_expect_tx(SMEM_B_SIZE_PER_STAGE);
                }
                __syncwarp();
            }
        };

        if constexpr (kDynamicL2) {
            uint32_t ring_count = 0;
            sm90_fp8_mega_moe_for_each_block_dynamic_l2<kNumSMs, kNumL1BlockNs, kNumL1BlockKs, kNumL2BlockKs, kPrefillTailPair, WG_BLOCK_M>(
                scheduler,
                [&]() { return take_l2_block(ring_count); },
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_b_block(sched::BlockPhase::Linear1, local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                },
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_b_block(sched::BlockPhase::Linear2, local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                });
        } else if constexpr (kDecodeTail) {
            decode_for_each_block(process_b_block, decode_receive_block);
        } else {
            scheduler.for_each_block(process_b_block);
        }

    } else if (warp_idx < kNumDispatchWarps + kNumMMANonEpilogueWarps) {
        // Idle non-epilogue warps (kNumDispatchWarps+2, +3). They must still
        // participate in the warpgroup-collective `setmaxnreg.dec.sync.aligned`
        // so that the math warpgroup's `warpgroup_reg_alloc` can succeed.
        cutlass::arch::warpgroup_reg_dealloc<kNumNonEpilogueRegisters>();

    } else if (warp_idx >= kNumDispatchWarps + kNumMMANonEpilogueWarps) {
    // =====================================================================
    // ROLE 3: MATH WARPGROUPS (WGMMA + epilogue + combine)
    // =====================================================================
        cutlass::arch::warpgroup_reg_alloc<kNumEpilogueRegisters>();

        const uint32_t epilogue_warp_idx  = warp_idx - (kNumDispatchWarps + kNumMMANonEpilogueWarps);
        // Per-128 FC2 scales: the two warpgroups of a row pair exchange their
        // per-row amax through a double-buffered scratch (parity flips per FC1
        // tile so a fast warpgroup never overwrites a value its partner has not
        // read) and meet on named barrier 12 + pair (0/1 dispatch, 2 all math,
        // 3..6 per-warpgroup epilogue, 8..11 WGMMA turn order are taken).
        [[maybe_unused]] uint32_t l1_pair_parity = 0;
        constexpr uint32_t kPairAmaxBarrierStartIdx = 12;
        const uint32_t epilogue_wg_idx    = epilogue_warp_idx / 4;
        const uint32_t epilogue_thread_idx = epilogue_warp_idx * 32 + lane_idx;
        const uint32_t warp_idx_in_wg     = epilogue_warp_idx % 4;

        // WGMMA-output register layout helpers
        const uint32_t row_idx = lane_idx / 4;
        const uint32_t col_idx = lane_idx % 4;
        const uint32_t r_0 = warp_idx_in_wg * 16 + row_idx;
        const uint32_t r_1 = r_0 + 8;

        // When the two N-split warpgroups share a single per-64 SF group they
        // also stage into ONE shared row-major L1-output tile (stride
        // L1_OUT_BLOCK_N), each writing its own WG_L1_OUT_BLOCK_N-column half,
        // so a single combined TMA store matches the host descriptor box.
        constexpr uint32_t WG_SMEM_CD_L1_STRIDE_N =
            kSplitNSharesSF ? L1_OUT_BLOCK_N : WG_L1_OUT_BLOCK_N;
        constexpr uint32_t WG_SMEM_CD_L2_STRIDE_N = WG_BLOCK_N;

        // kPrefill2WG: every warp stores its 16 FC1 output rows itself and publishes
        // the arrival late, in the next FC1 tile's mainloop (K block 2) or before
        // the first FC2 block is taken, when the stores have long completed. Holds
        // the pool block of the unpublished rows, or ~0.
        [[maybe_unused]] uint32_t l1_unpublished_block = 0xffffffffu;
        [[maybe_unused]] const auto publish_l1_rows = [&]() {
            if (l1_unpublished_block != 0xffffffffu) {
                if (lane_idx == 0)
                    ptx::red_add_rel(reinterpret_cast<uint32_t*>(workspace.get_l2_arrival_mask_ptr(l1_unpublished_block)), 1);
                l1_unpublished_block = 0xffffffffu;
            }
        };

        // Sync with dispatch in the full communication path.
        ptx::sync_unaligned(kNumDispatchThreads + kNumEpilogueThreads, kDispatchWithEpilogueBarrierIdx);

        auto process_math_block = [&](const auto& block_phase,
                                      const uint32_t& local_expert_idx,
                                      const uint32_t& num_k_blocks,
                                      const uint32_t& m_block_idx, const uint32_t& item_n_block_idx) CUTLASS_LAMBDA_FUNC_INLINE {
            const uint32_t valid_m = scheduler.template get_valid_m<false>();
            // A paired tail: both warpgroups take rows 0..63, warpgroup g the N block n + g.
            const bool pair_tile = kPrefillTailPair and sm90_fp8_mega_moe_tail_pair<WG_BLOCK_M>(valid_m);
            const uint32_t n_block_idx = item_n_block_idx + (pair_tile ? epilogue_wg_idx : 0u);
            const uint32_t pool_block_idx = scheduler.get_current_pool_block_offset() + m_block_idx;
            const uint32_t m_idx = pool_block_idx * BLOCK_M;
            const uint32_t n_idx = n_block_idx * BLOCK_N;
            const uint32_t epilogue_wg_m_idx = (kIndependentWG or pair_tile) ? 0 : epilogue_wg_idx / kWarpgroupSplitN;
            const uint32_t epilogue_wg_n_idx = kIndependentWG ? 0 : epilogue_wg_idx - epilogue_wg_m_idx * kWarpgroupSplitN;
            const uint32_t wg_n_offset = epilogue_wg_n_idx * WG_BLOCK_N;
            const uint32_t wg_l1_out_n_offset = epilogue_wg_n_idx * WG_L1_OUT_BLOCK_N;
            const uint32_t row_base = epilogue_wg_m_idx * WG_BLOCK_M;
            const uint32_t row_offset_r0 = row_base + r_0;
            const uint32_t row_offset_r1 = row_base + r_1;
            const uint32_t sf_n_block_idx = (kIndependentWG or kSplitNSharesSF) ? n_block_idx
                : (n_block_idx * kWarpgroupSplitN + epilogue_wg_n_idx);
            const uint32_t smem_a_wg_offset = epilogue_wg_m_idx * WG_BLOCK_M * BLOCK_K;
            const uint32_t smem_b_wg_offset = epilogue_wg_n_idx * WG_BLOCK_N * BLOCK_K;
            // In the shared-tile case the WG stages into the joint L1-output tile
            // at its own column offset (row stride L1_OUT_BLOCK_N); otherwise each
            // WG owns a disjoint contiguous WG_BLOCK_M x WG_L1_OUT_BLOCK_N slice.
            const uint32_t smem_cd_l1_wg_offset = kSplitNSharesSF ? wg_l1_out_n_offset
                : (epilogue_wg_idx * WG_BLOCK_M * WG_L1_OUT_BLOCK_N);
            const uint32_t smem_cd_l2_wg_offset = kIndependentWG ? 0 : epilogue_wg_idx * WG_BLOCK_M * WG_BLOCK_N;
            const bool valid_r0 = row_offset_r0 < valid_m;
            const bool valid_r1 = row_offset_r1 < valid_m;

            // ---------------- GEMM ----------------
            using WGMMA = L1WGMMA;
            constexpr uint32_t kAccumPerThread = WGMMA::kNumAccum;
            float final_accum[kAccumPerThread] = {};

            if constexpr (kReuseAccumAsFinal) {
                auto prescale_l1_final = [&](const float& scale_a_0, const float& scale_a_1,
                                             const float& gate_sf, const float& up_sf) {
                    const float inv_s0_gate = kFastMath ? math::fast_rcp(scale_a_0 * gate_sf) : 1.0f / (scale_a_0 * gate_sf);
                    const float inv_s1_gate = kFastMath ? math::fast_rcp(scale_a_1 * gate_sf) : 1.0f / (scale_a_1 * gate_sf);
                    const float inv_s0_up = kFastMath ? math::fast_rcp(scale_a_0 * up_sf) : 1.0f / (scale_a_0 * up_sf);
                    const float inv_s1_up = kFastMath ? math::fast_rcp(scale_a_1 * up_sf) : 1.0f / (scale_a_1 * up_sf);
                    #pragma unroll
                    for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                        const float inv_s0 = (i & 1u) ? inv_s0_up : inv_s0_gate;
                        const float inv_s1 = (i & 1u) ? inv_s1_up : inv_s1_gate;
                        final_accum[i*4+0] *= inv_s0;
                        final_accum[i*4+1] *= inv_s0;
                        final_accum[i*4+2] *= inv_s1;
                        final_accum[i*4+3] *= inv_s1;
                    }
                };
                auto postscale_l1_final = [&](const float& scale_a_0, const float& scale_a_1,
                                              const float& gate_sf, const float& up_sf) {
                    const float s0_gate = scale_a_0 * gate_sf;
                    const float s1_gate = scale_a_1 * gate_sf;
                    const float s0_up = scale_a_0 * up_sf;
                    const float s1_up = scale_a_1 * up_sf;
                    #pragma unroll
                    for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                        const float s0 = (i & 1u) ? s0_up : s0_gate;
                        const float s1 = (i & 1u) ? s1_up : s1_gate;
                        final_accum[i*4+0] *= s0;
                        final_accum[i*4+1] *= s0;
                        final_accum[i*4+2] *= s1;
                        final_accum[i*4+3] *= s1;
                    }
                };
                auto prescale_l2_final = [&](const float& scale_a_0, const float& scale_a_1,
                                             const float& l2_sf) {
                    const float inv_s0 = kFastMath ? math::fast_rcp(scale_a_0 * l2_sf) : 1.0f / (scale_a_0 * l2_sf);
                    const float inv_s1 = kFastMath ? math::fast_rcp(scale_a_1 * l2_sf) : 1.0f / (scale_a_1 * l2_sf);
                    #pragma unroll
                    for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                        final_accum[i*4+0] *= inv_s0;
                        final_accum[i*4+1] *= inv_s0;
                        final_accum[i*4+2] *= inv_s1;
                        final_accum[i*4+3] *= inv_s1;
                    }
                };
                auto postscale_l2_final = [&](const float& scale_a_0, const float& scale_a_1,
                                              const float& l2_sf) {
                    const float s0 = scale_a_0 * l2_sf;
                    const float s1 = scale_a_1 * l2_sf;
                    #pragma unroll
                    for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                        final_accum[i*4+0] *= s0;
                        final_accum[i*4+1] *= s0;
                        final_accum[i*4+2] *= s1;
                        final_accum[i*4+3] *= s1;
                    }
                };
                auto rescale_l1_final = [&](const float& prev_scale_a_0, const float& prev_scale_a_1,
                                            const float& prev_gate_sf, const float& prev_up_sf,
                                            const float& scale_a_0, const float& scale_a_1,
                                            const float& gate_sf, const float& up_sf) {
                    const float r0_gate = (prev_scale_a_0 * prev_gate_sf) *
                        (kFastMath ? math::fast_rcp(scale_a_0 * gate_sf) : 1.0f / (scale_a_0 * gate_sf));
                    const float r1_gate = (prev_scale_a_1 * prev_gate_sf) *
                        (kFastMath ? math::fast_rcp(scale_a_1 * gate_sf) : 1.0f / (scale_a_1 * gate_sf));
                    const float r0_up = (prev_scale_a_0 * prev_up_sf) *
                        (kFastMath ? math::fast_rcp(scale_a_0 * up_sf) : 1.0f / (scale_a_0 * up_sf));
                    const float r1_up = (prev_scale_a_1 * prev_up_sf) *
                        (kFastMath ? math::fast_rcp(scale_a_1 * up_sf) : 1.0f / (scale_a_1 * up_sf));
                    #pragma unroll
                    for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                        const float r0 = (i & 1u) ? r0_up : r0_gate;
                        const float r1 = (i & 1u) ? r1_up : r1_gate;
                        final_accum[i*4+0] *= r0;
                        final_accum[i*4+1] *= r0;
                        final_accum[i*4+2] *= r1;
                        final_accum[i*4+3] *= r1;
                    }
                };
                auto rescale_l2_final = [&](const float& prev_scale_a_0, const float& prev_scale_a_1,
                                            const float& prev_l2_sf,
                                            const float& scale_a_0, const float& scale_a_1,
                                            const float& l2_sf) {
                    const float r0 = (prev_scale_a_0 * prev_l2_sf) *
                        (kFastMath ? math::fast_rcp(scale_a_0 * l2_sf) : 1.0f / (scale_a_0 * l2_sf));
                    const float r1 = (prev_scale_a_1 * prev_l2_sf) *
                        (kFastMath ? math::fast_rcp(scale_a_1 * l2_sf) : 1.0f / (scale_a_1 * l2_sf));
                    #pragma unroll
                    for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                        final_accum[i*4+0] *= r0;
                        final_accum[i*4+1] *= r0;
                        final_accum[i*4+2] *= r1;
                        final_accum[i*4+3] *= r1;
                    }
                };
                auto rescale_l2_act_final = [&](const float& prev_scale_a_0, const float& prev_scale_a_1,
                                                const float& scale_a_0, const float& scale_a_1) {
                    const float r0 = prev_scale_a_0 * (kFastMath ? math::fast_rcp(scale_a_0) : 1.0f / scale_a_0);
                    const float r1 = prev_scale_a_1 * (kFastMath ? math::fast_rcp(scale_a_1) : 1.0f / scale_a_1);
                    #pragma unroll
                    for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                        final_accum[i*4+0] *= r0;
                        final_accum[i*4+1] *= r0;
                        final_accum[i*4+2] *= r1;
                        final_accum[i*4+3] *= r1;
                    }
                };

                // Qwen Prefill (M128/N256, 4 math warpgroups, reused accumulator).
                // Same carried-scale arithmetic as the rescale path below, but the
                // next K block's scales are waited for, loaded and turned into
                // rescale ratios while the current WGMMA group runs, and the
                // shared-memory descriptors are advanced from one per-warpgroup
                // base instead of being rebuilt from pointers. Between WGMMA
                // groups only the accumulator multiply remains on the critical path.
                // The rescale path below keeps serving every other reuse geometry.
                constexpr bool kQwenPrefillMainloop =
                    kHidden == 4096 && kIntermediateHidden == 1536 && BLOCK_M == 128 &&
                    BLOCK_N == 256 && (kNumEpilogueThreads == 512 || kPrefill2WG) && kSpecializePhase;
                if constexpr (kQwenPrefillMainloop) {
                    if (pair_tile) {
                        if constexpr (kPrefillTailPair) {
                        // Paired tail mainloop: K block k waits on its stage pair (A, SFA and
                        // warpgroup 0's B in the first stage, warpgroup 1's B in the second),
                        // issues the m64n256 group of the warpgroup's N block on rows 0..63 and
                        // releases both stages. The carried-scale arithmetic per accumulator is
                        // the unpaired loop's: ratio (prev s_a * prev s_w) * rcp(s_a * s_w) for
                        // the next K block computed while the group runs, the same rescale before
                        // the next issue and the same final scale.
                        DG_STATIC_ASSERT(kPrefill2WG and kL2ActsSF128 and kNumEpilogueWarpgroups == 2 and
                                         kNumL1BlockNs % 2 == 0 and kNumL2BlockNs % 2 == 0, "Paired tail shape");
                        constexpr uint32_t kL1SFKBlocks = kHidden / 128, kL2SFKBlocks = kIntermediateHidden / 128;
                        constexpr uint32_t kL1SFPerExpert = (kIntermediateHidden * 2 / 128) * kL1SFKBlocks;
                        constexpr uint32_t kL2SFPerExpert = (kHidden / 128) * kL2SFKBlocks;
                        const bool l1 = block_phase == sched::BlockPhase::Linear1;
                        // Weight-SF rows: FC1 gate / up blocks (accumulator chunks alternate),
                        // FC2 the two 128-row blocks of the 256 columns (chunks 0..15, 16..31).
                        const float* w_sf = l1 ? l1_weights_sf : l2_weights_sf;
                        const uint32_t w_row_0 = l1 ? local_expert_idx * kL1SFPerExpert + n_block_idx * kL1SFKBlocks
                                                    : local_expert_idx * kL2SFPerExpert + n_block_idx * 2 * kL2SFKBlocks;
                        const uint32_t w_row_1 = w_row_0 + (l1 ? (kIntermediateHidden / 128) * kL1SFKBlocks : kL2SFKBlocks);
                        const auto pair_desc_a = mma::sm90::make_smem_desc(smem_a[0], 1);
                        const auto pair_desc_b = mma::sm90::make_smem_desc(smem_b[0], 1);
                        const uint32_t pair_a_lo = pair_desc_a.reg32_[0], pair_b_lo = pair_desc_b.reg32_[0];
                        const uint64_t pair_a_hi = static_cast<uint64_t>(pair_desc_a.reg32_[1]) << 32;
                        const uint64_t pair_b_hi = static_cast<uint64_t>(pair_desc_b.reg32_[1]) << 32;
                        auto next_of = [](const uint32_t& s) { return s == kNumStages - 1 ? 0u : s + 1; };
                        auto rcp = [](const float& x) { return kFastMath ? math::fast_rcp(x) : 1.0f / x; };
                        float prev_sa_0 = 1.0f, prev_sa_1 = 1.0f, prev_w_0 = 1.0f, prev_w_1 = 1.0f;
                        float r00 = 1.0f, r01 = 1.0f, r10 = 1.0f, r11 = 1.0f;
                        uint32_t slot = 0;
                        for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; ++ k_block_idx) {
                            const uint32_t a_stage = stage_idx, b_stage = epilogue_wg_idx == 0 ? stage_idx : next_of(stage_idx);
                            if (k_block_idx == 0) {
                                full_barriers[stage_idx]->wait(phase);
                                full_barriers[next_of(stage_idx)]->wait(phase ^ (next_of(stage_idx) == 0 ? 1u : 0u));
                            } else {
                                #pragma unroll
                                for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                                    const bool second = l1 ? (i & 1u) != 0 : i >= kAccumPerThread / 8;
                                    final_accum[i*4+0] *= second ? r01 : r00;
                                    final_accum[i*4+1] *= second ? r01 : r00;
                                    final_accum[i*4+2] *= second ? r11 : r10;
                                    final_accum[i*4+3] *= second ? r11 : r10;
                                }
                            }
                            {
                                const uint32_t a_lo = pair_a_lo + a_stage * (SMEM_A_SIZE_PER_STAGE / 16);
                                const uint32_t b_lo = pair_b_lo + b_stage * (SMEM_B_SIZE_PER_STAGE / 16);
                                #pragma unroll
                                for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                                ptx::warpgroup_arrive();
                                #pragma unroll
                                for (uint32_t k = 0; k < BLOCK_K / WGMMA::K; ++ k) {
                                    const uint32_t k_desc = k * WGMMA::K * static_cast<uint32_t>(sizeof(a_dtype_t)) / 16;
                                    WGMMA::wgmma(pair_a_hi | (a_lo + k_desc), pair_b_hi | (b_lo + k_desc), final_accum, true);
                                }
                                ptx::warpgroup_commit_batch();
                                #pragma unroll
                                for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            }
                            if (l1 and k_block_idx == 2)
                                publish_l1_rows();
                            if (k_block_idx == 0) {
                                prev_sa_0 = ptx::ld_shared(smem_sfa[a_stage] + r_0);
                                prev_sa_1 = ptx::ld_shared(smem_sfa[a_stage] + r_1);
                                prev_w_0 = __ldg(w_sf + w_row_0);
                                prev_w_1 = __ldg(w_sf + w_row_1);
                            }
                            if (k_block_idx + 1 < num_k_blocks) {
                                // The next pair starts two stages on.
                                const uint32_t next_0 = next_of(next_of(stage_idx));
                                const uint32_t next_1 = next_of(next_0);
                                const uint32_t phase_0 = phase ^ ((next_of(stage_idx) == 0 or next_0 == 0) ? 1u : 0u);
                                const uint32_t phase_1 = phase_0 ^ (next_1 == 0 ? 1u : 0u);
                                const float w_0 = __ldg(w_sf + w_row_0 + k_block_idx + 1);
                                const float w_1 = __ldg(w_sf + w_row_1 + k_block_idx + 1);
                                full_barriers[next_0]->wait(phase_0);
                                full_barriers[next_1]->wait(phase_1);
                                const float sa_0 = ptx::ld_shared(smem_sfa[next_0] + r_0);
                                const float sa_1 = ptx::ld_shared(smem_sfa[next_0] + r_1);
                                r00 = (prev_sa_0 * prev_w_0) * rcp(sa_0 * w_0);
                                r10 = (prev_sa_1 * prev_w_0) * rcp(sa_1 * w_0);
                                r01 = (prev_sa_0 * prev_w_1) * rcp(sa_0 * w_1);
                                r11 = (prev_sa_1 * prev_w_1) * rcp(sa_1 * w_1);
                                prev_sa_0 = sa_0;
                                prev_sa_1 = sa_1;
                                prev_w_0 = w_0;
                                prev_w_1 = w_1;
                            }
                            ptx::warpgroup_wait<0>();
                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();
                            advance_pipeline(slot);
                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();
                            advance_pipeline(slot);
                        }
                        if (num_k_blocks != 0) {
                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                                const bool second = l1 ? (i & 1u) != 0 : i >= kAccumPerThread / 8;
                                const float s0 = prev_sa_0 * (second ? prev_w_1 : prev_w_0);
                                const float s1 = prev_sa_1 * (second ? prev_w_1 : prev_w_0);
                                final_accum[i*4+0] *= s0;
                                final_accum[i*4+1] *= s0;
                                final_accum[i*4+2] *= s1;
                                final_accum[i*4+3] *= s1;
                            }
                        }
                        }
                    } else if (kPrefill2WG and row_base >= valid_m) {
                        // Padding-only WG: consume the shared stage stream, with
                        // identical phase advancement and four empty arrivals.
                        // Deferred FC1 publication belongs to the PREVIOUS tile
                        // and must still happen even if this tile has no rows.
                        for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                            full_barriers[stage_idx]->wait(phase);
                            if (block_phase == sched::BlockPhase::Linear1 and k_block_idx == 2)
                                publish_l1_rows();
                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();
                        }
                    } else {
                    // Not a paired tail: the warpgroup's N block is the item's (same expression
                    // as without kPrefillTailPair, so the unpaired K loops compile alike).
                    const uint32_t& n_block_idx = item_n_block_idx;
                    constexpr uint32_t kL1SFKBlocks   = kHidden / 128;
                    constexpr uint32_t kL2SFKBlocks   = kIntermediateHidden / 128;
                    constexpr uint32_t kL1SFGateBlks  = kIntermediateHidden / 128;
                    constexpr uint32_t kL1SFPerExpert = (kIntermediateHidden * 2 / 128) * kL1SFKBlocks;
                    constexpr uint32_t kL2SFPerExpert = (kHidden / 128) * kL2SFKBlocks;
                    // Descriptor start addresses are in 16-byte units in the low 14 bits;
                    // every offset below is a multiple of 16 bytes and the whole dynamic
                    // shared memory stays under 256 KiB, so plain additions never carry
                    // out of the field.
                    const auto desc_a_base = mma::sm90::make_smem_desc(smem_a[0] + smem_a_wg_offset, 1);
                    const auto desc_b_base = mma::sm90::make_smem_desc(smem_b[0] + smem_b_wg_offset, 1);
                    const uint32_t desc_a_lo = desc_a_base.reg32_[0], desc_b_lo = desc_b_base.reg32_[0];
                    const uint64_t desc_a_hi = static_cast<uint64_t>(desc_a_base.reg32_[1]) << 32;
                    const uint64_t desc_b_hi = static_cast<uint64_t>(desc_b_base.reg32_[1]) << 32;
                    auto issue = [&](const uint32_t& k_begin, const uint32_t& num_k) {
                        const uint32_t a_lo = desc_a_lo + stage_idx * (SMEM_A_SIZE_PER_STAGE / 16);
                        const uint32_t b_lo = desc_b_lo + stage_idx * (SMEM_B_SIZE_PER_STAGE / 16);
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                        ptx::warpgroup_arrive();
                        #pragma unroll
                        for (uint32_t k = 0; k < num_k; ++ k) {
                            const uint32_t k_desc = (k_begin + k) * WGMMA::K * static_cast<uint32_t>(sizeof(a_dtype_t)) / 16;
                            WGMMA::wgmma(desc_a_hi | (a_lo + k_desc), desc_b_hi | (b_lo + k_desc), final_accum, true);
                        }
                        ptx::warpgroup_commit_batch();
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                    };
                    auto rcp = [](const float& x) { return kFastMath ? math::fast_rcp(x) : 1.0f / x; };
                    auto next_stage_and_phase = [&](uint32_t& next_stage, uint32_t& next_phase) {
                        next_stage = stage_idx == kNumStages - 1 ? 0 : stage_idx + 1;
                        next_phase = phase ^ (next_stage == 0 ? 1u : 0u);
                    };
                    // kPrefillSplitAccum K loop: per K block, for half h = 0, 1: wait for half h of
                    // the previous K block, release its stage after both halves, rescale half h, issue
                    // half h; then the caller's per-K-block hook and the next K block's scales, as in
                    // the serving loop. The caller has waited for the first stage and read its scales;
                    // its ratios start at 1 (the zero accumulators stay zero, as without the flag).
                    [[maybe_unused]] auto split_k_loop = [&](auto num_k_blocks_c, auto unroll_c, const auto& rescale_half,
                                                             const auto& after_issue, const auto& prefetch) CUTLASS_LAMBDA_FUNC_INLINE {
                        constexpr uint32_t kNumKBlocks = decltype(num_k_blocks_c)::value, kUnroll = decltype(unroll_c)::value;
                        using HalfWGMMA = typename mma::sm90::FP8MMASelector<WG_BLOCK_N / 2>::type;
                        constexpr uint32_t kHalfAccum = kAccumPerThread / 2;
                        DG_STATIC_ASSERT(kNumKBlocks % kUnroll == 0 and HalfWGMMA::kNumAccum == kHalfAccum, "Split accumulator chunks");
                        auto issue_half = [&](const uint32_t& h) CUTLASS_LAMBDA_FUNC_INLINE {
                            const uint32_t a_lo = desc_a_lo + stage_idx * (SMEM_A_SIZE_PER_STAGE / 16);
                            const uint32_t b_lo = desc_b_lo + stage_idx * (SMEM_B_SIZE_PER_STAGE / 16) +
                                h * (WG_BLOCK_N / 2 * BLOCK_K * static_cast<uint32_t>(sizeof(b_dtype_t)) / 16);
                            #pragma unroll
                            for (uint32_t i = 0; i < kHalfAccum; ++ i) ptx::warpgroup_fence_operand(final_accum[h * kHalfAccum + i]);
                            ptx::warpgroup_arrive();
                            #pragma unroll
                            for (uint32_t k = 0; k < BLOCK_K / WGMMA::K; ++ k) {
                                const uint32_t k_desc = k * WGMMA::K * static_cast<uint32_t>(sizeof(a_dtype_t)) / 16;
                                HalfWGMMA::wgmma(desc_a_hi | (a_lo + k_desc), desc_b_hi | (b_lo + k_desc), final_accum + h * kHalfAccum, true);
                            }
                            ptx::warpgroup_commit_batch();
                            #pragma unroll
                            for (uint32_t i = 0; i < kHalfAccum; ++ i) ptx::warpgroup_fence_operand(final_accum[h * kHalfAccum + i]);
                        };
                        // The zero accumulators are pinned before the first WGMMA.
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                        uint32_t prev_stage = stage_idx, k_block_idx = 0;
                        for (uint32_t k_chunk = 0; k_chunk < kNumKBlocks; k_chunk += kUnroll) {
                            #pragma unroll
                            for (uint32_t u = 0; u < kUnroll; ++ u) {
                                #pragma unroll
                                for (uint32_t h = 0; h < 2; ++ h) {
                                    if (u > 0) {
                                        // Half h of the previous K block is the oldest pending group.
                                        ptx::warpgroup_wait<1>();
                                        if (h == 1 and lane_idx == 0)
                                            empty_barriers[prev_stage]->arrive();
                                    } else if (h == 1) {
                                        // Chunk start: only half 0 is pending, so this waits for nothing;
                                        // it tells ptxas that half 1 is not in flight.
                                        ptx::warpgroup_wait<1>();
                                    }
                                    rescale_half(h);
                                    issue_half(h);
                                }
                                after_issue(k_chunk + u);
                                if (u + 1 < kUnroll or k_chunk + kUnroll < kNumKBlocks) {
                                    uint32_t next_stage, next_phase;
                                    next_stage_and_phase(next_stage, next_phase);
                                    prefetch(k_chunk + u + 1, next_stage, next_phase);
                                }
                                prev_stage = stage_idx;
                                advance_pipeline(k_block_idx);
                            }
                            ptx::warpgroup_wait<0>();
                            if (lane_idx == 0)
                                empty_barriers[prev_stage]->arrive();
                        }
                    };

                    if (block_phase == sched::BlockPhase::Linear1) {
                        // The 256-column FC1 tile is 128 gate + 128 up channels (granularity-8
                        // interleave), one 128-channel weight-SF block each, whether one
                        // warpgroup owns all 256 columns (kPrefill2WG) or two own 128 each.
                        const uint32_t gate_row = local_expert_idx * kL1SFPerExpert + (kPrefill2WG ? n_block_idx : sf_n_block_idx / 2u) * kL1SFKBlocks;
                        const uint32_t up_row = gate_row + kL1SFGateBlks * kL1SFKBlocks;
                        float prev_scale_a_0 = 1.0f, prev_scale_a_1 = 1.0f, prev_gate_sf = 1.0f, prev_up_sf = 1.0f;
                        float r0_gate = 1.0f, r1_gate = 1.0f, r0_up = 1.0f, r1_up = 1.0f;
                        if constexpr (kPrefillSplitAccum) {
                        // num_k_blocks is kNumL1BlockKs for every unpaired FC1 item.
                        full_barriers[stage_idx]->wait(phase);
                        prev_scale_a_0 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r0);
                        prev_scale_a_1 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r1);
                        prev_gate_sf = __ldg(l1_weights_sf + gate_row);
                        prev_up_sf = __ldg(l1_weights_sf + up_row);
                        split_k_loop(std::integral_constant<uint32_t, kNumL1BlockKs>{}, std::integral_constant<uint32_t, kL1SplitUnroll>{},
                            [&](const uint32_t& h) CUTLASS_LAMBDA_FUNC_INLINE {
                                #pragma unroll
                                for (uint32_t i = h * kAccumPerThread / 8; i < (h + 1) * kAccumPerThread / 8; ++ i) {
                                    const float r0 = (i & 1u) ? r0_up : r0_gate;
                                    const float r1 = (i & 1u) ? r1_up : r1_gate;
                                    final_accum[i*4+0] *= r0;
                                    final_accum[i*4+1] *= r0;
                                    final_accum[i*4+2] *= r1;
                                    final_accum[i*4+3] *= r1;
                                }
                            },
                            [&](const uint32_t& k_block_idx) CUTLASS_LAMBDA_FUNC_INLINE {
                                if (k_block_idx == 2)
                                    publish_l1_rows();
                            },
                            [&](const uint32_t& next_k_block_idx, const uint32_t& next_stage, const uint32_t& next_phase) CUTLASS_LAMBDA_FUNC_INLINE {
                                const float gate_sf = __ldg(l1_weights_sf + gate_row + next_k_block_idx);
                                const float up_sf = __ldg(l1_weights_sf + up_row + next_k_block_idx);
                                full_barriers[next_stage]->wait(next_phase);
                                const float scale_a_0 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r0);
                                const float scale_a_1 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r1);
                                r0_gate = (prev_scale_a_0 * prev_gate_sf) * rcp(scale_a_0 * gate_sf);
                                r1_gate = (prev_scale_a_1 * prev_gate_sf) * rcp(scale_a_1 * gate_sf);
                                r0_up = (prev_scale_a_0 * prev_up_sf) * rcp(scale_a_0 * up_sf);
                                r1_up = (prev_scale_a_1 * prev_up_sf) * rcp(scale_a_1 * up_sf);
                                prev_scale_a_0 = scale_a_0;
                                prev_scale_a_1 = scale_a_1;
                                prev_gate_sf = gate_sf;
                                prev_up_sf = up_sf;
                            });
                        } else {
                        for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                            if (k_block_idx == 0) {
                                full_barriers[stage_idx]->wait(phase);
                            } else {
                                #pragma unroll
                                for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                                    const float r0 = (i & 1u) ? r0_up : r0_gate;
                                    const float r1 = (i & 1u) ? r1_up : r1_gate;
                                    final_accum[i*4+0] *= r0;
                                    final_accum[i*4+1] *= r0;
                                    final_accum[i*4+2] *= r1;
                                    final_accum[i*4+3] *= r1;
                                }
                            }
                            issue(0, BLOCK_K / WGMMA::K);
                            if constexpr (kPrefill2WG) {
                                if (k_block_idx == 2)
                                    publish_l1_rows();
                            }

                            if (k_block_idx == 0) {
                                prev_scale_a_0 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r0);
                                prev_scale_a_1 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r1);
                                prev_gate_sf = __ldg(l1_weights_sf + gate_row);
                                prev_up_sf = __ldg(l1_weights_sf + up_row);
                            }
                            if (k_block_idx + 1 < num_k_blocks) {
                                uint32_t next_stage, next_phase;
                                next_stage_and_phase(next_stage, next_phase);
                                const float gate_sf = __ldg(l1_weights_sf + gate_row + k_block_idx + 1);
                                const float up_sf = __ldg(l1_weights_sf + up_row + k_block_idx + 1);
                                full_barriers[next_stage]->wait(next_phase);
                                const float scale_a_0 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r0);
                                const float scale_a_1 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r1);
                                r0_gate = (prev_scale_a_0 * prev_gate_sf) * rcp(scale_a_0 * gate_sf);
                                r1_gate = (prev_scale_a_1 * prev_gate_sf) * rcp(scale_a_1 * gate_sf);
                                r0_up = (prev_scale_a_0 * prev_up_sf) * rcp(scale_a_0 * up_sf);
                                r1_up = (prev_scale_a_1 * prev_up_sf) * rcp(scale_a_1 * up_sf);
                                prev_scale_a_0 = scale_a_0;
                                prev_scale_a_1 = scale_a_1;
                                prev_gate_sf = gate_sf;
                                prev_up_sf = up_sf;
                            }
                            ptx::warpgroup_wait<0>();
                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();
                        }
                        }
                        if (num_k_blocks != 0)
                            postscale_l1_final(prev_scale_a_0, prev_scale_a_1, prev_gate_sf, prev_up_sf);
                    } else {
                        // Per-128 activation scales: one WGMMA group per K block and one
                        // carried-scale rescale, the same structure as FC1.
                        DG_STATIC_ASSERT(kL2ActsSF128, "The Qwen Prefill FC2 loop assumes per-128 activation scales");
                        if constexpr (kPrefill2WG) {
                        // The warpgroup's 256 output columns are two 128-row weight-SF
                        // blocks (accumulator chunks 0..15 and 16..31), each with its own
                        // carried scale; the arithmetic per output element is the
                        // four-warpgroup path's.
                        constexpr uint32_t kNumWSF = WG_BLOCK_N / 128;
                        constexpr uint32_t kChunksPerWSF = kAccumPerThread / 4 / kNumWSF;
                        DG_STATIC_ASSERT(kNumWSF == 2 and kChunksPerWSF == 16, "FC2 weight-SF blocks per warpgroup");
                        const uint32_t l2_row = local_expert_idx * kL2SFPerExpert + n_block_idx * kNumWSF * kL2SFKBlocks;
                        float prev_scale_a_0 = 1.0f, prev_scale_a_1 = 1.0f, prev_l2_sf[kNumWSF];
                        float r0_start[kNumWSF], r1_start[kNumWSF];
                        #pragma unroll
                        for (uint32_t j = 0; j < kNumWSF; ++ j)
                            prev_l2_sf[j] = 1.0f, r0_start[j] = 1.0f, r1_start[j] = 1.0f;
                        if constexpr (kPrefillSplitAccum) {
                        // num_k_blocks is kNumL2BlockKs for every unpaired FC2 item; half h is
                        // weight-SF block h (accumulator chunks 16h..16h+15).
                        full_barriers[stage_idx]->wait(phase);
                        prev_scale_a_0 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r0);
                        prev_scale_a_1 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r1);
                        #pragma unroll
                        for (uint32_t j = 0; j < kNumWSF; ++ j)
                            prev_l2_sf[j] = __ldg(l2_weights_sf + l2_row + j * kL2SFKBlocks);
                        split_k_loop(std::integral_constant<uint32_t, kNumL2BlockKs>{}, std::integral_constant<uint32_t, kL2SplitUnroll>{},
                            [&](const uint32_t& h) CUTLASS_LAMBDA_FUNC_INLINE {
                                #pragma unroll
                                for (uint32_t i = h * kChunksPerWSF; i < (h + 1) * kChunksPerWSF; ++ i) {
                                    final_accum[i*4+0] *= r0_start[h];
                                    final_accum[i*4+1] *= r0_start[h];
                                    final_accum[i*4+2] *= r1_start[h];
                                    final_accum[i*4+3] *= r1_start[h];
                                }
                            },
                            [&](const uint32_t&) CUTLASS_LAMBDA_FUNC_INLINE {},
                            [&](const uint32_t& next_k_block_idx, const uint32_t& next_stage, const uint32_t& next_phase) CUTLASS_LAMBDA_FUNC_INLINE {
                                float l2_sf[kNumWSF];
                                #pragma unroll
                                for (uint32_t j = 0; j < kNumWSF; ++ j)
                                    l2_sf[j] = __ldg(l2_weights_sf + l2_row + j * kL2SFKBlocks + next_k_block_idx);
                                full_barriers[next_stage]->wait(next_phase);
                                const float scale_a_0 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r0);
                                const float scale_a_1 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r1);
                                #pragma unroll
                                for (uint32_t j = 0; j < kNumWSF; ++ j) {
                                    r0_start[j] = (prev_scale_a_0 * prev_l2_sf[j]) * rcp(scale_a_0 * l2_sf[j]);
                                    r1_start[j] = (prev_scale_a_1 * prev_l2_sf[j]) * rcp(scale_a_1 * l2_sf[j]);
                                    prev_l2_sf[j] = l2_sf[j];
                                }
                                prev_scale_a_0 = scale_a_0;
                                prev_scale_a_1 = scale_a_1;
                            });
                        } else {
                        for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                            if (k_block_idx == 0) {
                                full_barriers[stage_idx]->wait(phase);
                            } else {
                                #pragma unroll
                                for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                                    final_accum[i*4+0] *= r0_start[i / kChunksPerWSF];
                                    final_accum[i*4+1] *= r0_start[i / kChunksPerWSF];
                                    final_accum[i*4+2] *= r1_start[i / kChunksPerWSF];
                                    final_accum[i*4+3] *= r1_start[i / kChunksPerWSF];
                                }
                            }
                            issue(0, BLOCK_K / WGMMA::K);

                            if (k_block_idx == 0) {
                                prev_scale_a_0 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r0);
                                prev_scale_a_1 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r1);
                                #pragma unroll
                                for (uint32_t j = 0; j < kNumWSF; ++ j)
                                    prev_l2_sf[j] = __ldg(l2_weights_sf + l2_row + j * kL2SFKBlocks);
                            }
                            if (k_block_idx + 1 < num_k_blocks) {
                                uint32_t next_stage, next_phase;
                                next_stage_and_phase(next_stage, next_phase);
                                float l2_sf[kNumWSF];
                                #pragma unroll
                                for (uint32_t j = 0; j < kNumWSF; ++ j)
                                    l2_sf[j] = __ldg(l2_weights_sf + l2_row + j * kL2SFKBlocks + k_block_idx + 1);
                                full_barriers[next_stage]->wait(next_phase);
                                const float scale_a_0 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r0);
                                const float scale_a_1 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r1);
                                #pragma unroll
                                for (uint32_t j = 0; j < kNumWSF; ++ j) {
                                    r0_start[j] = (prev_scale_a_0 * prev_l2_sf[j]) * rcp(scale_a_0 * l2_sf[j]);
                                    r1_start[j] = (prev_scale_a_1 * prev_l2_sf[j]) * rcp(scale_a_1 * l2_sf[j]);
                                    prev_l2_sf[j] = l2_sf[j];
                                }
                                prev_scale_a_0 = scale_a_0;
                                prev_scale_a_1 = scale_a_1;
                            }
                            ptx::warpgroup_wait<0>();
                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();
                        }
                        }
                        if (num_k_blocks != 0) {
                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                                const float s0 = prev_scale_a_0 * prev_l2_sf[i / kChunksPerWSF];
                                const float s1 = prev_scale_a_1 * prev_l2_sf[i / kChunksPerWSF];
                                final_accum[i*4+0] *= s0;
                                final_accum[i*4+1] *= s0;
                                final_accum[i*4+2] *= s1;
                                final_accum[i*4+3] *= s1;
                            }
                        }
                        } else {
                        const uint32_t l2_row = local_expert_idx * kL2SFPerExpert + sf_n_block_idx * kL2SFKBlocks;
                        float prev_scale_a_0 = 1.0f, prev_scale_a_1 = 1.0f, prev_l2_sf = 1.0f;
                        float r0_start = 1.0f, r1_start = 1.0f;
                        for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                            if (k_block_idx == 0) {
                                full_barriers[stage_idx]->wait(phase);
                            } else {
                                #pragma unroll
                                for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                                    final_accum[i*4+0] *= r0_start;
                                    final_accum[i*4+1] *= r0_start;
                                    final_accum[i*4+2] *= r1_start;
                                    final_accum[i*4+3] *= r1_start;
                                }
                            }
                            issue(0, BLOCK_K / WGMMA::K);

                            if (k_block_idx == 0) {
                                prev_scale_a_0 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r0);
                                prev_scale_a_1 = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r1);
                                prev_l2_sf = __ldg(l2_weights_sf + l2_row);
                            }
                            if (k_block_idx + 1 < num_k_blocks) {
                                uint32_t next_stage, next_phase;
                                next_stage_and_phase(next_stage, next_phase);
                                const float l2_sf = __ldg(l2_weights_sf + l2_row + k_block_idx + 1);
                                full_barriers[next_stage]->wait(next_phase);
                                const float scale_a_0 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r0);
                                const float scale_a_1 = ptx::ld_shared(smem_sfa[next_stage] + row_offset_r1);
                                r0_start = (prev_scale_a_0 * prev_l2_sf) * rcp(scale_a_0 * l2_sf);
                                r1_start = (prev_scale_a_1 * prev_l2_sf) * rcp(scale_a_1 * l2_sf);
                                prev_scale_a_0 = scale_a_0;
                                prev_scale_a_1 = scale_a_1;
                                prev_l2_sf = l2_sf;
                            }
                            ptx::warpgroup_wait<0>();
                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();
                        }
                        if (num_k_blocks != 0)
                            postscale_l2_final(prev_scale_a_0, prev_scale_a_1, prev_l2_sf);
                        }
                    }
                    }
                } else
                // The Qwen Prefill M128/N256 path reuses the accumulator.
                // Carry its current scale across K tiles and reconstruct once,
                // reusing the large-hidden path with different FP32 rounding.
                if constexpr (kHidden >= 7168 ||
                              (kHidden == 4096 && kIntermediateHidden == 1536 && BLOCK_M == 128 && BLOCK_N == 256)) {
                    float prev_scale_a_0 = 1.0f, prev_scale_a_1 = 1.0f;
                    float prev_gate_sf = 1.0f, prev_up_sf = 1.0f, prev_l2_sf = 1.0f;
                    for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                        full_barriers[stage_idx]->wait(phase);

                        float scale_a_0_lo, scale_a_1_lo;
                        float scale_a_0_hi, scale_a_1_hi;
                        if (block_phase == sched::BlockPhase::Linear1) {
                            scale_a_0_lo = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r0);
                            scale_a_1_lo = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r1);
                        } else {
                            scale_a_0_lo = ptx::ld_shared(smem_sfa[stage_idx] + 0 * BLOCK_M + row_offset_r0);
                            scale_a_1_lo = ptx::ld_shared(smem_sfa[stage_idx] + 0 * BLOCK_M + row_offset_r1);
                            scale_a_0_hi = ptx::ld_shared(smem_sfa[stage_idx] + 1 * BLOCK_M + row_offset_r0);
                            scale_a_1_hi = ptx::ld_shared(smem_sfa[stage_idx] + 1 * BLOCK_M + row_offset_r1);
                        }

                        constexpr uint32_t kL1SFKBlocks   = kHidden / 128;
                        constexpr uint32_t kL2SFKBlocks   = kIntermediateHidden / 128;
                        constexpr uint32_t kL1SFGateBlks  = kIntermediateHidden / 128;
                        constexpr uint32_t kL1SFPerExpert = (kIntermediateHidden * 2 / 128) * kL1SFKBlocks;
                        constexpr uint32_t kL2SFPerExpert = (kHidden / 128) * kL2SFKBlocks;
                        float gate_sf = 0.0f, up_sf = 0.0f, l2_sf = 0.0f;
                        if (block_phase == sched::BlockPhase::Linear1) {
                            const uint32_t gate_n = sf_n_block_idx / 2u;
                            const uint32_t up_n   = kL1SFGateBlks + gate_n;
                            const float* base = l1_weights_sf + local_expert_idx * kL1SFPerExpert + k_block_idx;
                            gate_sf = __ldg(base + gate_n * kL1SFKBlocks);
                            up_sf   = __ldg(base + up_n   * kL1SFKBlocks);
                        } else {
                            l2_sf = __ldg(l2_weights_sf + local_expert_idx * kL2SFPerExpert
                                                        + sf_n_block_idx * kL2SFKBlocks + k_block_idx);
                        }

                        if (block_phase == sched::BlockPhase::Linear1) {
                            if (k_block_idx != 0)
                                rescale_l1_final(prev_scale_a_0, prev_scale_a_1,
                                                 prev_gate_sf, prev_up_sf,
                                                 scale_a_0_lo, scale_a_1_lo,
                                                 gate_sf, up_sf);

                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_arrive();
                            #pragma unroll
                            for (uint32_t k = 0; k < BLOCK_K / WGMMA::K; ++ k) {
                                auto desc_a = mma::sm90::make_smem_desc(
                                    smem_a[stage_idx] + smem_a_wg_offset + k * WGMMA::K, 1);
                                auto desc_b = mma::sm90::make_smem_desc(
                                    smem_b[stage_idx] + smem_b_wg_offset + k * WGMMA::K, 1);
                                WGMMA::wgmma(desc_a, desc_b, final_accum, true);
                            }
                            ptx::warpgroup_commit_batch();
                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_wait<0>();

                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();

                            prev_scale_a_0 = scale_a_0_lo;
                            prev_scale_a_1 = scale_a_1_lo;
                            prev_gate_sf = gate_sf;
                            prev_up_sf = up_sf;
                        } else {
                            if (k_block_idx != 0)
                                rescale_l2_final(prev_scale_a_0, prev_scale_a_1, prev_l2_sf,
                                                 scale_a_0_lo, scale_a_1_lo, l2_sf);

                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_arrive();
                            #pragma unroll
                            for (uint32_t k = 0; k < (BLOCK_K / 2) / WGMMA::K; ++ k) {
                                auto desc_a = mma::sm90::make_smem_desc(
                                    smem_a[stage_idx] + smem_a_wg_offset + k * WGMMA::K, 1);
                                auto desc_b = mma::sm90::make_smem_desc(
                                    smem_b[stage_idx] + smem_b_wg_offset + k * WGMMA::K, 1);
                                WGMMA::wgmma(desc_a, desc_b, final_accum, true);
                            }
                            ptx::warpgroup_commit_batch();
                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_wait<0>();

                            rescale_l2_act_final(scale_a_0_lo, scale_a_1_lo,
                                                 scale_a_0_hi, scale_a_1_hi);

                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_arrive();
                            #pragma unroll
                            for (uint32_t k = 0; k < (BLOCK_K / 2) / WGMMA::K; ++ k) {
                                const uint32_t k_off = (BLOCK_K / 2) + k * WGMMA::K;
                                auto desc_a = mma::sm90::make_smem_desc(
                                    smem_a[stage_idx] + smem_a_wg_offset + k_off, 1);
                                auto desc_b = mma::sm90::make_smem_desc(
                                    smem_b[stage_idx] + smem_b_wg_offset + k_off, 1);
                                WGMMA::wgmma(desc_a, desc_b, final_accum, true);
                            }
                            ptx::warpgroup_commit_batch();
                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_wait<0>();

                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();

                            prev_scale_a_0 = scale_a_0_hi;
                            prev_scale_a_1 = scale_a_1_hi;
                            prev_l2_sf = l2_sf;
                        }
                    }

                    if (num_k_blocks != 0) {
                        if (block_phase == sched::BlockPhase::Linear1) {
                            postscale_l1_final(prev_scale_a_0, prev_scale_a_1,
                                               prev_gate_sf, prev_up_sf);
                        } else {
                            postscale_l2_final(prev_scale_a_0, prev_scale_a_1, prev_l2_sf);
                        }
                    }
                } else {
                    for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                        full_barriers[stage_idx]->wait(phase);

                        float scale_a_0_lo, scale_a_1_lo;
                        float scale_a_0_hi, scale_a_1_hi;
                        if (block_phase == sched::BlockPhase::Linear1) {
                            scale_a_0_lo = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r0);
                            scale_a_1_lo = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r1);
                        } else {
                            scale_a_0_lo = ptx::ld_shared(smem_sfa[stage_idx] + 0 * BLOCK_M + row_offset_r0);
                            scale_a_1_lo = ptx::ld_shared(smem_sfa[stage_idx] + 0 * BLOCK_M + row_offset_r1);
                            scale_a_0_hi = ptx::ld_shared(smem_sfa[stage_idx] + 1 * BLOCK_M + row_offset_r0);
                            scale_a_1_hi = ptx::ld_shared(smem_sfa[stage_idx] + 1 * BLOCK_M + row_offset_r1);
                        }

                        constexpr uint32_t kL1SFKBlocks   = kHidden / 128;
                        constexpr uint32_t kL2SFKBlocks   = kIntermediateHidden / 128;
                        constexpr uint32_t kL1SFGateBlks  = kIntermediateHidden / 128;
                        constexpr uint32_t kL1SFPerExpert = (kIntermediateHidden * 2 / 128) * kL1SFKBlocks;
                        constexpr uint32_t kL2SFPerExpert = (kHidden / 128) * kL2SFKBlocks;
                        float gate_sf = 0.0f, up_sf = 0.0f, l2_sf = 0.0f;
                        if (block_phase == sched::BlockPhase::Linear1) {
                            const uint32_t gate_n = sf_n_block_idx / 2u;
                            const uint32_t up_n   = kL1SFGateBlks + gate_n;
                            const float* base = l1_weights_sf + local_expert_idx * kL1SFPerExpert + k_block_idx;
                            gate_sf = __ldg(base + gate_n * kL1SFKBlocks);
                            up_sf   = __ldg(base + up_n   * kL1SFKBlocks);
                        } else {
                            l2_sf = __ldg(l2_weights_sf + local_expert_idx * kL2SFPerExpert
                                                        + sf_n_block_idx * kL2SFKBlocks + k_block_idx);
                        }

                        if (block_phase == sched::BlockPhase::Linear1) {
                            if (k_block_idx != 0)
                                prescale_l1_final(scale_a_0_lo, scale_a_1_lo, gate_sf, up_sf);

                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_arrive();
                            #pragma unroll
                            for (uint32_t k = 0; k < BLOCK_K / WGMMA::K; ++ k) {
                                auto desc_a = mma::sm90::make_smem_desc(
                                    smem_a[stage_idx] + smem_a_wg_offset + k * WGMMA::K, 1);
                                auto desc_b = mma::sm90::make_smem_desc(
                                    smem_b[stage_idx] + smem_b_wg_offset + k * WGMMA::K, 1);
                                WGMMA::wgmma(desc_a, desc_b, final_accum, true);
                            }
                            ptx::warpgroup_commit_batch();
                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_wait<0>();

                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();

                            postscale_l1_final(scale_a_0_lo, scale_a_1_lo, gate_sf, up_sf);
                        } else {
                            if (k_block_idx != 0)
                                prescale_l2_final(scale_a_0_lo, scale_a_1_lo, l2_sf);

                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_arrive();
                            #pragma unroll
                            for (uint32_t k = 0; k < (BLOCK_K / 2) / WGMMA::K; ++ k) {
                                auto desc_a = mma::sm90::make_smem_desc(
                                    smem_a[stage_idx] + smem_a_wg_offset + k * WGMMA::K, 1);
                                auto desc_b = mma::sm90::make_smem_desc(
                                    smem_b[stage_idx] + smem_b_wg_offset + k * WGMMA::K, 1);
                                WGMMA::wgmma(desc_a, desc_b, final_accum, true);
                            }
                            ptx::warpgroup_commit_batch();
                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_wait<0>();

                            postscale_l2_final(scale_a_0_lo, scale_a_1_lo, l2_sf);
                            prescale_l2_final(scale_a_0_hi, scale_a_1_hi, l2_sf);

                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_arrive();
                            #pragma unroll
                            for (uint32_t k = 0; k < (BLOCK_K / 2) / WGMMA::K; ++ k) {
                                const uint32_t k_off = (BLOCK_K / 2) + k * WGMMA::K;
                                auto desc_a = mma::sm90::make_smem_desc(
                                    smem_a[stage_idx] + smem_a_wg_offset + k_off, 1);
                                auto desc_b = mma::sm90::make_smem_desc(
                                    smem_b[stage_idx] + smem_b_wg_offset + k_off, 1);
                                WGMMA::wgmma(desc_a, desc_b, final_accum, true);
                            }
                            ptx::warpgroup_commit_batch();
                            #pragma unroll
                            for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(final_accum[i]);
                            ptx::warpgroup_wait<0>();

                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();

                            postscale_l2_final(scale_a_0_hi, scale_a_1_hi, l2_sf);
                        }
                    }
                }
            } else if constexpr (kSwapABActive) {
                // SwapAB Decode mainloop (weights as WGMMA-M, tokens as WGMMA-N). N_SWAP is
                // fixed for the block, so it is selected once and the whole K loop runs
                // inside that specialization instead of re-dispatching on every K block.
                // The math, scales, waits and FP32 promotion order are unchanged, so the
                // output is bit-identical.
                DG_STATIC_ASSERT(kL2ActsSFGranK == 64, "L2 swapAB assumes per-64 activation scales");
                // Weight SF rows of this block's (expert, N tile): one float per K block.
                // L1 (E, 2*IH/128, H/128): gate row sf_n_block_idx/2, up row IH/128 later
                // (gran-8 gate/up interleave). L2 (E, H/128, IH/128): row sf_n_block_idx.
                constexpr uint32_t kL1SFKBlocks   = kHidden / 128;
                constexpr uint32_t kL2SFKBlocks   = kIntermediateHidden / 128;
                constexpr uint32_t kL1SFGateBlks  = kIntermediateHidden / 128;
                constexpr uint32_t kL1SFPerExpert = (kIntermediateHidden * 2 / 128) * kL1SFKBlocks;
                constexpr uint32_t kL2SFPerExpert = (kHidden / 128) * kL2SFKBlocks;
                const float* l1_gate_sf = l1_weights_sf + local_expert_idx * kL1SFPerExpert + (sf_n_block_idx / 2u) * kL1SFKBlocks;
                const float* l1_up_sf = l1_gate_sf + kL1SFGateBlks * kL1SFKBlocks;
                const float* l2_sf_row = l2_weights_sf + local_expert_idx * kL2SFPerExpert + sf_n_block_idx * kL2SFKBlocks;

                auto run_swap_ab = [&]<uint32_t N_SWAP>() CUTLASS_LAMBDA_FUNC_INLINE {
                    using SwapWGMMA = typename mma::sm90::FP8MMASelector<N_SWAP>::type;
                    constexpr uint32_t kSwapAccum = SwapWGMMA::kNumAccum;
                    float swap_accum[kSwapAccum], swap_accum_hi[kSwapAccum];

                    auto fence = [](float* acc) {
                        #pragma unroll
                        for (uint32_t i = 0; i < kSwapAccum; ++ i)
                            ptx::warpgroup_fence_operand(acc[i]);
                    };
                    // One WGMMA group over K [k_offset, k_offset + kNumK * 32) of the stage.
                    auto issue = [&]<uint32_t kNumK>(float* acc, const uint32_t& k_offset, const uint32_t& fragment) {
                        fence(acc);
                        ptx::warpgroup_arrive();
                        #pragma unroll
                        for (uint32_t k = 0; k < kNumK; ++ k) {
                            auto desc_a = mma::sm90::make_smem_desc(
                                smem_b[stage_idx] + smem_b_wg_offset + fragment * 64 * BLOCK_K + k_offset + k * SwapWGMMA::K, 1);
                            auto desc_b = mma::sm90::make_smem_desc(
                                smem_a[stage_idx] + k_offset + k * SwapWGMMA::K, 1);
                            SwapWGMMA::wgmma(desc_a, desc_b, acc, k);
                        }
                        ptx::warpgroup_commit_batch();
                        fence(acc);
                    };
                    // Accumulator rows r0 (.x/.y) and r0 + 8 (.z/.w) take weight scales
                    // sf_0 and sf_1 (L1: gate and up); columns are tokens with per-token
                    // activation scales from `sfa`.
                    auto promote = [&](float* acc, const float* sfa, const float& sf_0, const float& sf_1, const uint32_t& fragment) {
                        fence(acc);
                        #pragma unroll
                        for (uint32_t i = 0; i < kSwapAccum / 4; ++ i) {
                            const uint32_t token_0 = i * 8 + col_idx * 2;
                            const uint32_t token_1 = token_0 + 1;
                            const float scale_0 = (token_0 < valid_m) ? ptx::ld_shared(sfa + token_0) : 0.0f;
                            const float scale_1 = (token_1 < valid_m) ? ptx::ld_shared(sfa + token_1) : 0.0f;
                            final_accum[fragment * 32 + i * 4 + 0] += scale_0 * sf_0 * acc[i * 4 + 0];
                            final_accum[fragment * 32 + i * 4 + 2] += scale_0 * sf_1 * acc[i * 4 + 2];
                            final_accum[fragment * 32 + i * 4 + 1] += scale_1 * sf_0 * acc[i * 4 + 1];
                            final_accum[fragment * 32 + i * 4 + 3] += scale_1 * sf_1 * acc[i * 4 + 3];
                        }
                    };

                    if (block_phase == sched::BlockPhase::Linear1) {
                        for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                            const float gate_sf = __ldg(l1_gate_sf + k_block_idx);
                            const float up_sf = __ldg(l1_up_sf + k_block_idx);
                            full_barriers[stage_idx]->wait(phase);
                            #pragma unroll
                            for (uint32_t fragment = 0; fragment < (kIndependentWG ? 2 : 1); ++ fragment) {
                                issue.template operator()<BLOCK_K / SwapWGMMA::K>(swap_accum, 0, fragment);
                                ptx::warpgroup_wait<0>();
                                promote(swap_accum, smem_sfa[stage_idx], gate_sf, up_sf, fragment);
                            }
                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();
                        }
                    } else {
                        // Per-64 K halves in separate groups: the high half runs while the
                        // low half is promoted. SFA layout is (K=2, M=BLOCK_M).
                        for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                            const float l2_sf = __ldg(l2_sf_row + k_block_idx);
                            full_barriers[stage_idx]->wait(phase);
                            #pragma unroll
                            for (uint32_t fragment = 0; fragment < (kIndependentWG ? 2 : 1); ++ fragment) {
                                issue.template operator()<(BLOCK_K / 2) / SwapWGMMA::K>(swap_accum, 0, fragment);
                                issue.template operator()<(BLOCK_K / 2) / SwapWGMMA::K>(swap_accum_hi, BLOCK_K / 2, fragment);
                                ptx::warpgroup_wait<1>();
                                promote(swap_accum, smem_sfa[stage_idx], l2_sf, l2_sf, fragment);
                                ptx::warpgroup_wait<0>();
                                promote(swap_accum_hi, smem_sfa[stage_idx] + BLOCK_M, l2_sf, l2_sf, fragment);
                            }
                            if (lane_idx == 0)
                                empty_barriers[stage_idx]->arrive();
                        }
                    }
                };

                const uint32_t n_swap = ((valid_m + 7u) / 8u) * 8u;
                // Qwen EP4 Decode benefits from the existing 8-token
                // specializations instead of rounding 33..56 rows to 64.
                if constexpr (kIntermediateHidden <= 2048 &&
                              !(kHidden == 4096 && kIntermediateHidden == 1536 && kNumRanks == 4)) {
                    if (n_swap <= 8) {
                        run_swap_ab.template operator()<8>();
                    } else if (n_swap <= 16) {
                        run_swap_ab.template operator()<16>();
                    } else if (n_swap <= 32) {
                        run_swap_ab.template operator()<32>();
                    } else {
                        run_swap_ab.template operator()<64>();
                    }
                } else {
                    switch (n_swap) {
                        case 8:  run_swap_ab.template operator()<8>();  break;
                        case 16: run_swap_ab.template operator()<16>(); break;
                        case 24: run_swap_ab.template operator()<24>(); break;
                        case 32: run_swap_ab.template operator()<32>(); break;
                        case 40: run_swap_ab.template operator()<40>(); break;
                        case 48: run_swap_ab.template operator()<48>(); break;
                        case 56: run_swap_ab.template operator()<56>(); break;
                        default: run_swap_ab.template operator()<64>(); break;
                    }
                }
            } else {
                float accum[kAccumPerThread];

                for (uint32_t k_block_idx = 0; k_block_idx < num_k_blocks; advance_pipeline(k_block_idx)) {
                    full_barriers[stage_idx]->wait(phase);

                    // Read SF (must precede warpgroup_arrive)
                    float scale_a_0_lo, scale_a_1_lo;
                    float scale_a_0_hi, scale_a_1_hi;  // Only used in L2 (per-64 K)
                    if (block_phase == sched::BlockPhase::Linear1) {
                        scale_a_0_lo = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r0);
                        scale_a_1_lo = ptx::ld_shared(smem_sfa[stage_idx] + row_offset_r1);
                    } else {
                        // L2: SFA layout is (K=2, M=BLOCK_M) MN-major; first half SF at offset 0, second at BLOCK_M
                        scale_a_0_lo = ptx::ld_shared(smem_sfa[stage_idx] + 0 * BLOCK_M + row_offset_r0);
                        scale_a_1_lo = ptx::ld_shared(smem_sfa[stage_idx] + 0 * BLOCK_M + row_offset_r1);
                        scale_a_0_hi = ptx::ld_shared(smem_sfa[stage_idx] + 1 * BLOCK_M + row_offset_r0);
                        scale_a_1_hi = ptx::ld_shared(smem_sfa[stage_idx] + 1 * BLOCK_M + row_offset_r1);
                    }

                    // ----- Block (128, 128) weight SF (loaded directly from global) -----
                    // L1 weight SF shape: (E, 2*IH/128, H/128) MN-major. The N axis is
                    // [gate(IH/128), up(IH/128)]; with the gate/up gran-8 interleave on
                    // the FP8 weight, each logical 128-wide N tile covers 64 rows of gate
                    // plus 64 rows of up taken from the same original 128-row block, so:
                    //     gate_sf_n = sf_n_block_idx / 2
                    //     up_sf_n   = (IH/128) + sf_n_block_idx / 2
                    //
                    // L2 weight SF shape: (E, H/128, IH/128) MN-major. One scalar per
                    // logical 128x128 weight-SF tile, broadcast across the matching
                    // WGMMA accumulators.
                    //
                    // Load the weight scale after the barrier from all WG threads.
                    // This keeps scale loads close to their WGMMA use and lets the
                    // read-only cache coalesce the same-address accesses.
                    constexpr uint32_t kL1SFKBlocks   = kHidden / 128;
                    constexpr uint32_t kL2SFKBlocks   = kIntermediateHidden / 128;
                    constexpr uint32_t kL1SFGateBlks  = kIntermediateHidden / 128;
                    constexpr uint32_t kL1SFPerExpert = (kIntermediateHidden * 2 / 128) * kL1SFKBlocks;
                    constexpr uint32_t kL2SFPerExpert = (kHidden / 128) * kL2SFKBlocks;
                    float gate_sf = 0.0f, up_sf = 0.0f, l2_sf = 0.0f;
                    if (block_phase == sched::BlockPhase::Linear1) {
                        const uint32_t gate_n = sf_n_block_idx / 2u;
                        const uint32_t up_n   = kL1SFGateBlks + gate_n;
                        const float* base = l1_weights_sf + local_expert_idx * kL1SFPerExpert + k_block_idx;
                        gate_sf = __ldg(base + gate_n * kL1SFKBlocks);
                        up_sf   = __ldg(base + up_n   * kL1SFKBlocks);
                    } else {
                        l2_sf = __ldg(l2_weights_sf + local_expert_idx * kL2SFPerExpert
                                                    + sf_n_block_idx * kL2SFKBlocks + k_block_idx);
                    }

                    if (block_phase == sched::BlockPhase::Linear1) {
                        // Single per-128 K-block WGMMA group
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(accum[i]);
                        ptx::warpgroup_arrive();
                        #pragma unroll
                        for (uint32_t k = 0; k < BLOCK_K / WGMMA::K; ++ k) {
                            auto desc_a = mma::sm90::make_smem_desc(
                                smem_a[stage_idx] + smem_a_wg_offset + k * WGMMA::K, 1);
                            auto desc_b = mma::sm90::make_smem_desc(
                                smem_b[stage_idx] + smem_b_wg_offset + k * WGMMA::K, 1);
                            WGMMA::wgmma(desc_a, desc_b, accum, k);
                        }
                        ptx::warpgroup_commit_batch();
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(accum[i]);
                        ptx::warpgroup_wait<0>();

                        if (lane_idx == 0)
                            empty_barriers[stage_idx]->arrive();

                        // L1: gate/up alternate at gran=8 along N; each `i` block of 8
                        // cols belongs entirely to one of {gate, up}, so .x and .y
                        // share the same scalar.
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                            const float sb = (i & 1u) ? up_sf : gate_sf;
                            final_accum[i*4+0] += scale_a_0_lo * sb * accum[i*4+0];
                            final_accum[i*4+1] += scale_a_0_lo * sb * accum[i*4+1];
                            final_accum[i*4+2] += scale_a_1_lo * sb * accum[i*4+2];
                            final_accum[i*4+3] += scale_a_1_lo * sb * accum[i*4+3];
                        }
                    } else {
                        // L2: split BLOCK_K=128 into two halves (per-64 SFA), each 2 WGMMAs.
                        float accum_hi[kAccumPerThread];
                        // First half: K=0..63, SFA = scale_a_*_lo
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(accum[i]);
                        ptx::warpgroup_arrive();
                        #pragma unroll
                        for (uint32_t k = 0; k < (BLOCK_K / 2) / WGMMA::K; ++ k) {
                            auto desc_a = mma::sm90::make_smem_desc(
                                smem_a[stage_idx] + smem_a_wg_offset + k * WGMMA::K, 1);
                            auto desc_b = mma::sm90::make_smem_desc(
                                smem_b[stage_idx] + smem_b_wg_offset + k * WGMMA::K, 1);
                            WGMMA::wgmma(desc_a, desc_b, accum, k);
                        }
                        ptx::warpgroup_commit_batch();
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(accum[i]);
                        // Second half: K=64..127, SFA = scale_a_*_hi
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(accum_hi[i]);
                        ptx::warpgroup_arrive();
                        #pragma unroll
                        for (uint32_t k = 0; k < (BLOCK_K / 2) / WGMMA::K; ++ k) {
                            const uint32_t k_off = (BLOCK_K / 2) + k * WGMMA::K;
                            auto desc_a = mma::sm90::make_smem_desc(
                                smem_a[stage_idx] + smem_a_wg_offset + k_off, 1);
                            auto desc_b = mma::sm90::make_smem_desc(
                                smem_b[stage_idx] + smem_b_wg_offset + k_off, 1);
                            WGMMA::wgmma(desc_a, desc_b, accum_hi, k);
                        }
                        ptx::warpgroup_commit_batch();
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread; ++ i) ptx::warpgroup_fence_operand(accum_hi[i]);
                        ptx::warpgroup_wait<1>();

                        // L2 first half: single scalar `l2_sf` broadcast across N.
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                            final_accum[i*4+0] += scale_a_0_lo * l2_sf * accum[i*4+0];
                            final_accum[i*4+1] += scale_a_0_lo * l2_sf * accum[i*4+1];
                            final_accum[i*4+2] += scale_a_1_lo * l2_sf * accum[i*4+2];
                            final_accum[i*4+3] += scale_a_1_lo * l2_sf * accum[i*4+3];
                        }

                        ptx::warpgroup_wait<0>();

                        if (lane_idx == 0)
                            empty_barriers[stage_idx]->arrive();

                        // L2 second half: same broadcast scalar `l2_sf`.
                        #pragma unroll
                        for (uint32_t i = 0; i < kAccumPerThread / 4; ++ i) {
                            final_accum[i*4+0] += scale_a_0_hi * l2_sf * accum_hi[i*4+0];
                            final_accum[i*4+1] += scale_a_0_hi * l2_sf * accum_hi[i*4+1];
                            final_accum[i*4+2] += scale_a_1_hi * l2_sf * accum_hi[i*4+2];
                            final_accum[i*4+3] += scale_a_1_hi * l2_sf * accum_hi[i*4+3];
                        }
                    }
                }
            }

            // Skip epilogue when block is past valid M (still must release via empty)
            if (row_base >= valid_m) {
                if (block_phase == sched::BlockPhase::Linear1) {
                    if constexpr (not kL2ArrivalCounter)
                        ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                } else {
                    if constexpr (kL2EpilogueRequiresFullSync)
                        ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                }
                return;
            }

            if (block_phase == sched::BlockPhase::Linear1) {
                if constexpr (kSwapABActive) {
                    auto silu = [](float x) -> float {
                        const float e = kFastMath ? __expf(-x) : expf(-x);
                        const float sig = kFastMath ? math::fast_rcp(1.0f + e) : 1.0f / (1.0f + e);
                        return x * sig;
                    };
                    auto clamp_gate = [](float& x) {
                        if constexpr (kActivationClamp != cute::numeric_limits<float>::infinity())
                            x = cute::min(x, kActivationClamp);
                    };
                    auto clamp_up = [](float& x) {
                        if constexpr (kActivationClamp != cute::numeric_limits<float>::infinity())
                            x = cute::min(cute::max(x, -kActivationClamp), kActivationClamp);
                    };

                    // The FP32 SwiGLU tile is staged as [token][64] with the column XOR-swizzled
                    // by 8 * ((token / 2) % 4). A warp's stores then cover all 32 banks (the
                    // unswizzled row stride of 64 floats put the four token pairs of a store on
                    // the same 8 banks), and the quad readers below can load float4 rows without
                    // conflicts. The swizzle keeps 4-column groups contiguous and aligned.
                    DG_STATIC_ASSERT(L1_OUT_BLOCK_N == 64, "swapAB L1 staging assumes one 64-wide SF group");
                    auto swap_l1_swizzle = [](const uint32_t& token) { return ((token >> 1) & 3u) << 3; };
                    const uint32_t out_col_base =
                        wg_l1_out_n_offset + warp_idx_in_wg * 8 + row_idx;
                    auto store_l1_swap_chunk = [&](const uint32_t& i, const uint32_t& fragment) {
                        const uint32_t token_0 = i * 8 + col_idx * 2;
                        const uint32_t token_1 = token_0 + 1;
                        const uint32_t smem_col = (out_col_base + fragment * 32) ^ swap_l1_swizzle(token_0);
                        if (token_0 < valid_m) {
                            float g0 = final_accum[fragment * 32 + i * 4 + 0];
                            float u0 = final_accum[fragment * 32 + i * 4 + 2];
                            clamp_gate(g0);
                            clamp_up(u0);
                            smem_cd_swap_l1_fp32[token_0 * L1_OUT_BLOCK_N + smem_col] =
                                silu(g0) * u0;
                        }
                        if (token_1 < valid_m) {
                            float g1 = final_accum[fragment * 32 + i * 4 + 1];
                            float u1 = final_accum[fragment * 32 + i * 4 + 3];
                            clamp_gate(g1);
                            clamp_up(u1);
                            smem_cd_swap_l1_fp32[token_1 * L1_OUT_BLOCK_N + smem_col] =
                                silu(g1) * u1;
                        }
                    };

                    const uint32_t num_swap_token_chunks = (valid_m + 7u) / 8u;
                    #pragma unroll
                    for (uint32_t fragment = 0; fragment < (kIndependentWG ? 2 : 1); ++ fragment) {
                        store_l1_swap_chunk(0, fragment);
                        if (valid_m > 8) {
                            #pragma unroll
                            for (uint32_t i = 1; i < kSwapABTokenChunks; ++ i) {
                                if (i < num_swap_token_chunks)
                                    store_l1_swap_chunk(i, fragment);
                            }
                        }
                    }

                    ptx::sync_aligned(kIndependentWG ? 128 : kNumEpilogueThreads, kIndependentWG ? kEpilogueWGBarrierStartIdx + epilogue_wg_idx : kEpilogueFullBarrierIdx);

                    // Per-token amax over the 64-wide SF group and FP8 quantization, with four
                    // threads per token so that all 256 threads take part: each thread loads 16
                    // values as four float4 (slot order rotated by (token + 1) / 2 so that loads
                    // and the packed FP8 stores are bank-conflict free), the quad reduces its
                    // maxima with two XOR shuffles (max is exact, so the amax is the same), and
                    // every value is scaled and converted exactly as before.
                    DG_STATIC_ASSERT(BLOCK_M * 4 == kNumEpilogueThreads, "swapAB L1 quantizer uses four threads per token");
                    #pragma unroll
                    for (uint32_t token_half = 0; token_half < (kIndependentWG ? 2 : 1); ++ token_half) {
                        const uint32_t token = (kIndependentWG ? epilogue_thread_idx % 128 : epilogue_thread_idx) / 4 + token_half * 32;
                        const uint32_t quad_idx = epilogue_thread_idx % 4;
                        const uint32_t slot_rotation = (token + 1) / 2;
                        const bool valid_token = token < valid_m;
                        float4 values[4];
                        float amax = 0.0f;
                        #pragma unroll
                        for (uint32_t j = 0; j < 4; ++ j) {
                            const uint32_t col = (quad_idx + 4 * ((j + slot_rotation) & 3u)) * 4;
                            values[j] = valid_token ?
                                *reinterpret_cast<const float4*>(
                                    smem_cd_swap_l1_fp32 + token * L1_OUT_BLOCK_N + (col ^ swap_l1_swizzle(token))) :
                                make_float4(0.0f, 0.0f, 0.0f, 0.0f);
                            amax = cute::max(amax, cute::abs(values[j].x));
                            amax = cute::max(amax, cute::abs(values[j].y));
                            amax = cute::max(amax, cute::abs(values[j].z));
                            amax = cute::max(amax, cute::abs(values[j].w));
                        }
                        amax = cute::max(amax, __shfl_xor_sync(0xffffffff, amax, 1));
                        amax = cute::max(amax, __shfl_xor_sync(0xffffffff, amax, 2));
                        if (valid_token) {
                            float2 amax_pair = {amax, amax};
                            float2 sf_pair, sf_inv_pair;
                            sm90_fp8_mega_moe_get_e4m3_sf_and_sf_inv(amax_pair, sf_pair, sf_inv_pair);
                            const float sf = sf_pair.x;
                            const float sf_inv = sf_inv_pair.x;

                            // The L2-activation SF pool is strided by SF_BLOCK_M (=128), as the
                            // L2 producer and the non-swap L1 epilogue read and write it.
                            if (quad_idx == 0) {
                                const uint32_t token_idx = pool_block_idx * SF_BLOCK_M + token;
                                l2_sf_buffer.get_base_ptr<float>()[n_block_idx * kNumPaddedSFPoolTokens + token_idx] = sf;
                            }

                            #pragma unroll
                            for (uint32_t j = 0; j < 4; ++ j) {
                                const uint32_t col = (quad_idx + 4 * ((j + slot_rotation) & 3u)) * 4;
                                const __nv_fp8x2_e4m3 lo(make_float2(values[j].x * sf_inv, values[j].y * sf_inv));
                                const __nv_fp8x2_e4m3 hi(make_float2(values[j].z * sf_inv, values[j].w * sf_inv));
                                *reinterpret_cast<uint32_t*>(smem_cd_swap_l1_fp8 + token * L1_OUT_BLOCK_N + col) =
                                    static_cast<uint32_t>(lo.__x) | (static_cast<uint32_t>(hi.__x) << 16);
                            }
                        }
                    }

                    ptx::sync_aligned(kIndependentWG ? 128 : kNumEpilogueThreads, kIndependentWG ? kEpilogueWGBarrierStartIdx + epilogue_wg_idx : kEpilogueFullBarrierIdx);

                    if constexpr (not kL2ArrivalCounter) {
                        // Decode: the thread that issues the store waits for it and publishes
                        // the arrival itself, so only its warp waits for the store; the other
                        // warps go on to the next block. The FP8 staging tile is next written
                        // after a CTA barrier that this warp reaches only after the wait.
                        if ((kIndependentWG ? warp_idx_in_wg == 0 : epilogue_warp_idx == 0) and cute::elect_one_sync()) {
                            cute::tma_store_fence();
                            cute::SM90_TMA_STORE_2D::copy(
                                &tensor_map_l1_output,
                                smem_cd_swap_l1_fp8,
                                n_block_idx * L1_OUT_BLOCK_N,
                                m_idx);
                            cute::tma_store_arrive();
                            ptx::tma_store_wait<0>();
                            ptx::red_or_rel_gpu(
                                workspace.get_l2_arrival_mask_ptr(pool_block_idx),
                                1ull << n_block_idx);
                        }
                        __syncwarp();
                    } else {
                    if (epilogue_wg_n_idx == 0 and warp_idx_in_wg == 0 and cute::elect_one_sync()) {
                        cute::tma_store_fence();
                        cute::SM90_TMA_STORE_2D::copy(
                            &tensor_map_l1_output,
                            smem_cd_swap_l1_fp8,
                            n_block_idx * L1_OUT_BLOCK_N,
                            m_idx);
                        cute::tma_store_arrive();
                    }
                    __syncwarp();
                    ptx::tma_store_wait<0>();

                    if constexpr (kL2ArrivalCounter) {
                        if (epilogue_wg_n_idx == 0 and warp_idx_in_wg == 0 and cute::elect_one_sync()) {
                            ptx::red_add_rel(
                                reinterpret_cast<uint32_t*>(workspace.get_l2_arrival_mask_ptr(pool_block_idx)),
                                kWarpgroupSplitN);
                        }
                    } else {
                        ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                        if ((kIndependentWG ? warp_idx_in_wg == 0 : epilogue_warp_idx == 0) and cute::elect_one_sync()) {
                            ptx::red_or_rel_gpu(
                                workspace.get_l2_arrival_mask_ptr(pool_block_idx),
                                1ull << n_block_idx);
                        }
                    }
                    __syncwarp();
                    if constexpr (kL2ArrivalCounter)
                        ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                    }
                } else if constexpr (kPrefill2WG) {
                    // Qwen Prefill with two math warpgroups: the same SwiGLU, per-row amax
                    // over the warpgroup's 128 output columns (one per-128 group), E4M3
                    // scale and saturating conversion as the path below, so the stored
                    // bytes and scales are the same. What changes is how 8 math warps (2 per
                    // scheduler instead of 4) get through it:
                    //  * SwiGLU runs for every element without the per-pair row branches
                    //    (the row masks only gate the amax and the stores), so a thread's
                    //    64 independent EX2/RCP chains overlap instead of 32 short branchy
                    //    blocks of two. EX2 is the .ftz form: e = 2^(-g log2 e) below 2^-126
                    //    only occurs where 1 + e rounds to 1 anyway.
                    //  * Each warp stages its 16 rows in its own 16 x 144-byte slice (the
                    //    16-byte pad puts the 8 rows of a fragment on distinct banks; the
                    //    128-byte rows of the TMA-store tile were 8-way conflicted) and
                    //    writes them to the L1-output pool with 16-byte global stores, 8
                    //    lanes per 128-byte row segment, valid rows only. No warpgroup
                    //    barrier, TMA store or store drain.
                    //  * The warp's arrival (kL1OutputArrivalParts = 4 per warpgroup tile)
                    //    is published by publish_l1_rows: in the next FC1 tile's K block 2,
                    //    or, for the CTA's last FC1 tile, before its first FC2 block is
                    //    taken, which every CTA does once even without FC2 blocks.
                    constexpr uint32_t kNumPairs = kAccumPerThread / 8;
                    constexpr uint32_t kStageRowBytes = WG_L1_OUT_BLOCK_N + 16;
                    DG_STATIC_ASSERT(WG_L1_OUT_BLOCK_N == 128 and kNumPairs == 16 and kL2ActsSF128,
                                     "kPrefill2WG L1 epilogue shape");
                    DG_STATIC_ASSERT(kNumEpilogueWarps * 16 * kStageRowBytes <= SMEM_CD_SIZE,
                                     "kPrefill2WG L1 staging");
                    auto silu_mul = [](float g, float u) -> float {
                        if constexpr (kActivationClamp != cute::numeric_limits<float>::infinity()) {
                            g = cute::min(g, kActivationClamp);
                            u = cute::min(cute::max(u, -kActivationClamp), kActivationClamp);
                        }
                        float sig;
                        if constexpr (kFastMath) {
                            float e;
                            asm("ex2.approx.ftz.f32 %0, %1;" : "=f"(e) : "f"(g * -1.44269502162933349609375f));
                            asm("rcp.approx.ftz.f32 %0, %1;" : "=f"(sig) : "f"(1.0f + e));
                        } else {
                            sig = 1.0f / (1.0f + expf(-g));
                        }
                        return (g * sig) * u;
                    };
                    // Pair p: gate chunk 2p = final_accum[p*8 + 0..3], up chunk 2p+1 =
                    // final_accum[p*8 + 4..7], each (r0c0, r0c1, r1c0, r1c1); output columns
                    // p*8 + col_idx*2 + {0, 1}.
                    float swiglu_r0[kNumPairs][2], swiglu_r1[kNumPairs][2];
                    float amax_r0 = 0.0f, amax_r1 = 0.0f;
                    #pragma unroll
                    for (uint32_t p = 0; p < kNumPairs; ++ p) {
                        swiglu_r0[p][0] = silu_mul(final_accum[p * 8 + 0], final_accum[p * 8 + 4]);
                        swiglu_r0[p][1] = silu_mul(final_accum[p * 8 + 1], final_accum[p * 8 + 5]);
                        swiglu_r1[p][0] = silu_mul(final_accum[p * 8 + 2], final_accum[p * 8 + 6]);
                        swiglu_r1[p][1] = silu_mul(final_accum[p * 8 + 3], final_accum[p * 8 + 7]);
                        amax_r0 = fmaxf(amax_r0, fmaxf(fabsf(swiglu_r0[p][0]), fabsf(swiglu_r0[p][1])));
                        amax_r1 = fmaxf(amax_r1, fmaxf(fabsf(swiglu_r1[p][0]), fabsf(swiglu_r1[p][1])));
                    }
                    // Rows past valid_m (a partial tile) keep amax 0 as before; their values
                    // are never stored.
                    amax_r0 = valid_r0 ? amax_r0 : 0.0f;
                    amax_r1 = valid_r1 ? amax_r1 : 0.0f;
                    amax_r0 = math::warp_reduce<4, false>(amax_r0, math::ReduceMax<float>());
                    amax_r1 = math::warp_reduce<4, false>(amax_r1, math::ReduceMax<float>());
                    float2 sf_pair, sf_inv_pair;
                    sm90_fp8_mega_moe_get_e4m3_sf_and_sf_inv(make_float2(amax_r0, amax_r1), sf_pair, sf_inv_pair);

                    // Quantize into the warp's staging slice (local rows row_idx and row_idx + 8).
                    auto* stage = reinterpret_cast<uint8_t*>(smem_cd_l1) + epilogue_warp_idx * (16 * kStageRowBytes);
                    auto* stage_r0 = stage + row_idx * kStageRowBytes + col_idx * 2;
                    auto* stage_r1 = stage_r0 + 8 * kStageRowBytes;
                    #pragma unroll
                    for (uint32_t p = 0; p < kNumPairs; ++ p) {
                        const __nv_fp8x2_e4m3 r0_pair(make_float2(swiglu_r0[p][0] * sf_inv_pair.x, swiglu_r0[p][1] * sf_inv_pair.x));
                        const __nv_fp8x2_e4m3 r1_pair(make_float2(swiglu_r1[p][0] * sf_inv_pair.y, swiglu_r1[p][1] * sf_inv_pair.y));
                        *reinterpret_cast<uint16_t*>(stage_r0 + p * 8) = r0_pair.__x;
                        *reinterpret_cast<uint16_t*>(stage_r1 + p * 8) = r1_pair.__x;
                    }

                    // The per-128 scale of the row at `[n_block_idx, token]` (MN-major).
                    if (col_idx == 0) {
                        auto sf_base_ptr = l2_sf_buffer.get_base_ptr<float>() + n_block_idx * kNumPaddedSFPoolTokens + pool_block_idx * SF_BLOCK_M;
                        if (valid_r0)
                            sf_base_ptr[row_offset_r0] = sf_pair.x;
                        if (valid_r1)
                            sf_base_ptr[row_offset_r1] = sf_pair.y;
                    }
                    __syncwarp();

                    // 16 rows x 128 bytes: lane l copies 16-byte chunk l % 8 of local row 4 i + l / 8.
                    const uint32_t warp_row = row_base + warp_idx_in_wg * 16;
                    auto* l1_out = l2_token_buffer.get_base_ptr<uint8_t>() +
                        static_cast<uint64_t>(m_idx + warp_row) * kIntermediateHidden + n_block_idx * L1_OUT_BLOCK_N + (lane_idx % 8) * 16;
                    #pragma unroll
                    for (uint32_t i = 0; i < 4; ++ i) {
                        const uint32_t row = i * 4 + lane_idx / 8;
                        const auto chunk = *reinterpret_cast<const uint4*>(stage + row * kStageRowBytes + (lane_idx % 8) * 16);
                        if (warp_row + row < valid_m)
                            *reinterpret_cast<uint4*>(l1_out + row * kIntermediateHidden) = chunk;
                    }
                    // Orders the lanes' stores before lane 0's release in publish_l1_rows, and
                    // the staging reads before this warp's next writes to its slice.
                    __syncwarp();
                    l1_unpublished_block = pool_block_idx;
                } else {

                // ---------------- L1 EPILOGUE: activation + FP8 quantize + TMA store ----------------
                // Layout in `final_accum`:
                //   kAccumPerThread/4 chunks, each chunk = 4 floats per thread =
                //   (r0c0, r0c1, r1c0, r1c1).
                //   Gate and up chunks alternate; pair `p` uses chunks 2p and 2p+1.
                //
                // For each pair we produce 4 post-SwiGLU floats per thread, mapped to
                // output cols (p*8 + col_idx*2 + {0,1}) for both r0 and r1.

                constexpr uint32_t kNumPairs = kAccumPerThread / 8;
                float sf_r0, sf_inv_r0;
                float sf_r1, sf_inv_r1;

                float swiglu_r0[kNumPairs][2];
                float swiglu_r1[kNumPairs][2];
                float amax_r0 = 0.0f, amax_r1 = 0.0f;

                auto clamp_gate = [](float& x) {
                    if constexpr (kActivationClamp != cute::numeric_limits<float>::infinity())
                        x = cute::min(x, kActivationClamp);
                };
                auto clamp_up = [](float& x) {
                    if constexpr (kActivationClamp != cute::numeric_limits<float>::infinity())
                        x = cute::min(cute::max(x, -kActivationClamp), kActivationClamp);
                };
                auto silu = [](float x) -> float {
                    const float e = kFastMath ? __expf(-x) : expf(-x);
                    const float sig = kFastMath ? math::fast_rcp(1.0f + e) : 1.0f / (1.0f + e);
                    return x * sig;
                };

                #pragma unroll
                for (uint32_t p = 0; p < kNumPairs; ++ p) {
                    const uint32_t gate = 2 * p, up = 2 * p + 1;

                    float g_r0_c0 = final_accum[gate*4 + 0];
                    float g_r0_c1 = final_accum[gate*4 + 1];
                    float g_r1_c0 = final_accum[gate*4 + 2];
                    float g_r1_c1 = final_accum[gate*4 + 3];
                    float u_r0_c0 = final_accum[up*4   + 0];
                    float u_r0_c1 = final_accum[up*4   + 1];
                    float u_r1_c0 = final_accum[up*4   + 2];
                    float u_r1_c1 = final_accum[up*4   + 3];
                    clamp_gate(g_r0_c0);
                    clamp_gate(g_r0_c1);
                    clamp_gate(g_r1_c0);
                    clamp_gate(g_r1_c1);
                    clamp_up(u_r0_c0);
                    clamp_up(u_r0_c1);
                    clamp_up(u_r1_c0);
                    clamp_up(u_r1_c1);

                    if (valid_r0) {
                        swiglu_r0[p][0] = silu(g_r0_c0) * u_r0_c0;
                        swiglu_r0[p][1] = silu(g_r0_c1) * u_r0_c1;
                        amax_r0 = cute::max(amax_r0, cute::max(cute::abs(swiglu_r0[p][0]), cute::abs(swiglu_r0[p][1])));
                    } else {
                        swiglu_r0[p][0] = 0.0f;
                        swiglu_r0[p][1] = 0.0f;
                    }
                    if (valid_r1) {
                        swiglu_r1[p][0] = silu(g_r1_c0) * u_r1_c0;
                        swiglu_r1[p][1] = silu(g_r1_c1) * u_r1_c1;
                        amax_r1 = cute::max(amax_r1, cute::max(cute::abs(swiglu_r1[p][0]), cute::abs(swiglu_r1[p][1])));
                    } else {
                        swiglu_r1[p][0] = 0.0f;
                        swiglu_r1[p][1] = 0.0f;
                    }
                }

                // Keep SwiGLU independent of routing weights. Apply those once,
                // after FC2, in the FP32 combine below (including the SwapAB path).

                // Reduce amax across the 4 col-lanes that share the same row. In the
                // SM90 WGMMA output layout, lanes with the same `lane_idx >> 2` and
                // different `lane_idx & 3` partition the WG-owned output columns for
                // the same r_0/r_1, so this is an INTRA-group reduction
                // (`warp_reduce<4, false>`). Using `<4, true>` would instead merge
                // amax across 8 different rows -- giving wrong per-row SF.
                amax_r0 = math::warp_reduce<4, false>(amax_r0, math::ReduceMax<float>());
                amax_r1 = math::warp_reduce<4, false>(amax_r1, math::ReduceMax<float>());

                // Phase 2: cross-WG amax. When two N-split warpgroups share one
                // per-64 SF group, each WG so far only saw its own
                // WG_L1_OUT_BLOCK_N columns; the true per-row amax spans both
                // halves. Reduce across both warpgroups through a small smem
                // scratch (carved from the upper, currently-unused half of the
                // CD staging region) so BOTH WGs quantize with the SAME SF.
                if constexpr (kSplitNSharesSF) {
                    float* amax_scratch = reinterpret_cast<float*>(
                        reinterpret_cast<uint8_t*>(smem_cd_l1) + SMEM_CD_SIZE / 2);
                    #pragma unroll
                    for (uint32_t i = epilogue_thread_idx; i < BLOCK_M; i += kNumEpilogueThreads)
                        amax_scratch[i] = 0.0f;
                    ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                    if (col_idx == 0) {
                        atomicMax(reinterpret_cast<unsigned int*>(&amax_scratch[r_0]), __float_as_uint(amax_r0));
                        atomicMax(reinterpret_cast<unsigned int*>(&amax_scratch[r_1]), __float_as_uint(amax_r1));
                    }
                    ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                    amax_r0 = amax_scratch[r_0];
                    amax_r1 = amax_scratch[r_1];
                    ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                } else if constexpr (kL2ActsSF128 and not kPrefill2WG) {
                    // (kPrefill2WG: one warpgroup owns all 128 output columns of the group,
                    // so the per-row amax above is already the group amax.)
                    // One per-128 group spans both N-split warpgroups of the row pair:
                    // take the max of the partner's per-row amax (scratch in the upper,
                    // otherwise unused half of the CD region; 2 parities x 2 pairs x
                    // 2 warpgroups x 64 rows of floats).
                    float* amax_pair = reinterpret_cast<float*>(reinterpret_cast<uint8_t*>(smem_cd_l1) + SMEM_CD_SIZE / 2) +
                        ((l1_pair_parity * kWarpgroupSplitM + epilogue_wg_m_idx) * 2 + epilogue_wg_n_idx) * WG_BLOCK_M;
                    const float* amax_partner = amax_pair + (epilogue_wg_n_idx == 0 ? WG_BLOCK_M : -static_cast<int>(WG_BLOCK_M));
                    if (col_idx == 0) {
                        amax_pair[r_0] = amax_r0;
                        amax_pair[r_1] = amax_r1;
                    }
                    ptx::sync_aligned(256, kPairAmaxBarrierStartIdx + epilogue_wg_m_idx);
                    amax_r0 = cute::max(amax_r0, amax_partner[r_0]);
                    amax_r1 = cute::max(amax_r1, amax_partner[r_1]);
                    l1_pair_parity ^= 1u;
                }

                // Compute SF and inverse SF for each row
                float2 amax_pair = {amax_r0, amax_r1};
                float2 sf_pair, sf_inv_pair;
                sm90_fp8_mega_moe_get_e4m3_sf_and_sf_inv(amax_pair, sf_pair, sf_inv_pair);
                sf_r0 = sf_pair.x; sf_inv_r0 = sf_inv_pair.x;
                sf_r1 = sf_pair.y; sf_inv_r1 = sf_inv_pair.y;

                // Quantize and write to the shared-memory staging tile.
                auto* smem_cd_l1_wg = smem_cd_l1 + smem_cd_l1_wg_offset;
                DG_STATIC_ASSERT(kNumPairs % 2 == 0, "L1 staging stores two 8-byte chunks at once");
                #pragma unroll
                for (uint32_t p_base = 0; p_base < kNumPairs; p_base += 2) {
                    uint16_t r0_bits[2], r1_bits[2];
                    #pragma unroll
                    for (uint32_t q = 0; q < 2; ++ q) {
                        const uint32_t p = p_base + q;
                        const float v00 = swiglu_r0[p][0] * sf_inv_r0;
                        const float v01 = swiglu_r0[p][1] * sf_inv_r0;
                        const float v10 = swiglu_r1[p][0] * sf_inv_r1;
                        const float v11 = swiglu_r1[p][1] * sf_inv_r1;

                        const __nv_fp8x2_e4m3 r0_pair(make_float2(v00, v01));
                        const __nv_fp8x2_e4m3 r1_pair(make_float2(v10, v11));
                        r0_bits[q] = valid_r0 ? r0_pair.__x : 0u;
                        r1_bits[q] = valid_r1 ? r1_pair.__x : 0u;
                    }

                    #pragma unroll
                    for (uint32_t q = 0; q < 2; ++ q) {
                        const uint32_t p = p_base + q;
                        const uint32_t col = p * 8 + col_idx * 2;
                        auto* p0 = reinterpret_cast<uint16_t*>(
                            smem_cd_l1_wg + r_0 * WG_SMEM_CD_L1_STRIDE_N + col);
                        auto* p1 = reinterpret_cast<uint16_t*>(
                            smem_cd_l1_wg + r_1 * WG_SMEM_CD_L1_STRIDE_N + col);
                        if (valid_r0)
                            *p0 = r0_bits[q];
                        if (valid_r1)
                            *p1 = r1_bits[q];
                    }
                }

                // Write SF as float at `[token, n_block_idx]` in L2 acts SF buffer (per-64 layout).
                // Each row is contributed by lanes col_idx in {0..3}; only col_idx == 0 writes.
                // In the shared-SF split both warpgroups own the same per-64 group and rows, so
                // only the first N-split warpgroup publishes the SF slot to avoid a write race.
                if (col_idx == 0 and (not (kSplitNSharesSF or kL2ActsSF128) or epilogue_wg_n_idx == 0)) {
                    auto sf_base_ptr = l2_sf_buffer.get_base_ptr<float>();
                    // SF buffer is (kNumPaddedSFPoolTokens x kIntermediateHidden/64), MN-major:
                    //   addr[k_idx * num_padded_sf_pool_tokens + token_idx]
                    const uint32_t token_r0 = pool_block_idx * SF_BLOCK_M + row_offset_r0;
                    const uint32_t token_r1 = pool_block_idx * SF_BLOCK_M + row_offset_r1;
                    // One per-64 post-SwiGLU group, or with per-128 scales the 128-column
                    // L1 output tile `n_block_idx` (slot of the per-64-sized buffer).
                    const uint32_t k_sf_idx = kL2ActsSF128 ? n_block_idx : sf_n_block_idx;
                    if (valid_r0)
                        sf_base_ptr[k_sf_idx * kNumPaddedSFPoolTokens + token_r0] = sf_r0;
                    if (valid_r1)
                        sf_base_ptr[k_sf_idx * kNumPaddedSFPoolTokens + token_r1] = sf_r1;
                }

                // Sync the warpgroup before TMA store. In the shared-tile split
                // both N-split warpgroups must finish writing their halves of the
                // joint L1-output tile, so sync across all epilogue threads.
                if constexpr (kSplitNSharesSF)
                    ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                else
                    ptx::sync_aligned(128, kEpilogueWGBarrierStartIdx + epilogue_wg_idx);

                // Issue TMA store of the entire tile. Padding rows beyond
                // `valid_m` are written with stale/garbage FP8 to the L1-output
                // pool buffer, but they are never consumed downstream: the L2
                // GEMM tile loads them, but its NVLink-scatter epilogue is
                // gated by `m_idx_in_block >= valid_m`, and stale SF in the
                // padding rows can produce NaN accumulators that simply stay
                // in registers (only valid rows are converted to BF16 and
                // STSM'd into smem). Using TMA for partial tiles is a large
                // win for low-batch / decode where every tile is partial.
                if constexpr (kSplitNSharesSF) {
                    // One combined store of the joint L1_OUT_BLOCK_N tile, issued
                    // by the first N-split warpgroup once both halves are staged.
                    if (epilogue_wg_n_idx == 0 and warp_idx_in_wg == 0 and cute::elect_one_sync()) {
                        const uint32_t out_n_idx = n_block_idx * L1_OUT_BLOCK_N;
                        cute::tma_store_fence();
                        cute::SM90_TMA_STORE_2D::copy(
                            &tensor_map_l1_output,
                            smem_cd_l1,
                            out_n_idx,
                            m_idx + row_base);
                        cute::tma_store_arrive();
                    }
                } else {
                    if (warp_idx_in_wg == 0 and cute::elect_one_sync()) {
                        const uint32_t out_n_idx = n_block_idx * L1_OUT_BLOCK_N + wg_l1_out_n_offset;
                        cute::tma_store_fence();
                        cute::SM90_TMA_STORE_2D::copy(
                            &tensor_map_l1_output,
                            smem_cd_l1 + smem_cd_l1_wg_offset,
                            out_n_idx,
                            m_idx + row_base);
                        cute::tma_store_arrive();
                    }
                }
                __syncwarp();
                ptx::tma_store_wait<0>();

                // Notify L2 that this L1 output (and SF) is ready. Counter mode lets
                // independent WG tiles publish arrivals without the CTA-wide barrier
                // needed before the single bit-mask update.
                if constexpr (kL2ArrivalCounter) {
                    if constexpr (kSplitNSharesSF) {
                        // The combined tile counts for both N-split warpgroups; the
                        // storing warpgroup publishes all kWarpgroupSplitN arrivals
                        // after its TMA store has drained.
                        if (epilogue_wg_n_idx == 0 and warp_idx_in_wg == 0 and cute::elect_one_sync()) {
                            ptx::red_add_rel(
                                reinterpret_cast<uint32_t*>(workspace.get_l2_arrival_mask_ptr(pool_block_idx)),
                                kWarpgroupSplitN);
                        }
                    } else if (warp_idx_in_wg == 0 and cute::elect_one_sync()) {
                        ptx::red_add_rel(
                            reinterpret_cast<uint32_t*>(workspace.get_l2_arrival_mask_ptr(pool_block_idx)), 1);
                    }
                } else {
                    ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                    if (epilogue_warp_idx == 0 and cute::elect_one_sync()) {
                        ptx::red_or_rel_gpu(
                            workspace.get_l2_arrival_mask_ptr(pool_block_idx),
                            1ull << n_block_idx);
                    }
                }
                __syncwarp();
                // In the shared-tile split only the first warpgroup issues and
                // drains the combined TMA store; gate the other warpgroup so it
                // cannot overwrite the joint smem tile in the next block until
                // that store has drained.
                if constexpr (kSplitNSharesSF)
                    ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                }
            } else {
                // ---------------- L2 EPILOGUE: BF16 cast + NVLink scatter ----------------
                if constexpr (kPrefillWarpCD) {
                    // Four-stage Prefill: the same BF16 values of the same accumulators go
                    // to the same combine-buffer bytes as the 64 KiB tile path; only the
                    // staging differs. Each warp passes its 16 x 256 tile through its own
                    // 16 x 144-byte slice in four 64-column steps (8 accumulator chunks
                    // each); rows are 144 bytes apart so the 8 rows of a fragment and the
                    // 8 lanes of a 128-byte row read hit distinct banks. Lane l stores
                    // 16-byte piece l % 8 of local rows 4 i + l / 8, whose destinations
                    // are resolved once per tile from the metadata of lanes l and l + 16.
                    DG_STATIC_ASSERT(WG_BLOCK_N == 256 and kAccumPerThread == 128 and kWarpgroupSplitN == 1,
                                     "Four-stage Prefill FC2 staging shape");
                    DG_STATIC_ASSERT(kNumEpilogueWarps * 16 * kPrefillWarpCDRowBytes <= SMEM_CD_SIZE,
                                     "Four-stage Prefill FC2 staging");
                    auto* stage = reinterpret_cast<uint8_t*>(smem_cd_l2) + epilogue_warp_idx * (16 * kPrefillWarpCDRowBytes);
                    const uint32_t warp_row = row_base + warp_idx_in_wg * 16;
                    layout::TokenSrcMetadata meta = {0, 0, 0};
                    if (warp_row + lane_idx % 16 < valid_m)
                        meta = *workspace.get_token_src_metadata_ptr(m_idx + warp_row + lane_idx % 16);
                    uint4* dst[4];
                    bool dst_valid[4];
                    #pragma unroll
                    for (uint32_t i = 0; i < 4; ++ i) {
                        const uint32_t row = i * 4 + lane_idx / 8;
                        const uint32_t dst_rank_idx = __shfl_sync(0xffffffff, meta.rank_idx, row);
                        const uint32_t dst_token_idx = __shfl_sync(0xffffffff, meta.token_idx, row);
                        const uint32_t dst_topk_idx = __shfl_sync(0xffffffff, meta.topk_idx, row);
                        dst_valid[i] = warp_row + row < valid_m;
                        dst[i] = sym_buffer.map(math::advance_ptr<uint4>(
                            combine_token_buffer.get_rank_buffer(dst_topk_idx).get_data_buffer(dst_token_idx).get_base_ptr(),
                            n_idx * sizeof(nv_bfloat16) + (lane_idx % 8) * sizeof(uint4)), dst_rank_idx);
                    }
                    auto* stage_r0 = stage + row_idx * kPrefillWarpCDRowBytes + col_idx * 4;
                    auto* stage_r1 = stage_r0 + 8 * kPrefillWarpCDRowBytes;
                    // stmatrix.x4 rows: lane l addresses row l % 16 of n8 chunk 2 q + l / 16, i.e.
                    // matrices (rows 0-7, 2 q), (8-15, 2 q), (0-7, 2 q + 1), (8-15, 2 q + 1), whose
                    // fragments are the thread's r_0 / r_1 BF16 pairs of those chunks.
                    #pragma unroll
                    for (uint32_t step = 0; step < 4; ++ step) {
                        if constexpr (kPrefillLean) {
                            const uint32_t stage_stsm = cute::cast_smem_ptr_to_uint(stage) + (lane_idx % 16) * kPrefillWarpCDRowBytes + (lane_idx / 16) * 16;
                            #pragma unroll
                            for (uint32_t q = 0; q < 4; ++ q) {
                                const uint32_t chunk = step * 8 + q * 2;
                                asm volatile("stmatrix.sync.aligned.x4.m8n8.shared.b16 [%0], {%1, %2, %3, %4};\n"
                                             :: "r"(stage_stsm + q * 32),
                                                "r"(math::cast_into_bf16_and_pack(final_accum[chunk * 4 + 0], final_accum[chunk * 4 + 1])),
                                                "r"(math::cast_into_bf16_and_pack(final_accum[chunk * 4 + 2], final_accum[chunk * 4 + 3])),
                                                "r"(math::cast_into_bf16_and_pack(final_accum[chunk * 4 + 4], final_accum[chunk * 4 + 5])),
                                                "r"(math::cast_into_bf16_and_pack(final_accum[chunk * 4 + 6], final_accum[chunk * 4 + 7]))
                                             : "memory");
                            }
                        } else {
                        #pragma unroll
                        for (uint32_t j = 0; j < 8; ++ j) {
                            const uint32_t chunk = step * 8 + j;
                            *reinterpret_cast<uint32_t*>(stage_r0 + j * 16) = math::cast_into_bf16_and_pack(
                                final_accum[chunk * 4 + 0], final_accum[chunk * 4 + 1]);
                            *reinterpret_cast<uint32_t*>(stage_r1 + j * 16) = math::cast_into_bf16_and_pack(
                                final_accum[chunk * 4 + 2], final_accum[chunk * 4 + 3]);
                        }
                        }
                        __syncwarp();
                        #pragma unroll
                        for (uint32_t i = 0; i < 4; ++ i) {
                            const auto packed = *reinterpret_cast<const uint4*>(
                                stage + (i * 4 + lane_idx / 8) * kPrefillWarpCDRowBytes + (lane_idx % 8) * sizeof(uint4));
                            if (dst_valid[i])
                                dst[i][step * 8] = packed;
                        }
                        // The next step's writes reuse the slice after every lane has read it.
                        __syncwarp();
                    }
                    if constexpr (kL2EpilogueRequiresFullSync)
                        ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
                    return;
                }
                constexpr uint32_t kNumRowsPerWarp = WG_BLOCK_M / 8;

                const uint32_t row_in_warp_block = lane_idx / 16;  // 0 or 1
                const uint32_t lane_in_row = lane_idx % 16;
                const uint32_t cols_per_lane = WG_BLOCK_N / 16;
                // Non-swap rows are WG_BLOCK_N BF16 (128 or 256 B), so the 8 rows of a
                // WGMMA fragment (lane / 4) hit the same banks: XOR the 16-byte chunk
                // with row % 8. The scatter reads through the same map, so the bytes
                // sent are unchanged.
                DG_STATIC_ASSERT(kSwapABActive or WG_BLOCK_N % 64 == 0, "L2 output swizzle needs 8 chunks per row");
                const auto swizzle_l2_col = [](const uint32_t& row, const uint32_t& col) {
                    return (((col / 8) ^ (row % 8)) * 8) + col % 8;
                };

                if constexpr (kSwapABActive) {
                    auto store_bf16 = [&](const uint32_t& token, const uint32_t& col, float value) {
                        smem_cd_l2[smem_cd_l2_wg_offset + token * WG_BLOCK_N + col] =
                            __float2bfloat16_rn(value);
                    };

                    auto store_l2_swap_chunk = [&](const uint32_t& i, const uint32_t& fragment) {
                        const uint32_t token_0 = i * 8 + col_idx * 2;
                        const uint32_t token_1 = token_0 + 1;
                        if (token_0 < valid_m) {
                            store_bf16(token_0, fragment * 64 + r_0, final_accum[fragment * 32 + i * 4 + 0]);
                            store_bf16(token_0, fragment * 64 + r_1, final_accum[fragment * 32 + i * 4 + 2]);
                        }
                        if (token_1 < valid_m) {
                            store_bf16(token_1, fragment * 64 + r_0, final_accum[fragment * 32 + i * 4 + 1]);
                            store_bf16(token_1, fragment * 64 + r_1, final_accum[fragment * 32 + i * 4 + 3]);
                        }
                    };

                    const uint32_t num_swap_token_chunks = (valid_m + 7u) / 8u;
                    #pragma unroll
                    for (uint32_t fragment = 0; fragment < (kIndependentWG ? 2 : 1); ++ fragment) {
                        store_l2_swap_chunk(0, fragment);
                        if (valid_m > 8) {
                            #pragma unroll
                            for (uint32_t i = 1; i < kSwapABTokenChunks; ++ i) {
                                if (i < num_swap_token_chunks)
                                    store_l2_swap_chunk(i, fragment);
                            }
                        }
                    }
                } else {
                    // STSM into smem_cd_l2 (BF16). Reuse SM100 column-swizzle layout.
                    #pragma unroll
                    for (uint32_t i = 0; i < kAccumPerThread / 8; ++ i) {
                        // Each i consumes 8 floats (one 16x256b chunk in SM100 terms).
                        // For SM90 WGMMA layout, 8 floats per i correspond to 2 chunks of 4 floats:
                        //   final_accum[i*8 + (0..3)] = chunk 2i: (r0c0, r0c1, r1c0, r1c1)
                        //   final_accum[i*8 + (4..7)] = chunk 2i+1: same shape
                        const uint32_t chunk_lo = 2 * i, chunk_hi = 2 * i + 1;

                        auto write_pair = [&](uint32_t row, uint32_t col, uint32_t packed) {
                            auto smem_ptr = smem_cd_l2
                                + smem_cd_l2_wg_offset
                                + row * WG_BLOCK_N
                                + swizzle_l2_col(row, col);
                            // BF16 STS: 2 bf16 elements
                            *reinterpret_cast<uint32_t*>(smem_ptr) = packed;
                        };
                        if (valid_r0) {
                            const uint32_t r0_lo = math::cast_into_bf16_and_pack(
                                final_accum[chunk_lo*4 + 0], final_accum[chunk_lo*4 + 1]);
                            const uint32_t r0_hi = math::cast_into_bf16_and_pack(
                                final_accum[chunk_hi*4 + 0], final_accum[chunk_hi*4 + 1]);
                            write_pair(r_0, chunk_lo * 8 + col_idx * 2, r0_lo);
                            write_pair(r_0, chunk_hi * 8 + col_idx * 2, r0_hi);
                        }
                        if (valid_r1) {
                            const uint32_t r1_lo = math::cast_into_bf16_and_pack(
                                final_accum[chunk_lo*4 + 2], final_accum[chunk_lo*4 + 3]);
                            const uint32_t r1_hi = math::cast_into_bf16_and_pack(
                                final_accum[chunk_hi*4 + 2], final_accum[chunk_hi*4 + 3]);
                            write_pair(r_1, chunk_lo * 8 + col_idx * 2, r1_lo);
                            write_pair(r_1, chunk_hi * 8 + col_idx * 2, r1_hi);
                        }
                    }
                }

                // In the normal layout each warp writes and then scatters its
                // own 16-row slice. swapAB writes by output-column ownership
                // instead, so a token row is produced by the whole warpgroup.
                if constexpr (kSwapABActive)
                    ptx::sync_aligned(128, kEpilogueWGBarrierStartIdx + epilogue_wg_idx);
                else
                    __syncwarp();

                if constexpr (kPrefill2WG) {
                    // A warp's 16 rows are 512 bytes each: one row per iteration, one
                    // 16-byte chunk per lane. The rows' source metadata is loaded up
                    // front (lanes l and l + 16 hold row l) so the per-row remote stores
                    // do not each wait on a dependent load.
                    DG_STATIC_ASSERT(WG_BLOCK_N * sizeof(nv_bfloat16) == 32 * sizeof(uint4), "kPrefill2WG scatter row width");
                    const uint32_t warp_row_base = warp_idx_in_wg * 16;
                    const uint32_t meta_row = warp_row_base + lane_idx % 16;
                    layout::TokenSrcMetadata meta = {0, 0, 0};
                    if (row_base + meta_row < valid_m)
                        meta = *workspace.get_token_src_metadata_ptr(m_idx + row_base + meta_row);
                    #pragma unroll
                    for (uint32_t j = 0; j < 16; ++ j) {
                        const uint32_t row_in_wg = warp_row_base + j;
                        if (row_base + row_in_wg >= valid_m) break;
                        const auto packed = *reinterpret_cast<const uint4*>(
                            smem_cd_l2 + smem_cd_l2_wg_offset + row_in_wg * WG_BLOCK_N + swizzle_l2_col(row_in_wg, lane_idx * 8));
                        const uint32_t dst_rank_idx = __shfl_sync(0xffffffff, meta.rank_idx, j);
                        const uint32_t dst_token_idx = __shfl_sync(0xffffffff, meta.token_idx, j);
                        const uint32_t dst_topk_idx = __shfl_sync(0xffffffff, meta.topk_idx, j);
                        const auto dst_token = combine_token_buffer.get_rank_buffer(dst_topk_idx)
                                               .get_data_buffer(dst_token_idx);
                        auto dst_ptr = math::advance_ptr<uint4>(
                            dst_token.get_base_ptr(),
                            n_idx * sizeof(nv_bfloat16) + lane_idx * sizeof(uint4));
                        *sym_buffer.map(dst_ptr, dst_rank_idx) = packed;
                    }
                } else {
                // Scatter to remote ranks via NVLink (one row per warp-pair)
                // Each warpgroup-warp covers 8 unique rows x 2 (r_0 + r_1 doubled by warps)
                // Lane group of 16 within a warp -> 1 row.
                // Each lane copies `cols_per_lane` BF16 (= cols_per_lane*2 bytes) as one
                // vector. WG_BLOCK_N=128 -> 8 BF16 = uint4; WG_BLOCK_N=64 -> 4 BF16 = uint2.
                using ScatterVec = std::conditional_t<(WG_BLOCK_N <= 64), uint2, uint4>;
                DG_STATIC_ASSERT(cols_per_lane * sizeof(nv_bfloat16) == sizeof(ScatterVec),
                                 "Scatter vector width must match cols_per_lane");
                #pragma unroll
                for (uint32_t j = 0; j < kNumRowsPerWarp; ++ j) {
                    const uint32_t row_in_wg = warp_idx_in_wg * 16 + j * 2 + row_in_warp_block;
                    const uint32_t m_idx_in_block = row_base + row_in_wg;
                    if (m_idx_in_block >= valid_m) break;

                    // Read cols_per_lane BF16 (= one ScatterVec) from smem
                    uint32_t col_in_row = lane_in_row * cols_per_lane;
                    if constexpr (not kSwapABActive)
                        col_in_row = swizzle_l2_col(row_in_wg, col_in_row);
                    auto smem_ptr = smem_cd_l2
                        + smem_cd_l2_wg_offset
                        + row_in_wg * WG_BLOCK_N
                        + col_in_row;
                    const auto packed = *reinterpret_cast<ScatterVec*>(smem_ptr);

                    const auto src_metadata = *workspace.get_token_src_metadata_ptr(m_idx + m_idx_in_block);
                    const uint32_t dst_rank_idx = src_metadata.rank_idx;
                    const uint32_t dst_token_idx = src_metadata.token_idx;
                    const uint32_t dst_topk_idx = src_metadata.topk_idx;
                    const auto dst_token = combine_token_buffer.get_rank_buffer(dst_topk_idx)
                                           .get_data_buffer(dst_token_idx);
                    auto dst_ptr = math::advance_ptr<ScatterVec>(
                        dst_token.get_base_ptr(),
                        (n_idx + wg_n_offset) * sizeof(nv_bfloat16) + lane_in_row * sizeof(ScatterVec));
                    *sym_buffer.map(dst_ptr, dst_rank_idx) = packed;
                }
                }

                if constexpr (kIndependentWG)
                    ptx::sync_aligned(128, kEpilogueWGBarrierStartIdx + epilogue_wg_idx);
                else if constexpr (kL2EpilogueRequiresFullSync)
                    ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx);
            }
        };

        if constexpr (kDynamicL2) {
            uint32_t ring_count = 0;
            sm90_fp8_mega_moe_for_each_block_dynamic_l2<kNumSMs, kNumL1BlockNs, kNumL1BlockKs, kNumL2BlockKs, kPrefillTailPair, WG_BLOCK_M>(
                scheduler,
                [&]() {
                    if constexpr (kPrefill2WG) {
                        // FC1 is over (every CTA gets here, with or without FC2 blocks):
                        // publish this warp's last FC1 rows.
                        publish_l1_rows();
                    }
                    return take_l2_block(ring_count);
                },
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_math_block(
                        std::integral_constant<sched::BlockPhase, sched::BlockPhase::Linear1>{},
                        local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                },
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_math_block(
                        std::integral_constant<sched::BlockPhase, sched::BlockPhase::Linear2>{},
                        local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                });
        } else if constexpr (kSpecializePhase) {
            sm90_fp8_mega_moe_for_each_block_split(
                scheduler,
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_math_block(
                        std::integral_constant<sched::BlockPhase, sched::BlockPhase::Linear1>{},
                        local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                },
                [&](const uint32_t& local_expert_idx,
                    const uint32_t& num_k_blocks,
                    const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                    process_math_block(
                        std::integral_constant<sched::BlockPhase, sched::BlockPhase::Linear2>{},
                        local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
                });
        } else if constexpr (kDecodeTail) {
            decode_for_each_block(process_math_block, decode_receive_block);
        } else {
            scheduler.for_each_block([&](const sched::BlockPhase& block_phase,
                                         const uint32_t& local_expert_idx,
                                         const uint32_t& num_k_blocks,
                                         const uint32_t& m_block_idx, const uint32_t& n_block_idx) {
                process_math_block(block_phase, local_expert_idx, num_k_blocks, m_block_idx, n_block_idx);
            });
        }

        // ---------------- COMBINE ----------------
        // NVLink barrier first: signals remote ranks that this rank's GEMM
        // outputs (NVLink scatter targets) are fully written.
        // Lean EP1: no remote rank waits on this rank's partials, so the CTAs leave after the
        // first grid sync (which orders every CTA's partials); only SM 0 still passes its
        // self-signal, keeping the barrier sequence of the workspace counters.
        if constexpr (kPrefillSplitAccum) {
            // The same sequence as the lean call below (grid sync, then SM 0's self-signal through
            // the workspace counters) without the 300 s NVLink-barrier timeout trap: a trap in the
            // math role keeps ptxas at the launch-bound 168 registers there, and the split K loops
            // need the setmaxnreg budget.
            const auto sync_math = [&]() { ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx); };
            comm::grid_sync<kNumSMs, kEpilogueGridSyncIndex>(workspace, sm_idx, epilogue_thread_idx, sync_math);
            if (sm_idx == 0) {
                auto* counter_ptr = workspace.get_nvl_barrier_counter_ptr();
                const auto status = (*counter_ptr) & 3;
                const auto signal_phase = status & 1, signal_sign = status >> 1;
                auto* signal_ptr = workspace.get_nvl_barrier_signal_ptr(signal_phase);
                if (epilogue_thread_idx < kNumRanks)
                    ptx::red_add_rel_sys(sym_buffer.map(signal_ptr, epilogue_thread_idx), signal_sign ? -1 : 1);
                sync_math();
                if (epilogue_thread_idx == 0) {
                    ptx::red_add(counter_ptr, 1);
                    const int target = signal_sign ? 0 : static_cast<int>(kNumRanks);
                    while (ptx::ld_acq_sys(signal_ptr) != target);
                }
            }
        } else if constexpr (kPrefillLean) {
            comm::nvlink_barrier<kNumRanks, kNumSMs, kNumEpilogueThreads,
                                 kEpilogueGridSyncIndex, kBeforeCombineReduceBarrierTag>(
                workspace, sym_buffer, sm_idx, epilogue_thread_idx,
                [&]() { ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx); }, true, false);
        } else {
        comm::nvlink_barrier<kNumRanks, kNumSMs, kNumEpilogueThreads,
                             kEpilogueGridSyncIndex, kBeforeCombineReduceBarrierTag>(
            workspace, sym_buffer, sm_idx, epilogue_thread_idx,
            [&]() { ptx::sync_aligned(kNumEpilogueThreads, kEpilogueFullBarrierIdx); }
        );
        }

        // Sync with dispatch (paired with dispatch's pre-cleanup sync) so that
        // dispatch may now safely clean workspace state.
        ptx::sync_unaligned(kNumDispatchThreads + kNumEpilogueThreads, kDispatchWithEpilogueBarrierIdx);

        if (epilogue_warp_idx >= kNumCombineWarps)
            return;

        constexpr uint32_t kNumHiddenBytes = kHidden * sizeof(nv_bfloat16);
        constexpr uint32_t kNumElemsPerUint4 = sizeof(uint4) / sizeof(nv_bfloat162);

        constexpr uint32_t kNumChunkSlots = 3;
        constexpr uint32_t kNumMaxRegistersForBuffer = 128;
        constexpr uint32_t kDefaultNumChunks =
            (kNumChunkSlots * kNumCombineWarps * kNumHiddenBytes <= SMEM_BEFORE_BARRIER_SIZE
             and kHidden <= 32 * kNumMaxRegistersForBuffer) ? 1 : 2;
        // Flash-style hidden=7168 is 7 * 1024. Splitting combine into 7 chunks
        // keeps each lane's BF16 reduce accumulator much smaller without
        // violating the 32-lane uint4 mapping.
        constexpr uint32_t kSplitMNNumChunks = (kHidden % 7 == 0) ? 7 : (kHidden >= 1024 ? 4 : 1);
        // Qwen SwapAB batches have at most 128 rows in the measured Decode
        // graphs. One whole-row warp leaves only 16 of 132 CTAs doing combine.
        // Spread the eight 1-KiB chunks across CTAs; each element still visits
        // its live top-k slots in the same order with the same FP32 FMAs.
        constexpr bool kParallelCombine = kSwapABActive and kHidden == 4096 and kNumTopk == 8;
        constexpr uint32_t kNumChunks = kParallelCombine ? 8 :
            ((kSplitMNWarpgroups or kPrefill2WG) ? kSplitMNNumChunks : kDefaultNumChunks);
        constexpr uint32_t kWorkItemsPerToken = kParallelCombine ? kNumChunks : 1;
        constexpr uint32_t kNumChunkBytes = kNumHiddenBytes / kNumChunks;
        constexpr uint32_t kNumChunkUint4 = kNumChunkBytes / sizeof(uint4);
        constexpr uint32_t kNumUint4PerLane = kNumChunkUint4 / 32;
        DG_STATIC_ASSERT(kHidden % kNumChunks == 0, "Hidden must be divisible by number of chunks");
        DG_STATIC_ASSERT(kNumChunkSlots * kNumCombineWarps * kNumHiddenBytes / kNumChunks <= SMEM_BEFORE_BARRIER_SIZE, "Hidden is too large");
        DG_STATIC_ASSERT(kNumChunkBytes % 16 == 0, "Combine chunk must be TMA-aligned (16 bytes)");
        DG_STATIC_ASSERT(kNumChunkBytes % sizeof(uint4) == 0, "Combine chunk must be divisible by 16 bytes");
        DG_STATIC_ASSERT(kNumChunkUint4 % 32 == 0, "Combine chunk must be a multiple of 32 16-byte elements");
        DG_STATIC_ASSERT(kNumTopk <= 32, "Top-k must fit in a single warp");

        // (The split instantiation relies on the static assert below: no trap in the math role.)
        if constexpr (not kPrefillSplitAccum) {
        DG_TRAP_ONLY_DEVICE_ASSERT(kCombineSmemOffset + kNumChunkSlots * kNumCombineWarps * kNumChunkBytes <= static_cast<uint32_t>(
            reinterpret_cast<uint8_t*>(barrier_start_ptr) - smem_buffer));
        }

        DG_STATIC_ASSERT(kCombineSmemOffset + kNumChunkSlots * kNumCombineWarps * kNumChunkBytes <= SMEM_BEFORE_BARRIER_SIZE,
                         "Combine buffers do not fit");
        const auto combine_load_buffer = utils::PatternVisitor([&](const uint32_t& i) {
            return math::advance_ptr<uint4>(smem_buffer, kCombineSmemOffset + (epilogue_warp_idx + i * kNumCombineWarps) * kNumChunkBytes);
        });
        const auto combine_store_buffer = math::advance_ptr<uint4>(
            smem_buffer, kCombineSmemOffset + (epilogue_warp_idx + kNumCombineWarps * 2) * kNumChunkBytes);

        auto combine_load_barriers = utils::PatternVisitor([&](const uint32_t& i) {
            return combine_barriers[i + epilogue_warp_idx * 2];
        });

        if constexpr (kPairedCombine) {
        // Qwen Prefill combine: the same per-chunk FP32 reduction in ascending
        // top-k slot order (bit-identical output), but the loads form one
        // continuous stream across slots, chunks and tokens. Slots are loaded in
        // pairs on one mbarrier, so the two existing barriers per warp keep two
        // pairs (four 2 KiB loads) in flight instead of two loads, and the next
        // chunk's first loads are already in flight while the current chunk's
        // last pair is reduced (the per-chunk pipeline drained at every chunk).
        DG_STATIC_ASSERT(kCombineSmemOffset + 5 * kNumCombineWarps * kNumChunkBytes <= SMEM_BEFORE_BARRIER_SIZE,
                         "No room for the paired combine buffers");
        const auto pair_buffer = [&](const uint32_t& i) {
            return math::advance_ptr<uint4>(smem_buffer, kCombineSmemOffset + (epilogue_warp_idx + i * kNumCombineWarps) * kNumChunkBytes);
        };
        const auto paired_store_buffer = math::advance_ptr<uint4>(
            smem_buffer, kCombineSmemOffset + (epilogue_warp_idx + kNumCombineWarps * 4) * kNumChunkBytes);
        const auto read_token_mask = [&](const uint32_t& token_idx) {
            const int slot_expert_idx = lane_idx < kNumTopk ?
                static_cast<int>(__ldg(input_topk_idx_buffer.get_base_ptr<int64_t>() + token_idx * kNumTopk + lane_idx)) : -1;
            return __ballot_sync(0xffffffff, slot_expert_idx >= 0);
        };
        constexpr uint32_t kTokenStride = kNumSMs * kNumCombineWarps;
        const uint32_t first_token_idx = sm_idx * kNumCombineWarps + epilogue_warp_idx;

        // Load issue state: runs ahead of the reduction by one pair.
        uint32_t issue_token_idx = first_token_idx, issue_chunk = 0, issue_mask = 0, issue_remaining = 0;
        const auto find_issue_token = [&]() {
            for (; issue_token_idx < num_tokens; issue_token_idx += kTokenStride) {
                issue_mask = read_token_mask(issue_token_idx);
                if (issue_mask != 0) {
                    issue_chunk = 0;
                    issue_remaining = issue_mask;
                    return;
                }
            }
        };
        find_issue_token();
        uint32_t issue_stage = 0;
        const auto issue_pair = [&]() {
            if (issue_token_idx >= num_tokens)
                return;
            const uint32_t slot_0 = __ffs(issue_remaining) - 1;
            issue_remaining ^= 1u << slot_0;
            const bool has_slot_1 = issue_remaining != 0;
            const uint32_t slot_1 = has_slot_1 ? __ffs(issue_remaining) - 1 : 0;
            if (has_slot_1)
                issue_remaining ^= 1u << slot_1;
            if (cute::elect_one_sync()) {
                const uint32_t chunk_byte_offset = issue_chunk * kNumChunkBytes;
                ptx::tma_load_1d(pair_buffer(issue_stage * 2),
                                 math::advance_ptr<uint8_t>(combine_token_buffer.get_rank_buffer(slot_0).get_data_buffer(issue_token_idx).get_base_ptr(), chunk_byte_offset),
                                 combine_load_barriers[issue_stage], kNumChunkBytes);
                if (has_slot_1) {
                    ptx::tma_load_1d(pair_buffer(issue_stage * 2 + 1),
                                     math::advance_ptr<uint8_t>(combine_token_buffer.get_rank_buffer(slot_1).get_data_buffer(issue_token_idx).get_base_ptr(), chunk_byte_offset),
                                     combine_load_barriers[issue_stage], kNumChunkBytes);
                }
                ptx::mbarrier_arrive_and_set_tx(combine_load_barriers[issue_stage], has_slot_1 ? 2 * kNumChunkBytes : kNumChunkBytes);
            }
            __syncwarp();
            issue_stage ^= 1;
            if (issue_remaining == 0) {
                if (++ issue_chunk < kNumChunks) {
                    issue_remaining = issue_mask;
                } else {
                    issue_token_idx += kTokenStride;
                    find_issue_token();
                }
            }
        };
        const auto reduce_slot = [&](float2* reduced, const uint4* buffer, const float& weight) {
            #pragma unroll
            for (uint32_t j = 0; j < kNumUint4PerLane; ++ j) {
                const auto uint4_values = buffer[j * 32 + lane_idx];
                const auto bf16_values = reinterpret_cast<const nv_bfloat162*>(&uint4_values);
                #pragma unroll
                for (uint32_t l = 0; l < kNumElemsPerUint4; ++ l) {
                    const auto value = __bfloat1622float2(bf16_values[l]);
                    auto& sum = reduced[j * kNumElemsPerUint4 + l];
                    sum.x = fmaf(value.x, weight, sum.x);
                    sum.y = fmaf(value.y, weight, sum.y);
                }
            }
        };

        issue_pair();
        uint32_t wait_stage = 0, wait_phase = 0;
        for (uint32_t token_idx = first_token_idx; token_idx < num_tokens; token_idx += kTokenStride) {
            const uint32_t total_mask = read_token_mask(token_idx);
            const float lane_weight = (lane_idx < kNumTopk and ((total_mask >> lane_idx) & 1u)) ?
                __ldg(input_topk_weights_buffer.get_base_ptr<float>() + token_idx * kNumTopk + lane_idx) : 0.0f;

            for (uint32_t chunk = 0; chunk < kNumChunks; ++ chunk) {
                const uint32_t chunk_byte_offset = chunk * kNumChunkBytes;
                float2 reduced[kNumUint4PerLane * kNumElemsPerUint4] = {};
                uint32_t remaining = total_mask;
                while (remaining != 0) {
                    const uint32_t slot_0 = __ffs(remaining) - 1;
                    remaining ^= 1u << slot_0;
                    const bool has_slot_1 = remaining != 0;
                    const uint32_t slot_1 = has_slot_1 ? __ffs(remaining) - 1 : 0;
                    if (has_slot_1)
                        remaining ^= 1u << slot_1;
                    const float weight_0 = __shfl_sync(0xffffffff, lane_weight, slot_0);
                    const float weight_1 = __shfl_sync(0xffffffff, lane_weight, slot_1);
                    issue_pair();
                    combine_load_barriers[wait_stage]->wait(wait_phase);
                    reduce_slot(reduced, pair_buffer(wait_stage * 2), weight_0);
                    if (has_slot_1)
                        reduce_slot(reduced, pair_buffer(wait_stage * 2 + 1), weight_1);
                    wait_phase ^= wait_stage;
                    wait_stage ^= 1;
                }

                #pragma unroll
                for (uint32_t j = 0; j < kNumUint4PerLane; ++ j) {
                    uint4 casted;
                    auto casted_bf16 = reinterpret_cast<nv_bfloat162*>(&casted);
                    #pragma unroll
                    for (uint32_t l = 0; l < kNumElemsPerUint4; ++ l)
                        casted_bf16[l] = __float22bfloat162_rn(reduced[j * kNumElemsPerUint4 + l]);

                    if (j == 0) {
                        ptx::tma_store_wait<0>();
                        __syncwarp();
                    }
                    ptx::st_shared(paired_store_buffer + j * 32 + lane_idx,
                                   casted.x, casted.y, casted.z, casted.w);
                }
                __syncwarp();

                if (cute::elect_one_sync()) {
                    cute::tma_store_fence();
                    ptx::tma_store_1d(
                        math::advance_ptr(y, static_cast<uint64_t>(token_idx) * kNumHiddenBytes + chunk_byte_offset),
                        paired_store_buffer, kNumChunkBytes);
                    cute::tma_store_arrive();
                }
                __syncwarp();
            }
        }
        } else {
        uint32_t combine_phase = 0;
        uint32_t load_stage_idx = 0;
        for (uint32_t work_idx = sm_idx * kNumCombineWarps + epilogue_warp_idx;
             work_idx < num_tokens * kWorkItemsPerToken;
             work_idx += kNumSMs * kNumCombineWarps) {
            const uint32_t token_idx = work_idx / kWorkItemsPerToken;
            const uint32_t first_chunk = kParallelCombine ? work_idx % kNumChunks : 0;
            const uint32_t end_chunk = kParallelCombine ? first_chunk + 1 : kNumChunks;
            const int stored_topk_slot_idx = lane_idx < kNumTopk ?
                static_cast<int>(__ldg(input_topk_idx_buffer.get_base_ptr<int64_t>() + token_idx * kNumTopk + lane_idx)) : -1;
            const uint32_t total_mask = __ballot_sync(0xffffffff, stored_topk_slot_idx >= 0);

            for (uint32_t chunk = first_chunk; chunk < end_chunk; ++ chunk) {
                const uint32_t chunk_byte_offset = chunk * kNumChunkBytes;

                uint32_t mask = total_mask;
                float combine_weights[2] = {};
                const auto move_mask_and_load = [&](const uint32_t& i) {
                    if (mask) {
                        const uint32_t slot_idx = __ffs(mask) - 1;
                        mask ^= 1 << slot_idx;
                        combine_weights[i] = __ldg(input_topk_weights_buffer.get_base_ptr<float>() + token_idx * kNumTopk + slot_idx);
                        if (cute::elect_one_sync()) {
                            const auto src_ptr = math::advance_ptr<uint8_t>(
                                combine_token_buffer.get_rank_buffer(slot_idx)
                                                    .get_data_buffer(token_idx).get_base_ptr(),
                                chunk_byte_offset);
                            ptx::tma_load_1d(combine_load_buffer[i], src_ptr, combine_load_barriers[i], kNumChunkBytes);
                            ptx::mbarrier_arrive_and_set_tx(combine_load_barriers[i], kNumChunkBytes);
                        }
                        __syncwarp();
                        return true;
                    }
                    return false;
                };

                bool do_reduce = move_mask_and_load(load_stage_idx);

                float2 reduced[kNumUint4PerLane * kNumElemsPerUint4] = {};
                while (do_reduce) {
                    do_reduce = move_mask_and_load(load_stage_idx ^ 1);
                    combine_load_barriers[load_stage_idx]->wait(combine_phase);
                    #pragma unroll
                    for (uint32_t j = 0; j < kNumUint4PerLane; ++ j) {
                        const auto uint4_values = combine_load_buffer[load_stage_idx][j * 32 + lane_idx];
                        const auto bf16_values = reinterpret_cast<const nv_bfloat162*>(&uint4_values);
                        #pragma unroll
                        for (uint32_t l = 0; l < kNumElemsPerUint4; ++ l) {
                            const auto value = __bfloat1622float2(bf16_values[l]);
                            auto& sum = reduced[j * kNumElemsPerUint4 + l];
                            sum.x = fmaf(value.x, combine_weights[load_stage_idx], sum.x);
                            sum.y = fmaf(value.y, combine_weights[load_stage_idx], sum.y);
                        }
                    }
                    combine_phase ^= load_stage_idx;
                    load_stage_idx ^= 1;
                }

                #pragma unroll
                for (uint32_t j = 0; j < kNumUint4PerLane; ++ j) {
                    uint4 casted;
                    auto casted_bf16 = reinterpret_cast<nv_bfloat162*>(&casted);
                    #pragma unroll
                    for (uint32_t l = 0; l < kNumElemsPerUint4; ++ l)
                        casted_bf16[l] = __float22bfloat162_rn(reduced[j * kNumElemsPerUint4 + l]);

                    if (j == 0) {
                        ptx::tma_store_wait<0>();
                        __syncwarp();
                    }
                    ptx::st_shared(combine_store_buffer + j * 32 + lane_idx,
                                   casted.x, casted.y, casted.z, casted.w);
                }
                __syncwarp();

                if (cute::elect_one_sync()) {
                    cute::tma_store_fence();
                    ptx::tma_store_1d(
                        math::advance_ptr(y, static_cast<uint64_t>(token_idx) * kNumHiddenBytes + chunk_byte_offset),
                        combine_store_buffer, kNumChunkBytes);
                    cute::tma_store_arrive();
                }
                __syncwarp();
            }
        }
        }
    }
#else
    if (blockIdx.x == 0 and threadIdx.x == 0)
        DG_TRAP_ONLY_DEVICE_ASSERT(false and "This kernel only supports sm_90");
#endif
}

} // namespace deep_gemm

#pragma clang diagnostic pop
